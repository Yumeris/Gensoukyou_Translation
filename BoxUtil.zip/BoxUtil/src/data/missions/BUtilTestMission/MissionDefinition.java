package data.missions.BUtilTestMission;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import org.boxutil.base.BaseShaderData;
import org.boxutil.define.BoxEnum;
import org.boxutil.define.BoxGeometry;
import org.boxutil.manager.CombatRenderingManager;
import org.boxutil.manager.ShaderCore;
import org.boxutil.units.standard.entity.*;
import org.boxutil.units.standard.misc.ArcObject;
import org.boxutil.units.standard.misc.NumberObject;
import org.boxutil.util.RenderingUtil;
import org.boxutil.util.TransformUtil;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import java.awt.*;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

public class MissionDefinition implements MissionDefinitionPlugin {
    private final static float _MISSION_MAP_SIZE_HALF = 6400.0f;

    public void defineMission(MissionDefinitionAPI api) {
        api.initFleet(FleetSide.PLAYER, "BOX", FleetGoal.ATTACK, false);
        api.initFleet(FleetSide.ENEMY, "BOX", FleetGoal.ATTACK, true);

        api.setFleetTagline(FleetSide.PLAYER, "GL");
        api.setFleetTagline(FleetSide.ENEMY, "HF");
        api.addBriefingItem("Just test.");

        FleetMemberAPI fm = api.addToFleet(FleetSide.PLAYER, "onslaught_xiv_Elite", FleetMemberType.SHIP, "Test guy", true);
        fm.getVariant().addTag("TEST");

        api.addToFleet(FleetSide.ENEMY, "onslaught_xiv_Elite", FleetMemberType.SHIP, "Test guy", true);

        api.initMap(-_MISSION_MAP_SIZE_HALF, _MISSION_MAP_SIZE_HALF, -_MISSION_MAP_SIZE_HALF, _MISSION_MAP_SIZE_HALF);
        api.addPlugin(new Plugin());
    }

    private static final class Plugin extends BaseEveryFrameCombatPlugin {
        private CombatEngineAPI engine = null;
        private CommonEntity commonEntity = null;
        private DistortionEntity distortion = null;
        private FlareEntity flareEntity = null;
        private FlareEntity flareEntity2 = null;
        private CurveEntity curveEntity = null;
        private SegmentEntity segmentEntity = null;
        private NumberObject locVec = new NumberObject();
        private ArcObject arc = new ArcObject();
        private SpriteEntity spriteEntity = null;
        private float time = 0.0f;
        private boolean tog = false;
        private TextFieldEntity textEntity = null;

        public void init(CombatEngineAPI engine) {
            this.engine = engine;
            engine.addLayeredRenderingPlugin(new RenderingPlugin());
            this.locVec.setIntegerLength(4);
            this.locVec.setDecimalLength(2);
            this.locVec.setColorWithoutAlpha(Misc.getPositiveHighlightColor());
            this.arc.setColorWithoutAlpha(Misc.getPositiveHighlightColor());
            this.arc.setRingHardness(0.99f);
            this.arc.setInner(0.95f, 0.95f);
            this.arc.setInnerHardness(0.8f);
            this.arc.setArcDirect(-1.0f);
        }

        public void advance(float amount, List<InputEventAPI> events) {
            this.time = this.engine.getTotalElapsedTime(false);
            ShipAPI ship = this.engine.getPlayerShip();
            if (ship == null) return;
            if (this.flareEntity != null) {
                this.flareEntity.appendToEntity(ship);
                this.flareEntity2.setStateVanilla(new Vector2f(ship.getLocation().x, ship.getLocation().y + 100.0f), 0.0f);
//                this.flareEntity.setLocation(ship.getLocation().x + 100.0f, ship.getLocation().y + 200.0f);
            } else {
                this.flareEntity = new FlareEntity();
                this.flareEntity.setSize(640, 16);
                this.flareEntity.setFlick(true);
                this.flareEntity.setFlickWhenPaused(false);
                this.flareEntity.setLayer(CombatEngineLayers.ABOVE_PARTICLES_LOWER);
                this.flareEntity.setSmoothDisc();
                this.flareEntity.setFringeColor(Misc.getNegativeHighlightColor());
                this.flareEntity.setCoreColor(Color.WHITE);
                this.flareEntity.setCoreAlpha(1.0f);
                this.flareEntity.setFringeAlpha(1.0f);
                this.flareEntity.setAdditiveBlend();
                this.flareEntity.setNoisePower(0.33f);
                this.flareEntity.autoAspect();
                this.flareEntity.setGlobalTimer(0.0f, 8192.0f, 2.0f);
                CombatRenderingManager.addEntity(BoxEnum.ENTITY_FLARE, this.flareEntity);

                Pair<FlareEntity, Byte> p = RenderingUtil.addCombatFlareField(ship.getLocation(), 128, ship.getFacing(), 360, 512.0f, new Vector4f(96, 5, 256, 12), Misc.getPositiveHighlightColor(), Color.WHITE, 8.0f, 3.0f, CombatEngineLayers.ABOVE_PARTICLES);
                this.flareEntity2 = p.one;
                this.flareEntity2.setAdditiveBlend();
                this.flareEntity2.setSmoothDisc();
                this.flareEntity2.setFringeAlpha(1.0f);
                this.flareEntity2.setCoreAlpha(1.0f);
                this.flareEntity2.setGlowPower(1.0f);
            }
            if (this.curveEntity != null) {
                this.curveEntity.setLocation(ship.getLocation().x + 100.0f, ship.getLocation().y - 200.0f);
            } else {
                this.curveEntity = new CurveEntity().initElliptic(null, 256, 128.0f, Misc.getNegativeHighlightColor(), new Color(15, 16, 17, 18), 12.0f);
                this.curveEntity.getMaterialData().setDiffuse(Global.getSettings().getSprite("graphics/fx/beam_weave_fringe.png"));
                this.curveEntity.setInterpolation((short) 64);
                this.curveEntity.setTexturePixels(256.0f);
                this.curveEntity.setTextureSpeed(100.0f);
                this.curveEntity.setLayer(CombatEngineLayers.ABOVE_PARTICLES_LOWER);
                this.curveEntity.setAdditiveBlend();
                this.curveEntity.setGlobalTimer(0.0f, 8192.0f, 2.0f);
                this.curveEntity.setFillEndAlpha(0.0f);
                this.curveEntity.setFillEndFactor(0.1f);
                CombatRenderingManager.addEntity(BoxEnum.ENTITY_CURVE, this.curveEntity);
            }
            if (this.segmentEntity != null) {
                this.segmentEntity.setStateVanilla(new Vector2f(ship.getLocation().x, ship.getLocation().y), ship.getFacing() + 90.0f);
            } else {
                List<Vector2f> points = new ArrayList<>(5);
                points.add(new Vector2f(-100.0f, -100.0f));
                points.add(new Vector2f(100.0f, -100.0f));
                points.add(new Vector2f(100.0f, 100.0f));
                points.add(new Vector2f(-100.0f, 100.0f));
                points.add(new Vector2f(-150.0f, 0.0f));
                this.segmentEntity = new SegmentEntity().initLineStrip(points, Color.ORANGE, Color.WHITE, 16.0f, true);
                this.segmentEntity.getMaterialData().setDiffuse(Global.getSettings().getSprite("graphics/fx/beam_weave_fringe.png"));
                this.segmentEntity.getMaterialData().setEmissive(Global.getSettings().getSprite("graphics/fx/beam_rough2_core.png"));
                this.segmentEntity.getMaterialData().setEmissiveColorAlpha(0.7f);
                this.segmentEntity.setTexturePixels(256.0f);
                this.segmentEntity.setTextureSpeed(100.0f);
                this.segmentEntity.setLayer(CombatEngineLayers.ABOVE_PARTICLES_LOWER);
                this.segmentEntity.setAdditiveBlend();
                this.segmentEntity.setGlobalTimer(0.0f, 8192.0f, 2.0f);
            }
            if (this.distortion != null) {
                if (Global.getCombatEngine().getPlayerShip() != null) this.distortion.setLocation(this.engine.getPlayerShip().getLocation());
            } else {
                this.distortion = new DistortionEntity();
                this.distortion.setGlobalTimer(5.0f, 3.0f, 5.0f);
                this.distortion.setInnerFull(0.7f, 0.2f);
                this.distortion.setInnerHardness(0.8f);
                this.distortion.setSizeIn(256, 256);
                this.distortion.setPowerIn(0);
                this.distortion.setPowerFull(1);
                this.distortion.setPowerOut(0);
                this.distortion.setSizeFull(128, 128);
                this.distortion.setSizeOut(96, 96);
                CombatRenderingManager.addEntity(BoxEnum.ENTITY_DISTORTION, this.distortion);
            }
            if (this.commonEntity != null) {
                this.commonEntity.setModelMatrix(TransformUtil.createModelMatrixRotateOnly(TransformUtil.rotationZXY(
                                        ship.getFacing(), (this.engine.getTotalElapsedTime(false) * 60.0f) % 360.0f, 0.0f
                                ), null));
                this.commonEntity.getModelMatrix().m30 = ship.getLocation().x;
                this.commonEntity.getModelMatrix().m31 = ship.getLocation().y;
            } else {
                this.commonEntity = new CommonEntity(BoxGeometry.DEMO_BOX, true);
                this.commonEntity.setBaseSize3D(200, 200, 200);
                this.commonEntity.setLayer(CombatEngineLayers.ABOVE_SHIPS_LAYER);
                this.commonEntity.setGlobalTimer(1.0f, 8192.0f, 0.0f);
                CombatRenderingManager.addEntity(BoxEnum.ENTITY_COMMON, this.commonEntity);
            }
            if (this.spriteEntity != null) {
                this.spriteEntity.setLocation(this.engine.getViewport().getCenter());
            } else {
                this.spriteEntity = new SpriteEntity("graphics/fx/dust_clouds_colorless.png");
                this.spriteEntity.setEmissiveSprite("graphics/fx/fx_clouds01.png");
                this.spriteEntity.setAdditiveBlend();
                this.spriteEntity.setTileSize(4, 4);
                this.spriteEntity.setStartingFormIndex(4);
                this.spriteEntity.setRandomTile(true);
                this.spriteEntity.setBaseSizePerTiles(100, 100);
                this.spriteEntity.getMaterialData().setColor(1.0f, 0.2f, 0.0f, 1.0f);
                this.spriteEntity.getMaterialData().setEmissiveColor(1.0f, 0.8f, 0.3f, 1.0f);
                this.spriteEntity.setLayer(CombatEngineLayers.JUST_BELOW_WIDGETS);
                this.spriteEntity.setGlobalTimer(1.0f, 8192.0f, 0.0f);
                CombatRenderingManager.addEntity(BoxEnum.ENTITY_SPRITE, this.spriteEntity);
            }
            if (this.textEntity == null) {
                this.textEntity = new TextFieldEntity("graphics/fonts/insignia15LTaa.fnt");
                this.textEntity.addText("Text can rendering at everywhere :)" + TextFieldEntity.LINE_FEED_SYMBOL,
                        0.0f, Misc.getButtonTextColor(),
                        false, true, false, false, 0);
                this.textEntity.addText("Add to 'Rendering manager' or 'directDraw' both ok.",
                        0.0f, Misc.getButtonTextColor(),
                        false, true, true, false, 0);
                this.textEntity.setFontSpace(1.0f, 5.0f);
                this.textEntity.setFieldSize(512.0f, 64.0f);
                this.textEntity.setTextDataRefreshAllFromCurrentIndex();
                this.textEntity.submitText();
                this.textEntity.setCustomPrimeMatrix();
                this.textEntity.setPrimeMatrix(TransformUtil.createWindowOrthoMatrix(null));
                this.textEntity.setLocation(2.0f, ShaderCore.getScreenHeight() * 0.5f);
//                CombatRenderingManager.addEntity(BoxEnum.ENTITY_TEXT, this.textEntity);
            } else {
                this.textEntity.directDraw(false);
                if (this.engine.getTotalElapsedTime(false) > 5.0f && !this.tog) {
                    this.tog = true;
                    TextFieldEntity.TextData a =this.textEntity.getTextDataList().get(1);
                    a.text = "change.";
                    this.textEntity.setTextDataRefreshIndex(1);
                    this.textEntity.setTextDataRefreshSize(1);
                    this.textEntity.submitText();
                }
            }
        }

        public void renderInUICoords(ViewportAPI viewport) {
            if (this.engine.getPlayerShip() == null) return;
            ShipAPI player = this.engine.getPlayerShip();
            this.locVec.setAlpha(viewport.getAlphaMult() * 0.8f);
            this.arc.setAlpha(viewport.getAlphaMult() * 0.5f);
            GL11.glPushMatrix();
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glTranslatef(ShaderCore.getScreenWidth() * 0.5f, ShaderCore.getScreenHeight() + 82.0f, 0.0f);
            this.arc.glDraw(225.0f, 225.0f);
            GL11.glTranslatef(-112.0f, -112.0f, 0.0f);
            this.locVec.glDraw(player.getLocation().x, 96.0f, 30.0f);
            GL11.glTranslatef(0.0f, -34.0f, 0.0f);
            this.locVec.glDraw(player.getLocation().y, 96.0f, 30.0f);
            GL11.glTranslatef(0.0f, -34.0f, 0.0f);
            this.locVec.setColorWithoutAlpha(Misc.getButtonTextColor());
            this.locVec.glDraw(player.getAngularVelocity(), 96.0f, 30.0f);
            GL11.glTranslatef(128.0f, 0.0f, 0.0f);
            this.locVec.glDraw(player.getFacing(), 96.0f, 30.0f);
            GL11.glTranslatef(0.0f, 34.0f, 0.0f);
            this.locVec.setColorWithoutAlpha(Misc.getPositiveHighlightColor());
            this.locVec.glDraw(player.getVelocity().y, 96.0f, 30.0f);
            GL11.glTranslatef(0.0f, 34.0f, 0.0f);
            this.locVec.glDraw(player.getVelocity().x, 96.0f, 30.0f);
            GL11.glPopMatrix();
        }

        private final class RenderingPlugin extends BaseCombatLayeredRenderingPlugin {
            private TextFieldEntity text = null;

            public void render(CombatEngineLayers layer, ViewportAPI viewport) {
                if (layer == RenderingUtil.getLowestCombatLayer()) {
                    BaseShaderData program = ShaderCore.getTestMissionProgram();
                    if (program == null || !program.isValid()) return;
                    GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
                    GL11.glViewport(0, 0, ShaderCore.getScreenScaleWidth(), ShaderCore.getScreenScaleHeight());
                    GL11.glMatrixMode(GL11.GL_PROJECTION);
                    GL11.glPushMatrix();
                    GL11.glLoadIdentity();
                    GL11.glMatrixMode(GL11.GL_MODELVIEW);
                    GL11.glPushMatrix();
                    GL11.glLoadIdentity();
                    GL11.glEnable(GL11.GL_BLEND);
                    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
                    program.active();
                    GL20.glUniform1f(program.location[0], time);
                    GL11.glBegin(GL11.GL_QUADS);
                    GL11.glVertex2f(-1.0f, -1.0f);
                    GL11.glVertex2f(-1.0f, 1.0f);
                    GL11.glVertex2f(1.0f, 1.0f);
                    GL11.glVertex2f(1.0f, -1.0f);
                    GL11.glEnd();
                    program.close();
                    GL11.glPopMatrix();
                    GL11.glMatrixMode(GL11.GL_PROJECTION);
                    GL11.glPopMatrix();
                    GL11.glPopAttrib();
                }
                if (layer == RenderingUtil.getHighestCombatLayer()) {
                    if (this.text == null) {
                        this.text = new TextFieldEntity("graphics/fonts/orbitron20aabold.fnt");
                        this.text.addText("#TEST-TEST-TEST#" + TextFieldEntity.LINE_FEED_SYMBOL,
                                0.0f, Misc.getButtonTextColor(),
                                false, false, true, true, 0);
                        this.text.addText(" !@#$%^&*()_+-=1234567890`~[]{};':\",.<>/?|\\" + TextFieldEntity.LINE_FEED_SYMBOL,
                                0.0f, Misc.getPositiveHighlightColor(),
                                false, true, false, false, 0);
                        this.text.addText("AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz" + TextFieldEntity.LINE_FEED_SYMBOL,
                                0.0f, Misc.getPositiveHighlightColor(),
                                false, true, true, false, 0);
                        this.text.addText("#test-test-test#",
                                10.0f, Misc.getNegativeHighlightColor(),
                                true, false, false, true, 0);
                        this.text.setAlignment(TextFieldEntity.Alignment.MID);
                        this.text.setFontSpace(8.0f, 5.0f);
                        this.text.setFieldSize(350.0f, 512.0f);
                        this.text.setTextDataRefreshAllFromCurrentIndex();
                        this.text.submitText();
                    } else {
                        if (engine.getPlayerShip() != null) this.text.setLocation(engine.getPlayerShip().getLocation());
                        this.text.directDraw(false);
                    }
                }
            }

            public float getRenderRadius() {
                return Float.MAX_VALUE;
            }

            public EnumSet<CombatEngineLayers> getActiveLayers() {
                return EnumSet.allOf(CombatEngineLayers.class);
            }
        }
    }
}