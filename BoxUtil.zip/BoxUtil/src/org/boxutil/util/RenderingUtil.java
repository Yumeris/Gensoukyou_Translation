package org.boxutil.util;

import com.fs.starfarer.api.campaign.CampaignEngineLayers;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.boxutil.base.api.InstanceDataAPI;
import org.boxutil.config.BoxConfigs;
import org.boxutil.define.BoxEnum;
import org.boxutil.manager.CampaignRenderingManager;
import org.boxutil.manager.CombatRenderingManager;
import org.boxutil.units.standard.attribute.Instance2Data;
import org.boxutil.units.standard.attribute.NodeData;
import org.boxutil.units.standard.entity.CurveEntity;
import org.boxutil.units.standard.entity.FlareEntity;
import org.boxutil.units.standard.entity.SpriteEntity;
import org.boxutil.units.standard.entity.TextFieldEntity;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public final class RenderingUtil {
    private static final CombatEngineLayers[] _COMBAT_LAYER = CombatEngineLayers.values();
    private static final HashMap<CombatEngineLayers, Integer> _COMBAT_LAYER_LINKED = new HashMap<>();
    private static final CombatEngineLayers _COMBAT_HIGHEST_LAYER = _COMBAT_LAYER[_COMBAT_LAYER.length - 1];
    private static final CombatEngineLayers _COMBAT_LOWEST_LAYER = _COMBAT_LAYER[0];
    private static final CampaignEngineLayers[] _CAMPAIGN_LAYER = CampaignEngineLayers.values();
    private static final HashMap<CampaignEngineLayers, Integer> _CAMPAIGN_LAYER_LINKED = new HashMap<>();
    private static final CampaignEngineLayers _CAMPAIGN_HIGHEST_LAYER = _CAMPAIGN_LAYER[_CAMPAIGN_LAYER.length - 1];
    private static final CampaignEngineLayers _CAMPAIGN_LOWEST_LAYER = _CAMPAIGN_LAYER[0];
    static {
        for (int i = 0; i < _COMBAT_LAYER.length; i++) {
            _COMBAT_LAYER_LINKED.put(_COMBAT_LAYER[i], i);
        }
        for (int i = 0; i < _CAMPAIGN_LAYER.length; i++) {
            _CAMPAIGN_LAYER_LINKED.put(_CAMPAIGN_LAYER[i], i);
        }
    }

    public static CombatEngineLayers getHighestCombatLayer() {
        return _COMBAT_HIGHEST_LAYER;
    }

    public static CombatEngineLayers getLowestCombatLayer() {
        return _COMBAT_LOWEST_LAYER;
    }

    public static CampaignEngineLayers getHighestCampaignLayer() {
        return _CAMPAIGN_HIGHEST_LAYER;
    }

    public static CampaignEngineLayers getLowestCampaignLayer() {
        return _CAMPAIGN_LOWEST_LAYER;
    }

    public static CombatEngineLayers getPreCombatLayer(CombatEngineLayers layer) {
        int index = _COMBAT_LAYER_LINKED.get(layer) - 1;
        return _COMBAT_LAYER[index < 0 ? _COMBAT_LAYER.length - 1 : index];
    }

    public static CombatEngineLayers getNextCombatLayer(CombatEngineLayers layer) {
        int index = _COMBAT_LAYER_LINKED.get(layer) + 1;
        return _COMBAT_LAYER[index >= _COMBAT_LAYER.length ? 0 : index];
    }

    public static CampaignEngineLayers getPreCampaignLayer(CampaignEngineLayers layer) {
        int index = _CAMPAIGN_LAYER_LINKED.get(layer) - 1;
        return _CAMPAIGN_LAYER[index < 0 ? _CAMPAIGN_LAYER.length - 1 : index];
    }

    public static CampaignEngineLayers getNextCampaignLayer(CampaignEngineLayers layer) {
        int index = _CAMPAIGN_LAYER_LINKED.get(layer) + 1;
        return _CAMPAIGN_LAYER[index >= _CAMPAIGN_LAYER.length ? 0 : index];
    }

    public static CurveEntity createBeamVisual(Vector2f location, float facing, float length, float width, Color color, @Nullable Color emissiveColor, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, boolean isAdditiveBlend) {
        if (emissiveColor == null) emissiveColor = Color.WHITE;
        CurveEntity entity = new CurveEntity().initLine(null, length, color, emissiveColor, width);
        entity.setGlobalTimer(fadeIn, full, fadeOut);
        if (isAdditiveBlend) entity.setAdditiveBlend();
        entity.getMaterialData().setDiffuse(diffuse);
        if (emissive != null) entity.getMaterialData().setEmissive(emissive);
        entity.submitNodes();
        TransformUtil.createModelMatrixVanilla(location, facing, entity.getModelMatrix());
        return entity;
    }

    public static Pair<CurveEntity, Byte> addCampaignBeamVisual(Vector2f location, float facing, float length, float width, Color color, SpriteAPI diffuse, float full, float fadeOut, CampaignEngineLayers layer) {
        return addCampaignBeamVisual(location, facing, length, width, color, null, diffuse, null, 0.0f, full, fadeOut, true, layer);
    }

    public static Pair<CurveEntity, Byte> addCampaignBeamVisual(Vector2f location, float facing, float length, float width, Color color, @Nullable Color emissiveColor, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, boolean isAdditiveBlend, CampaignEngineLayers layer) {
        CurveEntity entity = createBeamVisual(location, facing, length, width, color, emissiveColor, diffuse, emissive, fadeIn, full, fadeOut, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CampaignRenderingManager.addEntity(BoxEnum.ENTITY_CURVE, entity));
    }

    public static Pair<CurveEntity, Byte> addCombatBeamVisual(Vector2f location, float facing, float length, float width, Color color, SpriteAPI diffuse, float full, float fadeOut, CombatEngineLayers layer) {
        return addCombatBeamVisual(location, facing, length, width, color, null, diffuse, null, 0.0f, full, fadeOut, true, layer);
    }

    public static Pair<CurveEntity, Byte> addCombatBeamVisual(Vector2f location, float facing, float length, float width, Color color, @Nullable Color emissiveColor, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, boolean isAdditiveBlend, CombatEngineLayers layer) {
        CurveEntity entity = createBeamVisual(location, facing, length, width, color, emissiveColor, diffuse, emissive, fadeIn, full, fadeOut, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CombatRenderingManager.addEntity(BoxEnum.ENTITY_CURVE, entity));
    }

    public static SpriteEntity createParticleField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f velocityRange, @Nullable Vector2f facingRange, @Nullable Vector2f turnRateRange, Vector4f sizeRangeXY, @Nullable Vector4f sizeGrowScaleRangeXY, @Nullable Color baseColor, @Nullable Color baseColorShift, @Nullable Color baseEmissiveColor, @Nullable Color baseEmissiveColorShift, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend) {
        SpriteEntity entity = new SpriteEntity();
        if (baseColor == null) baseColor = Color.WHITE;
        if (baseEmissiveColor == null) baseEmissiveColor = Color.WHITE;
        if (isAdditiveBlend) entity.setAdditiveBlend();
        entity.getMaterialData().setDiffuse(diffuse);
        if (emissive != null) entity.getMaterialData().setEmissive(emissive);
        TransformUtil.createModelMatrixVanilla(location, facing, entity.getModelMatrix());

        final int finalCount = Math.min(BoxConfigs.getMaxInstanceDataSize(), count);
        final float finalArc = arc / 2.0f;
        final boolean haveColorShift = baseColorShift != null;
        final boolean haveEmissiveColorShift = baseEmissiveColorShift != null;
        final boolean haveSpreadRange = baseSpreadRange != null;
        final boolean haveVelocityRange = velocityRange != null;
        List<InstanceDataAPI> dataList = new ArrayList<>();
        for (int i = 0; i < finalCount; i++) {
            float factor = (float) Math.random();
            float factor2 = (float) Math.random();
            float timerOffset = timerOffsetRange * factor;
            Instance2Data data = new Instance2Data();
            float angle = facing + finalArc * (factor2 * 2.0f - 1.0f);
            if (angle < 0.0f) angle += 360.0f;
            if (angle > 360.0f) angle -= 360.0f;
            float baseX = (float) Math.cos(Math.toRadians(angle));
            float baseY = TrigUtil.sinFormCosF(baseX, angle);
            Color finalColor;
            if (haveColorShift) {
                finalColor = CalculateUtil.mix(baseColor, baseColorShift, true, factor);
            } else finalColor = baseColor;
            Color finalEmissiveColor;
            if (haveEmissiveColorShift) {
                finalEmissiveColor = CalculateUtil.mix(baseEmissiveColor, baseEmissiveColorShift, true, factor);
            } else finalEmissiveColor = baseEmissiveColor;
            if (haveSpreadRange) {
                float locationLength = (baseSpreadRange.y - baseSpreadRange.x) * factor + baseSpreadRange.x;
                data.setLocation(locationLength * baseX, locationLength * baseY);
            }
            if (haveVelocityRange) {
                float velocityLength = (velocityRange.x - velocityRange.y) * factor + velocityRange.x;
                data.setVelocity(velocityLength * baseX, velocityLength * baseY);
            }
            float sizeX = (sizeRangeXY.z - sizeRangeXY.x) * factor + sizeRangeXY.x;
            float sizeY = (sizeRangeXY.w - sizeRangeXY.y) * factor + sizeRangeXY.y;
            data.setScale(sizeX * 0.5f, sizeY * 0.5f);
            if (sizeGrowScaleRangeXY != null) {
                float growX = (sizeGrowScaleRangeXY.z - sizeGrowScaleRangeXY.x) * factor + sizeGrowScaleRangeXY.x;
                float growY = (sizeGrowScaleRangeXY.w - sizeGrowScaleRangeXY.y) * factor + sizeGrowScaleRangeXY.y;
                data.setScaleRate(growX * 0.5f, growY * 0.5f);
            }
            data.setColor(finalColor);
            data.setEmissiveColor(finalEmissiveColor);
            if (facingRange != null) data.setFacing((facingRange.y - facingRange.x) * factor + facingRange.x);
            if (turnRateRange != null) data.setTurnRate((turnRateRange.y - turnRateRange.x) * factor + turnRateRange.x);
            data.setTimer(fadeIn + timerOffset, full + timerOffset, fadeOut + timerOffset);
            dataList.add(data);
        }
        float timerOffsetCheck = Math.max(timerOffsetRange, 0.0f);
        entity.setInstanceData(dataList, fadeIn + timerOffsetCheck, full + timerOffsetCheck, fadeOut + timerOffsetCheck);
        entity.setInstanceDataRefreshAllFromCurrentIndex();
        entity.submitInstanceData();
        entity.setRenderingCount(finalCount);
        entity.setAlwaysRefreshInstanceData(true);
        return entity;
    }

    public static Pair<SpriteEntity, Byte> addCampaignParticleField(Vector2f location, int count, float facing, float arc, float fieldRadius, Vector4f sizeRangeXY, @Nullable Color baseColor, SpriteAPI diffuse, float full, float fadeOut, CampaignEngineLayers layer) {
        return addCampaignParticleField(location, count, facing, arc, null, new Vector2f(0.0f, fieldRadius), new Vector2f(0.0f, 360.0f), null, sizeRangeXY, null, baseColor, null, null, null, diffuse, null, 0.0f, full, fadeOut, 0.0f, true, layer);
    }

    public static Pair<SpriteEntity, Byte> addCampaignParticleField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f velocityRange, @Nullable Vector2f facingRange, @Nullable Vector2f turnRateRange, Vector4f sizeRangeXY, @Nullable Vector4f sizeGrowScaleRangeXY, @Nullable Color baseColor, @Nullable Color baseColorShift, @Nullable Color baseEmissiveColor, @Nullable Color baseEmissiveColorShift, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend, CampaignEngineLayers layer) {
        SpriteEntity entity = createParticleField(location, count, facing, arc, baseSpreadRange, velocityRange, facingRange, turnRateRange, sizeRangeXY, sizeGrowScaleRangeXY, baseColor, baseColorShift, baseEmissiveColor, baseEmissiveColorShift, diffuse, emissive, fadeIn, full, fadeOut, timerOffsetRange, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CampaignRenderingManager.addEntity(BoxEnum.ENTITY_SPRITE, entity));
    }

    public static Pair<SpriteEntity, Byte> addCombatParticleField(Vector2f location, int count, float facing, float arc, float fieldRadius, Vector4f sizeRangeXY, @Nullable Color baseColor, SpriteAPI diffuse, float full, float fadeOut, CombatEngineLayers layer) {
        return addCombatParticleField(location, count, facing, arc, null, new Vector2f(0.0f, fieldRadius), new Vector2f(0.0f, 360.0f), null, sizeRangeXY, null, baseColor, null, null, null, diffuse, null, 0.0f, full, fadeOut, 0.0f, true, layer);
    }

    public static Pair<SpriteEntity, Byte> addCombatParticleField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f velocityRange, @Nullable Vector2f facingRange, @Nullable Vector2f turnRateRange, Vector4f sizeRangeXY, @Nullable Vector4f sizeGrowScaleRangeXY, @Nullable Color baseColor, @Nullable Color baseColorShift, @Nullable Color baseEmissiveColor, @Nullable Color baseEmissiveColorShift, SpriteAPI diffuse, @Nullable SpriteAPI emissive, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend, CombatEngineLayers layer) {
        SpriteEntity entity = createParticleField(location, count, facing, arc, baseSpreadRange, velocityRange, facingRange, turnRateRange, sizeRangeXY, sizeGrowScaleRangeXY, baseColor, baseColorShift, baseEmissiveColor, baseEmissiveColorShift, diffuse, emissive, fadeIn, full, fadeOut, timerOffsetRange, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CombatRenderingManager.addEntity(BoxEnum.ENTITY_SPRITE, entity));
    }

    public static FlareEntity createFlareField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f facingRange, Vector4f sizeRangeXY, @Nullable Color baseFringeColor, @Nullable Color baseFringeColorShift, @Nullable Color baseCoreColor, @Nullable Color baseCoreColorShift, boolean flick, boolean syncFlick, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend) {
        FlareEntity entity = new FlareEntity();
        if (baseFringeColor == null) baseFringeColor = Color.WHITE;
        if (baseCoreColor == null) baseCoreColor = Color.WHITE;
        entity.setFlick(flick);
        entity.setSyncFlick(syncFlick);
        entity.setAspect((sizeRangeXY.x + sizeRangeXY.z) / (sizeRangeXY.y + sizeRangeXY.w));
        if (isAdditiveBlend) entity.setAdditiveBlend();
        TransformUtil.createModelMatrixVanilla(location, facing, entity.getModelMatrix());

        final int finalCount = Math.min(BoxConfigs.getMaxInstanceDataSize(), count);
        final float finalArc = arc / 2.0f;
        final boolean haveFringeColorShift = baseFringeColorShift != null;
        final boolean haveCoreColorShift = baseCoreColorShift != null;
        final boolean haveSpreadRange = baseSpreadRange != null;
        List<InstanceDataAPI> dataList = new ArrayList<>();
        for (int i = 0; i < finalCount; i++) {
            float factor = (float) Math.random();
            float factor2 = (float) Math.random();
            float timerOffset = timerOffsetRange * factor;
            Instance2Data data = new Instance2Data();
            float angle = facing + finalArc * (factor2 * 2.0f - 1.0f);
            if (angle < 0.0f) angle += 360.0f;
            if (angle > 360.0f) angle -= 360.0f;
            float baseX = (float) Math.cos(Math.toRadians(angle));
            float baseY = TrigUtil.sinFormCosF(baseX, angle);
            Color finalFringeColor;
            if (haveFringeColorShift) {
                finalFringeColor = CalculateUtil.mix(baseFringeColor, baseFringeColorShift, true, factor);
            } else finalFringeColor = baseFringeColor;
            Color finalCoreColor;
            if (haveCoreColorShift) {
                finalCoreColor = CalculateUtil.mix(baseCoreColor, baseCoreColorShift, true, factor);
            } else finalCoreColor = baseCoreColor;
            if (haveSpreadRange) {
                float locationLength = (baseSpreadRange.y - baseSpreadRange.x) * factor + baseSpreadRange.x;
                data.setLocation(locationLength * baseX, locationLength * baseY);
            }
            float sizeX = (sizeRangeXY.z - sizeRangeXY.x) * factor + sizeRangeXY.x;
            float sizeY = (sizeRangeXY.w - sizeRangeXY.y) * factor + sizeRangeXY.y;
            data.setScale(sizeX * 0.5f, sizeY * 0.5f);
            data.setColor(finalFringeColor);
            data.setEmissiveColor(finalCoreColor);
            if (facingRange != null) data.setFacing((facingRange.y - facingRange.x) * factor + facingRange.x);
            data.setTimer(fadeIn + timerOffset, full + timerOffset, fadeOut + timerOffset);
            dataList.add(data);
        }
        float timerOffsetCheck = Math.max(timerOffsetRange, 0.0f);
        entity.setInstanceData(dataList, fadeIn + timerOffsetCheck, full + timerOffsetCheck, fadeOut + timerOffsetCheck);
        entity.setInstanceDataRefreshAllFromCurrentIndex();
        entity.submitInstanceData();
        entity.setRenderingCount(finalCount);
        entity.setAlwaysRefreshInstanceData(true);
        return entity;
    }

    public static Pair<FlareEntity, Byte> addCampaignFlareField(Vector2f location, int count, float facing, float arc, float fieldRadius, Vector4f sizeRangeXY, @Nullable Color fringeColor, @Nullable Color coreColor, float full, float fadeOut, CampaignEngineLayers layer) {
        return addCampaignFlareField(location, count, facing, arc, new Vector2f(0.0f, fieldRadius), null, sizeRangeXY, fringeColor, null, coreColor, null, true, false, 0.0f, full, fadeOut, 0.0f, true, layer);
    }

    public static Pair<FlareEntity, Byte> addCampaignFlareField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f facingRange, Vector4f sizeRangeXY, @Nullable Color baseFringeColor, @Nullable Color baseFringeColorShift, @Nullable Color baseCoreColor, @Nullable Color baseCoreColorShift, boolean flick, boolean syncFlick, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend, CampaignEngineLayers layer) {
        FlareEntity entity = createFlareField(location, count, facing, arc, baseSpreadRange, facingRange, sizeRangeXY, baseFringeColor, baseFringeColorShift, baseCoreColor, baseCoreColorShift, flick, syncFlick, fadeIn, full, fadeOut, timerOffsetRange, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CampaignRenderingManager.addEntity(BoxEnum.ENTITY_FLARE, entity));
    }

    public static Pair<FlareEntity, Byte> addCombatFlareField(Vector2f location, int count, float facing, float arc, float fieldRadius, Vector4f sizeRangeXY, @Nullable Color fringeColor, @Nullable Color coreColor, float full, float fadeOut, CombatEngineLayers layer) {
        return addCombatFlareField(location, count, facing, arc, new Vector2f(0.0f, fieldRadius), null, sizeRangeXY, fringeColor, null, coreColor, null, true, false, 0.0f, full, fadeOut, 0.0f, true, layer);
    }

    public static Pair<FlareEntity, Byte> addCombatFlareField(Vector2f location, int count, float facing, float arc, @Nullable Vector2f baseSpreadRange, @Nullable Vector2f facingRange, Vector4f sizeRangeXY, @Nullable Color baseFringeColor, @Nullable Color baseFringeColorShift, @Nullable Color baseCoreColor, @Nullable Color baseCoreColorShift, boolean flick, boolean syncFlick, float fadeIn, float full, float fadeOut, float timerOffsetRange, boolean isAdditiveBlend, CombatEngineLayers layer) {
        FlareEntity entity = createFlareField(location, count, facing, arc, baseSpreadRange, facingRange, sizeRangeXY, baseFringeColor, baseFringeColorShift, baseCoreColor, baseCoreColorShift, flick, syncFlick, fadeIn, full, fadeOut, timerOffsetRange, isAdditiveBlend);
        entity.setLayer(layer);
        return new Pair<>(entity, CombatRenderingManager.addEntity(BoxEnum.ENTITY_FLARE, entity));
    }

    public static TextFieldEntity createTextField(@NotNull String fontPath, float width, float height, @NotNull String text, float padding, Color baseColor, boolean italic, boolean underline, boolean strikeout, Color highlightColor, String... highlight) {
        TextFieldEntity entity = new TextFieldEntity(fontPath);
        float pad = padding;
        String[] splits = text.split("%s");
        String split;
        String hlText;
        for (int i = 0; i < splits.length; i++) {
            split = splits[i];
            entity.addText(split, pad, baseColor, false, italic, underline, strikeout, 0);
            if (i == (splits.length - 1)) break;
            if (i == 0) pad = 0.0f;
            hlText = (highlight != null && i < highlight.length) ? highlight[i] : "null";
            entity.addText(hlText, 0.0f, highlightColor, false, italic, underline, strikeout, 0);
        }
        entity.setFieldSize(width, height);
        entity.setTextDataRefreshAllFromCurrentIndex();
        entity.submitText();
        return entity;
    }

    public static TextFieldEntity createTextField(@NotNull String fontPath, float width, float height, @NotNull String text, float padding, Color baseColor, Color highlightColor, String... highlight) {
        return createTextField(fontPath, width, height, text, padding, baseColor, false, false, false, highlightColor, highlight);
    }

    public static TextFieldEntity createTextField(@NotNull String fontPath, float width, float height, @NotNull String text, float padding, Color baseColor) {
        return createTextField(fontPath, width, height, text, padding, baseColor, Misc.getHighlightColor(), (String) null);
    }

    public static TextFieldEntity createTextField(@NotNull String fontPath, float width, float height, @NotNull String text) {
        return createTextField(fontPath, width, height, text, 0.0f, Misc.getTextColor(), Misc.getHighlightColor(), (String) null);
    }

    /**
     * Pick a node between two nodeList.
     */
    public static NodeData nodeInterpolation(@NotNull NodeData left, @NotNull NodeData right, float factor) {
        if (factor == 0.0f) return left;
        if (factor == 1.0f) return right;
        float factor2 = factor * factor;
        float factor3 = factor2 * factor2;
        float oneMinusF1 = 1.0f - factor;
        float[] tmp0 = CalculateUtil.mul(left.getLocationArrayDirect(), oneMinusF1 * oneMinusF1 * oneMinusF1);
        float[] tmp1 = CalculateUtil.mul(CalculateUtil.add(left.getLocationArrayDirect(), left.getTangentRightArrayDirect()), (factor3 - factor2 - factor2 + factor) * 3.0f);
        float[] tmp2 = CalculateUtil.mul(CalculateUtil.add(right.getLocationArrayDirect(), right.getTangentRightArrayDirect()), (factor2 - factor3) * 3.0f);
        float[] tmp3 = CalculateUtil.mul(left.getLocationArrayDirect(), factor3);
        float[] location = CalculateUtil.addAll(tmp0, tmp1, tmp2, tmp3);
        float[] leftTangent = CalculateUtil.mix(left.getTangentLeftArrayDirect(), right.getTangentLeftArrayDirect(), factor);
        float[] rightTangent = CalculateUtil.mix(left.getTangentRightArrayDirect(), right.getTangentRightArrayDirect(), factor);
        byte[] colorState = CalculateUtil.mix(left.getColorState(), right.getColorState(), factor);
        NodeData out = new NodeData();
        out.setLocationDirect(location[0], location[1]);
        out.setTangentLeftDirect(leftTangent[0], leftTangent[1]);
        out.setTangentRightDirect(rightTangent[0], rightTangent[1]);
        out.setColor(colorState[0], colorState[1], colorState[2], colorState[3]);
        out.setEmissiveColor(colorState[4], colorState[5], colorState[6], colorState[7]);
        out.setWidth(CalculateUtil.mix(left.getWidth(), right.getWidth(), factor));
        out.setMixFactor(CalculateUtil.mix(left.getMixFactor(), right.getMixFactor(), factor));
        return out;
    }

    private RenderingUtil() {}
}
