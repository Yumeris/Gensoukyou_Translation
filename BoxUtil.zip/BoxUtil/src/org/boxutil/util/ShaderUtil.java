package org.boxutil.util;

import com.fs.starfarer.api.Global;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.apache.log4j.Level;
import org.boxutil.define.BoxDatabase;
import org.boxutil.manager.ShaderCore;
import org.lwjgl.opengl.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public final class ShaderUtil {
    private final static HashMap<Integer, String> _SHADER_TYPE = new HashMap<>();
    private final static HashMap<String, Integer> _SHADER_FORMAT = new HashMap<>();
    static {
        _SHADER_TYPE.put(GL20.GL_VERTEX_SHADER, "Vertex");
        _SHADER_TYPE.put(GL40.GL_TESS_CONTROL_SHADER, "Tess-Control");
        _SHADER_TYPE.put(GL40.GL_TESS_EVALUATION_SHADER, "Tess-Evaluation");
        _SHADER_TYPE.put(GL32.GL_GEOMETRY_SHADER, "Geometry");
        _SHADER_TYPE.put(GL20.GL_FRAGMENT_SHADER, "Fragment");
        _SHADER_TYPE.put(GL43.GL_COMPUTE_SHADER, "Compute");
        _SHADER_FORMAT.put("vert", GL20.GL_VERTEX_SHADER);
        _SHADER_FORMAT.put("vsh", GL20.GL_VERTEX_SHADER);
        _SHADER_FORMAT.put("tesc", GL40.GL_TESS_CONTROL_SHADER);
        _SHADER_FORMAT.put("tese", GL40.GL_TESS_EVALUATION_SHADER);
        _SHADER_FORMAT.put("geom", GL32.GL_GEOMETRY_SHADER);
        _SHADER_FORMAT.put("gsh", GL32.GL_GEOMETRY_SHADER);
        _SHADER_FORMAT.put("frag", GL20.GL_FRAGMENT_SHADER);
        _SHADER_FORMAT.put("fsh", GL20.GL_FRAGMENT_SHADER);
        _SHADER_FORMAT.put("comp", GL43.GL_COMPUTE_SHADER);
        _SHADER_FORMAT.put("csh", GL43.GL_COMPUTE_SHADER);
    }

    public static String getShaderName(int type) {
        if (!_SHADER_TYPE.containsKey(type)) return "Shader type '" + type + "' not found.";
        return _SHADER_TYPE.get(type);
    }

    public static int getTypeFromPath(@NotNull String path) {
        String[] sp = path.split("\\.");
        String format = sp[sp.length - 1];
        return getTypeFromFormat(format);
    }

    public static int getTypeFromFormat(@NotNull String format) {
        String lower = format.toLowerCase();
        if (!_SHADER_FORMAT.containsKey(lower)) return GL11.GL_ZERO;
        return _SHADER_FORMAT.get(lower);
    }

    /**
     * For usual to creating shader program.
     */
    public static int createShaderVFFormPath(@Nullable String loggerTag, String vertPath, String fragPath) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        String vertLocal, fragLocal;
        try {
            vertLocal = Global.getSettings().loadText(vertPath);
            fragLocal = Global.getSettings().loadText(fragPath);
        } catch (IOException ex) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader file(s) loading error." + ex.getMessage());
            return 0;
        }
        return createShaderVF(tag, vertLocal, fragLocal);
    }

    /**
     * For usual to creating shader program.
     */
    public static int createShaderVF(@Nullable String loggerTag, String vert, String frag) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL20) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported shader program.");
            return 0;
        }
        return createShaderProgram(tag, new int[]{GL20.GL_VERTEX_SHADER, GL20.GL_FRAGMENT_SHADER}, vert, frag);
    }

    public static int createShaderVGF(@Nullable String loggerTag, String vert, String geom, String frag) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL32 || !GLContext.getCapabilities().GL_ARB_geometry_shader4) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported OpenGL3.2.");
            return 0;
        }
        return createShaderProgram(tag, new int[]{GL20.GL_VERTEX_SHADER, GL32.GL_GEOMETRY_SHADER, GL20.GL_FRAGMENT_SHADER}, vert, geom, frag);
    }

    public static int createShaderVTF(@Nullable String loggerTag, String vert, String tessC, String tessE, String frag) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL40 || !GLContext.getCapabilities().GL_ARB_tessellation_shader) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported OpenGL4.0.");
            return 0;
        }
        return createShaderProgram(tag, new int[]{GL20.GL_VERTEX_SHADER, GL40.GL_TESS_CONTROL_SHADER, GL40.GL_TESS_EVALUATION_SHADER, GL20.GL_FRAGMENT_SHADER}, vert, tessC, tessE, frag);
    }

    public static int createShaderVTGF(@Nullable String loggerTag, String vert, String tessC, String tessE, String geom, String frag) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL40 || !GLContext.getCapabilities().GL_ARB_geometry_shader4 || !GLContext.getCapabilities().GL_ARB_tessellation_shader) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported OpenGL4.0.");
            return 0;
        }
        return createShaderProgram(tag, new int[]{GL20.GL_VERTEX_SHADER, GL40.GL_TESS_CONTROL_SHADER, GL40.GL_TESS_EVALUATION_SHADER, GL32.GL_GEOMETRY_SHADER, GL20.GL_FRAGMENT_SHADER}, vert, tessC, tessE, geom, frag);
    }

    /**
     * 1-step get a shader program.
     */
    public static int createComputeShadersFormPath(@Nullable String loggerTag, String... shadersPath) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        String[] sources = new String[shadersPath.length];
        try {
            for (int i = 0; i < shadersPath.length; i++) {
                sources[i] = Global.getSettings().loadText(shadersPath[i]);
            }
        } catch (IOException ex) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader file(s) loading error." + ex.getMessage());
            return 0;
        }
        return createComputeShaders(tag, sources);
    }

    public static int createComputeShaders(@Nullable String loggerTag, String... source) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL43 && GLContext.getCapabilities().GL_ARB_compute_shader) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported OpenGL4.3.");
            return 0;
        }
        int[] types = new int[source.length];
        Arrays.fill(types, GL43.GL_COMPUTE_SHADER);
        return createShaderProgram(tag, types, source);
    }

    /**
     * @param loggerTag for locating in log when created or failed.
     */
    public static int createShader(@Nullable String loggerTag, String shader, int shaderType) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (!GLContext.getCapabilities().OpenGL20) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported shader program.");
            return 0;
        }
        String shaderTypeGetter = ShaderUtil._SHADER_TYPE.containsKey(shaderType) ? ShaderUtil._SHADER_TYPE.get(shaderType) : String.valueOf(shaderType);
        int shaderID = GL20.glCreateShader(shaderType);
        GL20.glShaderSource(shaderID, shader);
        GL20.glCompileShader(shaderID);
        if (GL20.glGetShaderi(shaderID, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader type '" + shaderTypeGetter + "' compilation failed:\n" + GL20.glGetShaderInfoLog(shaderID, GL20.glGetShaderi(shaderID, GL20.GL_INFO_LOG_LENGTH)));
            GL20.glDeleteShader(shaderID);
            return 0;
        } else {
            return shaderID;
        }
    }

    /**
     * @param loggerTag for locating in log when created or failed.
     */
    public static int createShaderProgramFromPath(@Nullable String loggerTag, String... shadersPath) {
        String tag = loggerTag == null ? "None marked" : loggerTag;
        int length = shadersPath.length;
        int[] types = new int[length];
        String[] sources = new String[length];
        try {
            for (int i = 0; i < length; i++) {
                String path = shadersPath[i];
                int type = getTypeFromPath(path);
                if (type == 0) {
                    Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
                    Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' error file format at: '" + path + "'.");
                    return 0;
                }
                sources[i] = Global.getSettings().loadText(path);
                types[i] = type;
            }
        } catch (IOException ex) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader file(s) loading error." + ex.getMessage());
            return 0;
        }
        return createShaderProgram(loggerTag, types, sources);
    }

    /**
     * @param loggerTag for locating in log when created or failed.
     */
    public static int createShaderProgram(@Nullable String loggerTag, int[] types, String... shaders) {
        if (!GLContext.getCapabilities().OpenGL20) {
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' platform is not supported OpenGL2.0.");
            return 0;
        }
        String tag = loggerTag == null ? "None marked" : loggerTag;
        if (shaders.length != types.length || shaders.length == 0) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader file's list's length and shader type list's length is mismatching.");
            return 0;
        }
        List<Integer> tmpShaders = new ArrayList<>();
        int programID = GL20.glCreateProgram();
        for (int i = 0; i < shaders.length; i++) {
            int shaderID = createShader(loggerTag, shaders[i], types[i]);
            if (shaderID == 0) {
                String shaderTypeGetter = ShaderUtil._SHADER_TYPE.containsKey(types[i]) ? ShaderUtil._SHADER_TYPE.get(types[i]) : String.valueOf(types[i]);
                Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader file error with type: '" + shaderTypeGetter + "', creating program has canceled.");
                GL20.glDeleteProgram(programID);
                return 0;
            }
            GL20.glAttachShader(programID, shaderID);
            tmpShaders.add(shaderID);
        }
        GL20.glLinkProgram(programID);

        if (GL20.glGetProgrami(programID, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader program tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).log(Level.ERROR, "'Box Util' shader program linking failed:\n" + GL20.glGetProgramInfoLog(programID, GL20.glGetProgrami(programID, GL20.GL_INFO_LOG_LENGTH)));
            GL20.glDeleteProgram(programID);
            if (!tmpShaders.isEmpty()) {
                for (int toDelete : tmpShaders) {
                    GL20.glDetachShader(programID, toDelete);
                    GL20.glDeleteShader(toDelete);
                }
            }
            return 0;
        } else {
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader creating tag: '" + tag + "'.");
            Global.getLogger(ShaderUtil.class).info("'Box Util' shader program has created.");
            return programID;
        }
    }

    public static long createBindlessTexture(int texture) {
        if (texture == 0) return 0;
        long id = 0;
        if (BoxDatabase.getGLState().GL_BINDLESS_TEXTURE) {
            if (GLContext.getCapabilities().GL_NV_bindless_texture) {
                id = NVBindlessTexture.glGetTextureHandleNV(texture);
                if (id != 0 && !NVBindlessTexture.glIsTextureHandleResidentNV(id)) NVBindlessTexture.glMakeTextureHandleResidentNV(id);;
            } else {
                id = ARBBindlessTexture.glGetTextureHandleARB(texture);
                if (id != 0 && !ARBBindlessTexture.glIsTextureHandleResidentARB(id)) ARBBindlessTexture.glMakeTextureHandleResidentARB(id);
            }
        }
        return id;
    }

    public static long createBindlessImage(int texture, int internalFormat) {
        return createBindlessImage(texture, 0, false, 0, GL15.GL_READ_WRITE, internalFormat);
    }

    public static long createBindlessImage(int texture, int level, boolean layered, int layer, int access, int internalFormat) {
        if (texture == 0) return 0;
        long id = 0;
        if (BoxDatabase.getGLState().GL_BINDLESS_TEXTURE) {
            if (GLContext.getCapabilities().GL_NV_bindless_texture) {
                id = NVBindlessTexture.glGetImageHandleNV(texture, level, layered, layer, internalFormat);
                if (id != 0 && !NVBindlessTexture.glIsImageHandleResidentNV(id))  NVBindlessTexture.glMakeImageHandleResidentNV(id, access);
            } else {
                id = ARBBindlessTexture.glGetImageHandleARB(texture, level, layered, layer, internalFormat);
                if (id != 0 && !ARBBindlessTexture.glIsImageHandleResidentARB(id)) ARBBindlessTexture.glMakeImageHandleResidentARB(id, access);
            }
        }
        return id;
    }

    public static void releaseBindlessTexture(long texture) {
        if (texture == 0) return;
        if (BoxDatabase.getGLState().GL_BINDLESS_TEXTURE) {
            if (GLContext.getCapabilities().GL_NV_bindless_texture) {
                if (NVBindlessTexture.glIsTextureHandleResidentNV(texture)) NVBindlessTexture.glMakeTextureHandleNonResidentNV(texture);
            } else {
                if (ARBBindlessTexture.glIsTextureHandleResidentARB(texture)) ARBBindlessTexture.glMakeTextureHandleNonResidentARB(texture);
            }
        }
    }

    public static void releaseBindlessImage(long image) {
        if (image == 0) return;
        if (BoxDatabase.getGLState().GL_BINDLESS_TEXTURE) {
            if (GLContext.getCapabilities().GL_NV_bindless_texture) {
                if (NVBindlessTexture.glIsImageHandleResidentNV(image)) NVBindlessTexture.glMakeImageHandleNonResidentNV(image);
            } else {
                if (ARBBindlessTexture.glIsImageHandleResidentARB(image)) ARBBindlessTexture.glMakeImageHandleNonResidentARB(image);
            }
        }
    }

    public static void blitFBO(int read, int draw, int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1) {
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, read);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, draw);
        GL30.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, 0);
    }

    public static void blitFBO(int read, int draw, int srcX1, int srcY1, int dstX1, int dstY1) {
        blitFBO(read, draw, 0, 0, srcX1, srcY1, 0, 0, dstX1, dstY1);
    }

    public static void blitFBO(int read, int draw, int width, int height) {
        blitFBO(read, draw, 0, 0, width, height, 0, 0, width, height);
    }

    public static void blitFBO(int read, int draw) {
        final int width = ShaderCore.getScreenScaleWidth();
        final int height = ShaderCore.getScreenScaleHeight();
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, read);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, draw);
        GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, 0);
    }

    public static void copyFromScreen(int fbo) {
        final int width = ShaderCore.getScreenScaleWidth();
        final int height = ShaderCore.getScreenScaleHeight();
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, fbo);
        GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, 0);
    }

    public static void blitToScreen(int fbo) {
        final int width = ShaderCore.getScreenScaleWidth();
        final int height = ShaderCore.getScreenScaleHeight();
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, 0);
        GL30.glBlitFramebuffer(0, 0, width, height, 0, 0, width, height, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, 0);
    }

    private ShaderUtil() {}
}
