package org.boxutil.util;

/**
 * All angle value must be <strong>[0, 360]</strong>.<p>
 * For avoid some calculation of trigonometric functions.
 */
public final class TrigUtil {
    public static double sinFormCosD(double cosValue, float angle) {
        double out = Math.sqrt(1.0d - (cosValue * cosValue));
        if (angle > 180.0f) out = -out;
        return out;
    }

    public static float sinFormCosF(float cosValue, float angle) {
        float out = (float) Math.sqrt(1.0f - (cosValue * cosValue));
        if (angle > 180.0f) out = -out;
        return out;
    }

    public static double sinFormTanD(double tanValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0d;
        double out = tanValue / Math.sqrt(1.0d + (tanValue * tanValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static float sinFormTanF(float tanValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0f;
        float out = tanValue / (float) Math.sqrt(1.0f + (tanValue * tanValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static double cosFormSinD(double sinValue, float angle) {
        double out = Math.sqrt(1.0d - (sinValue * sinValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static float cosFormSinF(float sinValue, float angle) {
        float out = (float) Math.sqrt(1.0f - (sinValue * sinValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static double cosFormTanD(double tanValue, float angle) {
        if (angle == 0.0f || angle == 270.0f) return 0.0d;
        double out = 1.0d / Math.sqrt(1.0d + (tanValue * tanValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static float cosFormTanF(float tanValue, float angle) {
        if (angle == 0.0f || angle == 270.0f) return 0.0f;
        float out = 1.0f / (float) Math.sqrt(1.0f + (tanValue * tanValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }


    public static double tanFormSinD(double sinValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0d;
        double out = sinValue / Math.sqrt(1.0d - (sinValue * sinValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static float tanFormSinF(float sinValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0f;
        float out = sinValue / (float) Math.sqrt(1.0f - (sinValue * sinValue));
        if (angle > 90.0f && angle < 270.0f) out = -out;
        return out;
    }

    public static double tanFormCosD(double cosValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0d;
        double out = Math.sqrt(1.0d - (cosValue * cosValue)) / cosValue;
        if (angle > 180.0f) out = -out;
        return out;
    }

    public static float tanFormCosD(float cosValue, float angle) {
        if (angle == 90.0f || angle == 270.0f) return 0.0f;
        float out = (float) Math.sqrt(1.0f - (cosValue * cosValue)) / cosValue;
        if (angle > 180.0f) out = -out;
        return out;
    }

    public static double tanD(double sinValue, double cosValue) {
        if (cosValue == 0.0d) return 0.0d;
        return sinValue / cosValue;
    }

    public static float tanF(float sinValue, float cosValue) {
        if (cosValue == 0.0f) return 0.0f;
        return sinValue / cosValue;
    }

    private TrigUtil() {};
}
