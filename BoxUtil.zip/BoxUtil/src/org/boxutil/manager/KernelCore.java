package org.boxutil.manager;

import com.fs.starfarer.api.Global;
import org.apache.log4j.Level;
import org.boxutil.base.BaseKernelData;
import org.boxutil.config.BoxConfigs;
import org.boxutil.define.BoxDatabase;
import org.boxutil.units.builtin.kernel.BUtil_KernelProgram;
import org.boxutil.units.builtin.kernel.BUtil_KernelSources;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.opencl.*;
import org.lwjgl.opengl.Display;

import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * clEnqueueNDRangeKernel() will return -1000 error code on 3070Ti, on current code, so mark it as deprecated.<p>
 * Search a solution later.
 */
@Deprecated
public final class KernelCore {
    private final static byte _KERNEL_COUNT = 2;
    private final static byte _INSTANCE_2D = 0;
    private final static byte _INSTANCE_3D = 1;
    private final static String _KERNEL_INSTANCE_SCALE_TITLE = "INSTANCE_SCALE_VALUE";
    private static CLPlatform clPlatform = null;
    private static CLPlatformCapabilities clPlatformCap = null;
    private static List<CLDevice> clDevice = new ArrayList<>();
    private static List<CLDeviceCapabilities> clDeviceCap = new ArrayList<>();
    private static CLContext clContext = null;
    private static CLCommandQueue clQueue = null;
    private static BaseKernelData[] _builtinKernels = new BaseKernelData[_KERNEL_COUNT];
    private static CLSampler instanceSampler = null;
    private static boolean clValid = false;
    private static boolean clFinished = false;

    /**
     * Default info.
     */
    @Deprecated
    public static final class Info {
        private static int MAX_IMAGE2D_WIDTH = 0;
        private static int MAX_IMAGE2D_HEIGHT = 0;
        private static int MAX_IMAGE2D_PIXELS = 0;
        private static int MAX_IMAGE3D_WIDTH = 0;
        private static int MAX_IMAGE3D_HEIGHT = 0;
        private static int MAX_IMAGE3D_DEPTH = 0;
        private static int MAX_IMAGE3D_PIXELS = 0;
        private static int CL_MAX_WORK_GROUP_SIZE = 0;
        private static int CL_MAX_WORK_ITEM_SIZE = 0;
        private static int CL_MAX_LOCAL_DIMENSIONS = 0;
        private static int CL_MAX_COMPUTE_UNITS = 0;

        public static int getMaxImage2dWidth() {
            return MAX_IMAGE2D_WIDTH;
        }

        public static int getMaxImage2dHeight() {
            return MAX_IMAGE2D_HEIGHT;
        }

        public static int getMaxImage2dPixels() {
            return MAX_IMAGE2D_PIXELS;
        }

        public static int getMaxImage3dWidth() {
            return MAX_IMAGE3D_WIDTH;
        }

        public static int getMaxImage3dHeight() {
            return MAX_IMAGE3D_HEIGHT;
        }

        public static int getMaxImage3dDepth() {
            return MAX_IMAGE3D_DEPTH;
        }

        public static int getMaxImage3dPixels() {
            return MAX_IMAGE3D_PIXELS;
        }

        /**
         * CPU code, component.
         */
        public static int getClMaxWorkGroupSize() {
            return CL_MAX_WORK_GROUP_SIZE;
        }

        /**
         * Local, component.
         */
        public static int getClMaxWorkItemSize() {
            return CL_MAX_WORK_ITEM_SIZE;
        }

        public static int getClMaxLocalDimensions() {
            return CL_MAX_LOCAL_DIMENSIONS;
        }

        public static int getClMaxComputeUnits() {
            return CL_MAX_COMPUTE_UNITS;
        }
    }

    /**
     * Loading after {@link ShaderCore#init()}.
     */
    public static void init() {
        if (clFinished) return;
        clFinished = true;
        if (BoxConfigs.BUtil_EnableCL) {
            Global.getLogger(ShaderCore.class).log(Level.WARN, "'Box Util' OpenCL module was disabled.");
            return;
        }
        try {
            IntBuffer errorCode = BufferUtils.createIntBuffer(1);
            CL.create();
            Global.getLogger(KernelCore.class).info("'Box Util' CL program has created.");
            for (CLPlatform checkPlatform : CLPlatform.getPlatforms()) {
                if (checkPlatform != null && checkPlatform.isValid()) {
                    CLPlatformCapabilities cap = CLCapabilities.getPlatformCapabilities(checkPlatform);
                    if (cap.majorVersion < 1 || !(cap.CL_KHR_gl_sharing || cap.CL_APPLE_gl_sharing)) continue;
                    clPlatformCap = cap;
                    clPlatform = checkPlatform;
                    Global.getLogger(KernelCore.class).info("'Box Util' CL platform init: '" + checkPlatform.getInfoString(CL10.CL_PLATFORM_NAME) + "', platform version: '" + checkPlatform.getInfoString(CL10.CL_PLATFORM_VERSION) + "'.");
                    Global.getLogger(KernelCore.class).info("'Box Util' CL platform cl version: '" + cap.majorVersion + "." + cap.minorVersion +  "'.");
                    break;
                }
            }
            if (clPlatform == null) {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' platform cannot support OpenCL.");
                destroy();
                return;
            }

            List<CLDevice> clDeviceTmp = new ArrayList<>();
            for (CLDevice checkDevice : clPlatform.getDevices(CL10.CL_DEVICE_TYPE_GPU)) {
                if (checkDevice != null && checkDevice.isValid()) {
                    CLDeviceCapabilities cap = CLCapabilities.getDeviceCapabilities(checkDevice);
                    boolean imageSupport = checkDevice.getInfoBoolean(CL10.CL_DEVICE_IMAGE_SUPPORT);
                    if (!imageSupport || !(cap.CL_KHR_gl_sharing || cap.CL_APPLE_gl_sharing)) continue;
                    clDeviceTmp.add(checkDevice);
                    clDeviceCap.add(CLCapabilities.getDeviceCapabilities(checkDevice));
                    Global.getLogger(KernelCore.class).info("'Box Util' CL device init: '" + checkDevice.getInfoString(CL10.CL_DEVICE_NAME) + "', driver version: '" + checkDevice.getInfoString(CL10.CL_DRIVER_VERSION) + "'.");
                    Global.getLogger(KernelCore.class).info("'Box Util' CL device cl version: '" + cap.majorVersion + "." + cap.minorVersion +  "'.");
                }
            }
            if (clDeviceTmp.isEmpty()) {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' CL device cannot found a valid device.");
                destroy();
                return;
            }
            if (BoxConfigs.BUtil_CL_DeviceIndex > clDeviceTmp.size() - 1) BoxConfigs.BUtil_CL_DeviceIndex = 0;
            clDevice = clDeviceTmp;

            if (Display.getDrawable() == null) {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' CL found drawable failed.");
                destroy();
                return;
            }
            clContext = CLContext.create(clPlatform, clDevice, null, Display.getDrawable(), errorCode);
            if (clContext == null || !clContext.isValid()) {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' CL context create error, error code: '" + errorCode.get(0) + "'.");
                destroy();
                return;
            }
            Global.getLogger(KernelCore.class).info("'Box Util' CL context has created.");
            errorCode.position(0);

            CLDevice defDevice = getDefaultCLDevice();
            CLCommandQueue queue;
            if (defDevice == null || !defDevice.isValid()) {
                queue = null;
            } else {
                queue = CL10.clCreateCommandQueue(clContext, defDevice, 0, errorCode);
            }
            if (queue == null || !queue.isValid()) {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' CL command queue create error for '" + defDevice.getInfoString(CL10.CL_DEVICE_NAME) + "', error code: '" + errorCode.get(0) + "'.");
                destroy();
                return;
            }
            clQueue = queue;
            Global.getLogger(KernelCore.class).info("'Box Util' CL command queue on device: '" + defDevice.getInfoString(CL10.CL_DEVICE_NAME) + "' has created.");
            errorCode.position(0);
            Global.getLogger(KernelCore.class).info("'Box Util' OpenCL context create finished.");
            clValid = true;

            {
                Info.MAX_IMAGE2D_WIDTH = defDevice.getInfoInt(CL10.CL_DEVICE_IMAGE2D_MAX_WIDTH);;
                Info.MAX_IMAGE2D_HEIGHT = defDevice.getInfoInt(CL10.CL_DEVICE_IMAGE2D_MAX_HEIGHT);;
                Info.MAX_IMAGE2D_PIXELS = Info.MAX_IMAGE2D_WIDTH * Info.MAX_IMAGE2D_HEIGHT;
                Info.MAX_IMAGE3D_WIDTH = defDevice.getInfoInt(CL10.CL_DEVICE_IMAGE3D_MAX_WIDTH);;
                Info.MAX_IMAGE3D_HEIGHT = defDevice.getInfoInt(CL10.CL_DEVICE_IMAGE3D_MAX_HEIGHT);;
                Info.MAX_IMAGE3D_DEPTH = defDevice.getInfoInt(CL10.CL_DEVICE_IMAGE3D_MAX_DEPTH);;
                Info.MAX_IMAGE3D_PIXELS = Info.MAX_IMAGE3D_WIDTH * Info.MAX_IMAGE3D_HEIGHT * Info.MAX_IMAGE3D_DEPTH;
                Info.CL_MAX_WORK_GROUP_SIZE = defDevice.getInfoInt(CL10.CL_DEVICE_MAX_WORK_GROUP_SIZE);
                Info.CL_MAX_WORK_ITEM_SIZE = defDevice.getInfoInt(CL10.CL_DEVICE_MAX_WORK_ITEM_SIZES);
                Info.CL_MAX_LOCAL_DIMENSIONS = defDevice.getInfoInt(CL10.CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS);
                Info.CL_MAX_COMPUTE_UNITS = defDevice.getInfoInt(CL10.CL_DEVICE_MAX_COMPUTE_UNITS);
            }

            CLDeviceCapabilities deviceCheckCap = getDefaultCLDeviceCapabilities();
            if (BoxConfigs.isCLParallel() && deviceCheckCap.OpenCL12 && (deviceCheckCap.CL_KHR_gl_sharing || deviceCheckCap.CL_APPLE_gl_sharing)) {
                final String gl_instanceScale = BoxDatabase.HALF_FLOAT_LOCATION_SCALE + "f";
                String instanceKernel2D = BUtil_KernelSources.InstanceMatrix.KERNEL_2D.replace(_KERNEL_INSTANCE_SCALE_TITLE, gl_instanceScale);
                String instanceKernel3D = BUtil_KernelSources.InstanceMatrix.KERNEL_3D.replace(_KERNEL_INSTANCE_SCALE_TITLE, gl_instanceScale);
                String instanceKernelName2D = BUtil_KernelSources.InstanceMatrix.KERNEL_NAME_2D;
                String instanceKernelName3D = BUtil_KernelSources.InstanceMatrix.KERNEL_NAME_3D;
                IntBuffer errorCode2D = BufferUtils.createIntBuffer(1);
                IntBuffer errorCode3D = BufferUtils.createIntBuffer(1);
                _builtinKernels[_INSTANCE_2D] = new BUtil_KernelProgram(instanceKernel2D, "", instanceKernelName2D, errorCode2D);
                _builtinKernels[_INSTANCE_3D] = new BUtil_KernelProgram(instanceKernel3D, "", instanceKernelName3D, errorCode3D);
                instanceSampler = CL10.clCreateSampler(KernelCore.getClContext(), CL10.CL_FALSE, CL10.CL_ADDRESS_CLAMP_TO_EDGE, CL10.CL_FILTER_NEAREST, errorCode);
                if (!(_builtinKernels[_INSTANCE_2D].isValid() && _builtinKernels[_INSTANCE_3D].isValid() && instanceSampler.isValid())) {
                    Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' creating instance matrix kernel or sampler happened error, kernel-2D/3D error code: '" + errorCode2D.get(0) + " / " + errorCode3D.get(0) + "' and sampler error code: '" + errorCode.get(0) + "'.");
                }
            } else {
                Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' CL platform is not supported to creating kernel program for 'instance data calculation'.");
            }
        } catch (LWJGLException e) {
            Global.getLogger(KernelCore.class).log(Level.ERROR, "'Box Util' OpenCL Context create error." + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public static void destroy() {
        clValid = false;
        if (_builtinKernels[_INSTANCE_2D] != null) _builtinKernels[_INSTANCE_2D].release();
        if (_builtinKernels[_INSTANCE_3D] != null) _builtinKernels[_INSTANCE_3D].release();
        if (clQueue != null && clQueue.isValid()) {
            CL10.clReleaseCommandQueue(clQueue);
        }
        if (clContext != null && clContext.isValid()) {
            CL10.clReleaseContext(clContext);
        }
        CL.destroy();
    }

    public static boolean isInitialized() {
        return clFinished;
    }

    public static boolean isValid() {
        return clValid;
    }

    public static CLPlatform getClPlatform() {
        return clPlatform;
    }

    public static CLPlatformCapabilities getClPlatformCapabilities() {
        return clPlatformCap;
    }

    public static List<CLDevice> getAllCLDevice() {
        return new ArrayList<>(clDevice);
    }

    public static CLDevice getDefaultCLDevice() {
        return clDevice.get(BoxConfigs.BUtil_CL_DeviceIndex);
    }

    public static List<CLDeviceCapabilities> getAllCLDeviceCapabilities() {
        return new ArrayList<>(clDeviceCap);
    }

    public static CLDeviceCapabilities getDefaultCLDeviceCapabilities() {
        return clDeviceCap.get(BoxConfigs.BUtil_CL_DeviceIndex);
    }

    public static CLContext getClContext() {
        return clContext;
    }

    public static CLCommandQueue getDefaultCLQueue() {
        return clQueue;
    }

    public static BaseKernelData getInstanceKernel2D() {
        return _builtinKernels[_INSTANCE_2D];
    }

    public static BaseKernelData getInstanceKernel3D() {
        return _builtinKernels[_INSTANCE_3D];
    }

    public static CLSampler getInstanceSampler() {
        return instanceSampler;
    }

    public static boolean isCLMultipleValid() {
        return clValid && _builtinKernels[_INSTANCE_2D].kernel != null && _builtinKernels[_INSTANCE_2D].kernel.isValid() && _builtinKernels[_INSTANCE_3D].kernel != null && _builtinKernels[_INSTANCE_3D].kernel.isValid();
    }

    private KernelCore() {}
}
