package org.boxutil.manager;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ViewportAPI;
import org.apache.log4j.Level;
import org.boxutil.base.BaseShaderData;
import org.boxutil.base.api.SimpleVAOAPI;
import org.boxutil.config.BoxConfigs;
import org.boxutil.define.BoxDatabase;
import org.boxutil.define.BoxEnum;
import org.boxutil.units.builtin.buffer.BUtil_RenderingBuffer;
import org.boxutil.units.builtin.shader.BUtil_ShaderProgram;
import org.boxutil.units.builtin.shader.BUtil_ShaderSources;
import org.boxutil.units.standard.misc.LineObject;
import org.boxutil.units.standard.misc.PointObject;
import org.boxutil.units.standard.misc.QuadObject;
import org.boxutil.util.CalculateUtil;
import org.boxutil.util.CommonUtil;
import org.boxutil.util.ShaderUtil;
import org.boxutil.util.TransformUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.*;
import org.lwjgl.util.vector.Matrix4f;

import java.nio.FloatBuffer;

public final class ShaderCore {
    private final static byte _SHADER_COUNT = 17;
    private final static byte _COMMON = 0;
    private final static byte _SPRITE = 1;
    private final static byte _CURVE = 2;
    private final static byte _SEGMENT = 3;
    private final static byte _FLARE = 4;
    private final static byte _TEXT = 5;
    private final static byte _DIST = 6;
    private final static byte _DIRECT = 7;
    private final static byte _BLOOM = 8;
    private final static byte _FXAA_C = 9;
    private final static byte _FXAA_Q = 10;
    private final static byte _MATRIX_2D = 11;
    private final static byte _MATRIX_3D = 12;
    private final static byte _SIMPLE_NUMBER = 13;
    private final static byte _SIMPLE_ARC = 14;
    private final static byte _SIMPLE_TEX_ARC = 15;
    private final static byte _MISSION_BG = 16;
    private final static String _GLSL_VERSION = "420";
    private final static String _GLSL_VERSION_TITLE = "OVERWRITE_VERSION";
    private final static String _GLSL_PRECISION = "highp";
    private final static String _GLSL_PRECISION_TITLE = "OVERWRITE_PRECISION";
    private final static String _GLSL_MATRIX_UBO_TITLE = "OVERWRITE_MATRIX_UBO";
    private final static String _GLSL_CURVE_NODE_SCALE_TITLE = "NODE_SCALE_VALUE";
    private final static String _GLSL_INSTANCE_SCALE_TITLE = "INSTANCE_SCALE_VALUE";
    private final static String _GLSL_WORKGROUP_SIZE_TITLE = "WORKGROUP_SIZE_VALUE";
    private final static String _GLSL_BLOOM_RADIUS_TITLE = "OVERWRITE_RADIUS_SCALE";
    private final static byte _GLSL_MATRIX_UBO_BINDING = 0;
    private final static FloatBuffer _NONE_GAME_MATRIX = CommonUtil.createFloatBuffer(1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f);
    private final static BaseShaderData[] _SHADER_PROGRAM = new BaseShaderData[_SHADER_COUNT];
    private static BUtil_RenderingBuffer renderingBuffer = null;
    private static SimpleVAOAPI defaultPointObject = null;
    private static SimpleVAOAPI defaultLineObject = null;
    private static SimpleVAOAPI defaultQuadObject = null;
    private static int matrixUBO = 0;
    private static boolean _miscShaderInit = false;
    private static boolean glValid = false;
    private static boolean glFinished = false;
    private static boolean glMainProgramValid = true;
    private static boolean glDistortionValid = false;
    private static boolean glBloomValid = false;
    private static boolean glFXAACValid = false;
    private static boolean glFXAAQValid = false;
    private static boolean glInstanceMatrixValid = false;
    private static final int[] screenSize = new int[2];
    private static final int[] screenSizeScale = new int[2];
    private static final int[] screenSizeFix = new int[2];
    private static final float[] screenSizeUV = new float[2];

    /**
     * Loading after {@link BoxConfigs#init()}.
     */
    public static void init() {
        if (glFinished) return;
        Global.getLogger(ShaderCore.class).info("'Box Util' OpenGL context running on: '" + BoxDatabase.getGLState().GL_CURRENT_DEVICE_NAME + "' with drive version: '" + BoxDatabase.getGLState().GL_CURRENT_DEVICE_VERSION + "'.");
        if (!BoxConfigs.isBaseGL42Supported()) {
            Global.getLogger(ShaderCore.class).log(Level.WARN, "'Box Util' platform is not supported 'OpenGL4.2'.");
            closeShader();
            return;
        }
        if (!BoxConfigs.isShaderEnable()) {
            Global.getLogger(ShaderCore.class).log(Level.WARN, "'Box Util' shader core has been disabled.");
            closeShader();
            return;
        }
        String vertCommon, fragCommon,
                vertSprite, fragSprite,
                vertCurve, tescCurve, teseCurve, geomCurve, fragCurve,
                vertSeg, tescSeg, teseSeg, geomSeg, fragSeg,
                vertFlare, fragFlare,
                vertText, geomText, fragText,
                vertDist, fragDist,
                vertPost, fragDirect, vertBloom, fragBloom, fragFXAAC, fragFXAAQ, compMatrix2D, compMatrix3D;
        final String gl_linear = "0.2126729, 0.7151522, 0.0721750";
        final String gl_screenXStep = String.format("%.9f", 1.0f / (float) screenSizeScale[0]);
        final String gl_screenYStep = String.format("%.9f", 1.0f / (float) screenSizeScale[1]);
        final boolean vendorCheckRed = BoxDatabase.getGLState().GL_CURRENT_DEVICE_VENDOR_BYTE == BoxEnum.GL_DEVICE_AMD_ATI;
        final String gl_localWorkDim = vendorCheckRed ? "16" : "8";
        final String gl_localWorkSize = vendorCheckRed ? "64" : "32";
        final String gl_matrixUBO = _GLSL_MATRIX_UBO_BINDING + "";
        final String gl_nodeScale = String.valueOf(BoxDatabase.HALF_FLOAT_TANGENT_SCALE);
        final String gl_instanceScale = String.valueOf(BoxDatabase.HALF_FLOAT_LOCATION_SCALE);
        final String gl_bloomRadius = "" + (4.0 * Global.getSettings().getScreenScaleMult());
        vertCommon = BUtil_ShaderSources.Common.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale);
        fragCommon = BUtil_ShaderSources.Common.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertSprite = BUtil_ShaderSources.Sprite.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale);
        fragSprite = BUtil_ShaderSources.Sprite.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertCurve = BUtil_ShaderSources.Curve.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale)
                .replace(_GLSL_CURVE_NODE_SCALE_TITLE, gl_nodeScale);
        tescCurve = BUtil_ShaderSources.Curve.TESC.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        teseCurve = BUtil_ShaderSources.Curve.TESE.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        geomCurve = BUtil_ShaderSources.Curve.GEOM.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        fragCurve = BUtil_ShaderSources.Curve.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertSeg = BUtil_ShaderSources.Segment.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale)
                .replace(_GLSL_CURVE_NODE_SCALE_TITLE, gl_nodeScale);
        tescSeg = BUtil_ShaderSources.Segment.TESC.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        teseSeg = BUtil_ShaderSources.Segment.TESE.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        geomSeg = geomCurve.replace("statePackage[5];", "statePackage[4];");
        fragSeg = fragCurve.replace("statePackage[5];", "statePackage[4];");
        vertFlare = BUtil_ShaderSources.Flare.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale);
        fragFlare = BUtil_ShaderSources.Flare.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertText = BUtil_ShaderSources.TextField.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO);
        geomText = BUtil_ShaderSources.TextField.GEOM.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        fragText = BUtil_ShaderSources.TextField.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertDist = BUtil_ShaderSources.Distortion.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace(_GLSL_MATRIX_UBO_TITLE, gl_matrixUBO).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale);
        fragDist = BUtil_ShaderSources.Distortion.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertPost = BUtil_ShaderSources.Share.POST_VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        fragDirect = BUtil_ShaderSources.Share.DIRECT_FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        vertBloom = BUtil_ShaderSources.Bloom.VERT.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION).replace("OVERWRITE_SCREEN_Y", gl_screenYStep).replace("OVERWRITE_SCREEN_X", gl_screenXStep)
                .replace(_GLSL_BLOOM_RADIUS_TITLE, gl_bloomRadius);
        fragBloom = BUtil_ShaderSources.Bloom.FRAG.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION);
        fragFXAAC = BUtil_ShaderSources.FXAA.CONSOLE.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION)
                .replace("OVERWRITE_SCREEN_X", gl_screenXStep).replace("OVERWRITE_SCREEN_Y", gl_screenYStep).replace("LINEAR_VALUES", gl_linear);
        fragFXAAQ = BUtil_ShaderSources.FXAA.QUALITY.replace(_GLSL_VERSION_TITLE, _GLSL_VERSION)
                .replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION)
                .replace("OVERWRITE_SCREEN_X", gl_screenXStep).replace("OVERWRITE_SCREEN_Y", gl_screenYStep).replace("LINEAR_VALUES", gl_linear);
        compMatrix2D = BUtil_ShaderSources.InstanceMatrix.COMPUTE_2D.replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION)
                .replace("RESET_VALUE", gl_localWorkDim).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale)
                .replace(_GLSL_WORKGROUP_SIZE_TITLE, gl_localWorkSize);
        compMatrix3D = BUtil_ShaderSources.InstanceMatrix.COMPUTE_3D.replace(_GLSL_PRECISION_TITLE, _GLSL_PRECISION)
                .replace("RESET_VALUE", gl_localWorkDim).replace(_GLSL_INSTANCE_SCALE_TITLE, gl_instanceScale)
                .replace(_GLSL_WORKGROUP_SIZE_TITLE, gl_localWorkSize);
        _SHADER_PROGRAM[_COMMON] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-CommonShader", vertCommon, fragCommon));
        _SHADER_PROGRAM[_SPRITE] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-SpriteShader", vertSprite, fragSprite));
        _SHADER_PROGRAM[_CURVE] = new BUtil_ShaderProgram(ShaderUtil.createShaderVTGF("Box Util-CurveShader", vertCurve, tescCurve, teseCurve, geomCurve, fragCurve));
        _SHADER_PROGRAM[_SEGMENT] = new BUtil_ShaderProgram(ShaderUtil.createShaderVTGF("Box Util-SegmentShader", vertSeg, tescSeg, teseSeg, geomSeg, fragSeg));
        _SHADER_PROGRAM[_FLARE] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-FlareShader", vertFlare, fragFlare));
        _SHADER_PROGRAM[_TEXT] = new BUtil_ShaderProgram(ShaderUtil.createShaderVGF("Box Util-TextShader", vertText, geomText, fragText));
        _SHADER_PROGRAM[_DIST] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-DistortionShader", vertDist, fragDist));
        _SHADER_PROGRAM[_DIRECT] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-DirectShader", vertPost, fragDirect));
        _SHADER_PROGRAM[_BLOOM] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-BloomShader", vertBloom, fragBloom));
        _SHADER_PROGRAM[_FXAA_C] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-FXAA-ConsoleShader", vertPost, fragFXAAC));
        _SHADER_PROGRAM[_FXAA_Q] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-FXAA-QualityShader", vertPost, fragFXAAQ));
        if (BoxConfigs.isGLParallel() && BoxConfigs.isGLParallelSupported()) {
            _SHADER_PROGRAM[_MATRIX_2D] = new BUtil_ShaderProgram(ShaderUtil.createComputeShaders("Box Util-MatrixComputeShader-2D", compMatrix2D));
            _SHADER_PROGRAM[_MATRIX_3D] = new BUtil_ShaderProgram(ShaderUtil.createComputeShaders("Box Util-MatrixComputeShader-3D", compMatrix3D));
        }

        initShaderPrograms();
        refreshRenderingBuffer();
        refreshDefaultVAO();
        if (!isMainProgramValid() || !isRenderingFramebufferValid() || !isDefaultVAOValid()) {
            closeShader();
            Global.getLogger(ShaderCore.class).info("'Box Util' base shader resource init failed, main program: " + isMainProgramValid() + ", rendering framebuffer: " + isRenderingFramebufferValid() + ", default VAO: " + isDefaultVAOValid() + ".");
            return;
        }
        matrixUBO = GL15.glGenBuffers();
        if (matrixUBO == 0) {
            closeShader();
            Global.getLogger(ShaderCore.class).info("'Box Util' shader UBO init failed. ");
            return;
        }
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferData(GL31.GL_UNIFORM_BUFFER, 20 * BoxDatabase.FLOAT_SIZE, GL15.GL_DYNAMIC_DRAW);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
        GL30.glBindBufferBase(GL31.GL_UNIFORM_BUFFER, _GLSL_MATRIX_UBO_BINDING, matrixUBO);
        glValid = true;
        glFinished = true;

        initDistortionProgram();
        initBloomProgram();
        initFXAACProgram();
        initFXAAQProgram();
        initMatrixProgram();
    }

    public static void initMiscShaderPrograms() {
        if (_miscShaderInit) return;
        _SHADER_PROGRAM[_SIMPLE_NUMBER] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-NumberShader", BUtil_ShaderSources.Number.VERT, BUtil_ShaderSources.Number.FRAG));
        _SHADER_PROGRAM[_SIMPLE_ARC] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-ArcShader", BUtil_ShaderSources.Arc.VERT, BUtil_ShaderSources.Arc.FRAG));
        _SHADER_PROGRAM[_SIMPLE_TEX_ARC] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-TexArcShader", BUtil_ShaderSources.Arc.VERT, BUtil_ShaderSources.TexArc.FRAG));
        _SHADER_PROGRAM[_MISSION_BG] = new BUtil_ShaderProgram(ShaderUtil.createShaderVF("Box Util-TestMissionShader", BUtil_ShaderSources.Mission.VERT, BUtil_ShaderSources.Mission.FRAG));
        if (_SHADER_PROGRAM[_SIMPLE_NUMBER].isValid()) {
            int[] uniforms = new int[]{
                    _SHADER_PROGRAM[_SIMPLE_NUMBER].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_SIMPLE_NUMBER].getUniformIndex("charLength")
            };
            _SHADER_PROGRAM[_SIMPLE_NUMBER].location = uniforms;
        }

        if (_SHADER_PROGRAM[_SIMPLE_ARC].isValid()) {
            int[] uniforms = new int[]{
                    _SHADER_PROGRAM[_SIMPLE_ARC].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_SIMPLE_ARC].getUniformIndex("arcValue")
            };
            _SHADER_PROGRAM[_SIMPLE_ARC].location = uniforms;
        }

        if (_SHADER_PROGRAM[_SIMPLE_TEX_ARC].isValid()) {
            int[] uniforms = new int[]{
                    _SHADER_PROGRAM[_SIMPLE_TEX_ARC].getUniformIndex("statePackage")
            };
            _SHADER_PROGRAM[_SIMPLE_TEX_ARC].location = uniforms;
        }

        if (_SHADER_PROGRAM[_MISSION_BG].isValid()) {
            int[] uniforms = new int[]{
                    _SHADER_PROGRAM[_MISSION_BG].getUniformIndex("time")
            };
            _SHADER_PROGRAM[_MISSION_BG].location = uniforms;
        }
        _miscShaderInit = true;
    }

    public static void closeShader() {
        glValid = false;
        glFinished = true;
        BoxConfigs.sysCheck();
    }

    private static void initShaderPrograms() {
        if (_SHADER_PROGRAM[_COMMON].isValid()) {
            int[] commonU = new int[]{
                    _SHADER_PROGRAM[_COMMON].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_COMMON].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_COMMON].getUniformIndex("baseSize"),
                    _SHADER_PROGRAM[_COMMON].getUniformIndex("additionEmissive")
            };
            int[] commonUBOU = new int[]{
                    _SHADER_PROGRAM[_COMMON].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING)
            };
            int[][] commonSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "commonMode"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "colorMode"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "noneData"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData2D"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData3D")
                    },
                    {
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "commonMode"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "colorMode")
                    }
            };
            int[][] commonSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_COMMON].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "vertexState"),
                            _SHADER_PROGRAM[_COMMON].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "instanceState")
                    },
                    {
                            _SHADER_PROGRAM[_COMMON].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "surfaceState")
                    }
            };
            _SHADER_PROGRAM[_COMMON].location = commonU;
            _SHADER_PROGRAM[_COMMON].uboLocation = commonUBOU;
            _SHADER_PROGRAM[_COMMON].subroutineLocation = commonSU;
            _SHADER_PROGRAM[_COMMON].subroutineUniformLocation = commonSUL;
            _SHADER_PROGRAM[_COMMON].initMaxSubroutineUniformLocation();
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_SPRITE].isValid()) {
            int[] spriteU = new int[]{
                    _SHADER_PROGRAM[_SPRITE].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_SPRITE].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_SPRITE].getUniformIndex("additionEmissive")
            };
            int[] spriteUBOU = new int[]{
                    _SHADER_PROGRAM[_SPRITE].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            int[][] spriteSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "commonUV"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "tileUV"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "tileRUV"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "noneData"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData2D"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData3D")
                    }
            };
            int[][] spriteSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_SPRITE].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "uvMapping"),
                            _SHADER_PROGRAM[_SPRITE].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "instanceState")
                    }
            };
            _SHADER_PROGRAM[_SPRITE].location = spriteU;
            _SHADER_PROGRAM[_SPRITE].uboLocation = spriteUBOU;
            _SHADER_PROGRAM[_SPRITE].subroutineLocation = spriteSU;
            _SHADER_PROGRAM[_SPRITE].subroutineUniformLocation = spriteSUL;
            _SHADER_PROGRAM[_SPRITE].initMaxSubroutineUniformLocation();
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_CURVE].isValid()) {
            int[] curveU = new int[]{
                    _SHADER_PROGRAM[_CURVE].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_CURVE].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_CURVE].getUniformIndex("totalNodes"),
                    _SHADER_PROGRAM[_CURVE].getUniformIndex("additionEmissive")
            };
            int[] curveUBOU = new int[]{
                    _SHADER_PROGRAM[_CURVE].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            int[][] curveSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_CURVE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "noneData"),
                            _SHADER_PROGRAM[_CURVE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData2D"),
                            _SHADER_PROGRAM[_CURVE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData3D")
                    }
            };
            int[][] curveSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_CURVE].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "instanceState")
                    }
            };
            _SHADER_PROGRAM[_CURVE].location = curveU;
            _SHADER_PROGRAM[_CURVE].uboLocation = curveUBOU;
            _SHADER_PROGRAM[_CURVE].subroutineLocation = curveSU;
            _SHADER_PROGRAM[_CURVE].subroutineUniformLocation = curveSUL;
            _SHADER_PROGRAM[_CURVE].initMaxSubroutineUniformLocation();
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_SEGMENT].isValid()) {
            int[] curveU = new int[]{
                    _SHADER_PROGRAM[_SEGMENT].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_SEGMENT].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_SEGMENT].getUniformIndex("additionEmissive")
            };
            int[] curveUBOU = new int[]{
                    _SHADER_PROGRAM[_SEGMENT].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            _SHADER_PROGRAM[_SEGMENT].location = curveU;
            _SHADER_PROGRAM[_SEGMENT].uboLocation = curveUBOU;
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_FLARE].isValid()) {
            int[] flareU = new int[]{
                    _SHADER_PROGRAM[_FLARE].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_FLARE].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_FLARE].getUniformIndex("extraState")
            };
            int[] flareUBOU = new int[]{
                    _SHADER_PROGRAM[_FLARE].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            int[][] flareSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "noneData"),
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData2D"),
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData3D")
                    },
                    {
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "smoothMode"),
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "sharpMode"),
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "smoothDiscMode"),
                            _SHADER_PROGRAM[_FLARE].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "sharpDiscMode")
                    }
            };
            int[][] flareSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_FLARE].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "instanceState")
                    },
                    {
                            _SHADER_PROGRAM[_FLARE].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "flareState")
                    }
            };
            _SHADER_PROGRAM[_FLARE].location = flareU;
            _SHADER_PROGRAM[_FLARE].uboLocation = flareUBOU;
            _SHADER_PROGRAM[_FLARE].subroutineLocation = flareSU;
            _SHADER_PROGRAM[_FLARE].subroutineUniformLocation = flareSUL;
            _SHADER_PROGRAM[_FLARE].initMaxSubroutineUniformLocation();
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_TEXT].isValid()) {
            int[] textU = new int[]{
                    _SHADER_PROGRAM[_TEXT].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_TEXT].getUniformIndex("fontMap[0]"),
                    _SHADER_PROGRAM[_TEXT].getUniformIndex("fontMap[1]"),
                    _SHADER_PROGRAM[_TEXT].getUniformIndex("fontMap[2]"),
                    _SHADER_PROGRAM[_TEXT].getUniformIndex("fontMap[3]")
            };
            int[] textUBOU = new int[]{
                    _SHADER_PROGRAM[_TEXT].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            _SHADER_PROGRAM[_TEXT].location = textU;
            _SHADER_PROGRAM[_TEXT].uboLocation = textUBOU;
            _SHADER_PROGRAM[_TEXT].putDefaultTextureUnit(_SHADER_PROGRAM[_TEXT].location[1], 0);
            _SHADER_PROGRAM[_TEXT].putDefaultTextureUnit(_SHADER_PROGRAM[_TEXT].location[2], 1);
            _SHADER_PROGRAM[_TEXT].putDefaultTextureUnit(_SHADER_PROGRAM[_TEXT].location[3], 2);
            _SHADER_PROGRAM[_TEXT].putDefaultTextureUnit(_SHADER_PROGRAM[_TEXT].location[4], 3);
        } else glMainProgramValid = false;

        if (_SHADER_PROGRAM[_DIRECT].isValid()) {
            int[] directU = new int[]{
                    _SHADER_PROGRAM[_DIRECT].getUniformIndex("alphaFix")
            };
            _SHADER_PROGRAM[_DIRECT].location = directU;
        } else glMainProgramValid = false;
    }

    private static void initDistortionProgram() {
        if (_SHADER_PROGRAM[_DIST].isValid()) {
            int[] distU = new int[]{
                    _SHADER_PROGRAM[_DIST].getUniformIndex("modelMatrix"),
                    _SHADER_PROGRAM[_DIST].getUniformIndex("statePackage"),
                    _SHADER_PROGRAM[_DIST].getUniformIndex("screenScale"),
                    _SHADER_PROGRAM[_DIST].getUniformIndex("arcValue")
            };
            int[] distUBOU = new int[]{
                    _SHADER_PROGRAM[_DIST].getUBOIndex("BUtilGlobalData", _GLSL_MATRIX_UBO_BINDING),
            };
            int[][] distSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_DIST].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "noneData"),
                            _SHADER_PROGRAM[_DIST].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData2D"),
                            _SHADER_PROGRAM[_DIST].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "haveData3D")
                    }
            };
            int[][] distSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_DIST].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "instanceState")
                    }
            };
            _SHADER_PROGRAM[_DIST].location = distU;
            _SHADER_PROGRAM[_DIST].uboLocation = distUBOU;
            _SHADER_PROGRAM[_DIST].subroutineLocation = distSU;
            _SHADER_PROGRAM[_DIST].subroutineUniformLocation = distSUL;
            _SHADER_PROGRAM[_DIST].initMaxSubroutineUniformLocation();
            glDistortionValid = true;
        } else Global.getLogger(ShaderCore.class).info("'Box Util' distortion program init failed.");
    }

    private static void initBloomProgram() {
        if (_SHADER_PROGRAM[_BLOOM].isValid()) {
            int[] bloomU = new int[]{
                    _SHADER_PROGRAM[_BLOOM].getUniformIndex("scale")
            };
            int[][] bloomSU = new int[][]{
                    {
                            _SHADER_PROGRAM[_BLOOM].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "downSample"),
                            _SHADER_PROGRAM[_BLOOM].getSubroutineIndex(GL20.GL_VERTEX_SHADER, "upSample")
                    },
                    {
                            _SHADER_PROGRAM[_BLOOM].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "downSample"),
                            _SHADER_PROGRAM[_BLOOM].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "upSample")
                    }
            };
            int[][] bloomSUL = new int[][]{
                    {
                            _SHADER_PROGRAM[_BLOOM].getSubroutineUniformLocation(GL20.GL_VERTEX_SHADER, "sampleModeState")
                    },
                    {
                            _SHADER_PROGRAM[_BLOOM].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "sampleModeState")
                    }
            };
            _SHADER_PROGRAM[_BLOOM].location = bloomU;
            _SHADER_PROGRAM[_BLOOM].subroutineLocation = bloomSU;
            _SHADER_PROGRAM[_BLOOM].subroutineUniformLocation = bloomSUL;
            _SHADER_PROGRAM[_BLOOM].initMaxSubroutineUniformLocation();
            glBloomValid = true;
        } else Global.getLogger(ShaderCore.class).info("'Box Util' bloom program init failed.");
    }

    private static void initFXAACProgram() {
        if (_SHADER_PROGRAM[_FXAA_C].isValid()) {
            int[][] fxaaCSU = new int[][]{
                    {},
                    {
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "fromRaw"),
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "fromDepth"),
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "commonDisplay"),
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "edgeDisplay")
                    }
            };
            int[][] fxaaSUL = new int[][]{
                    {},
                    {
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "sampleMethodState"),
                            _SHADER_PROGRAM[_FXAA_C].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "displayMethodState")
                    }
            };
            _SHADER_PROGRAM[_FXAA_C].subroutineLocation = fxaaCSU;
            _SHADER_PROGRAM[_FXAA_C].subroutineUniformLocation = fxaaSUL;
            _SHADER_PROGRAM[_FXAA_C].initMaxSubroutineUniformLocation();
            glFXAACValid = true;
        } else Global.getLogger(ShaderCore.class).info("'Box Util' fxaa-console program init failed.");
    }

    private static void initFXAAQProgram() {
        if (_SHADER_PROGRAM[_FXAA_Q].isValid()) {
            int[][] fxaaQSU = new int[][]{
                    {},
                    {
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "fromRaw"),
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "fromDepth"),
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "commonDisplay"),
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineIndex(GL20.GL_FRAGMENT_SHADER, "edgeDisplay")
                    }
            };
            int[][] fxaaSUL = new int[][]{
                    {},
                    {
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "sampleMethodState"),
                            _SHADER_PROGRAM[_FXAA_Q].getSubroutineUniformLocation(GL20.GL_FRAGMENT_SHADER, "displayMethodState")
                    }
            };
            _SHADER_PROGRAM[_FXAA_Q].subroutineLocation = fxaaQSU;
            _SHADER_PROGRAM[_FXAA_Q].subroutineUniformLocation = fxaaSUL;
            _SHADER_PROGRAM[_FXAA_Q].initMaxSubroutineUniformLocation();
            glFXAAQValid = true;
        } else Global.getLogger(ShaderCore.class).info("'Box Util' fxaa-quality program init failed.");
    }

    private static void initMatrixProgram() {
        if (BoxConfigs.isGLParallel() && _SHADER_PROGRAM[_MATRIX_2D].isValid() && _SHADER_PROGRAM[_MATRIX_3D].isValid()) {
            int[] matrix2DU = new int[]{
                    _SHADER_PROGRAM[_MATRIX_2D].getUniformIndex("instanceState"),
            };
            _SHADER_PROGRAM[_MATRIX_2D].location = matrix2DU;

            int[] matrix3DU = new int[]{
                    _SHADER_PROGRAM[_MATRIX_3D].getUniformIndex("instanceState"),
            };
            _SHADER_PROGRAM[_MATRIX_3D].location = matrix3DU;
            glInstanceMatrixValid = true;
        } else Global.getLogger(ShaderCore.class).info("'Box Util' matrix program init failed.");
    }

    public static void glBeginDraw() {
        GL11.glPushClientAttrib(GL11.GL_ALL_CLIENT_ATTRIB_BITS);
        GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
        GL11.glViewport(0, 0, screenSizeScale[0], screenSizeScale[1]);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glDisable(GL11.GL_STENCIL_TEST);
        GL11.glDisable(GL13.GL_MULTISAMPLE);
        GL11.glEnable(GL32.GL_DEPTH_CLAMP);
        GL11.glEnable(GL11.GL_BLEND);
        GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL14.glBlendEquation(GL14.GL_FUNC_ADD);
        GL11.glCullFace(GL11.GL_BACK);
        GL11.glFrontFace(GL11.GL_CCW);
        GL11.glDepthFunc(GL11.GL_LESS);
        GL11.glDepthRange(-1.0f, 1.0f);
    }

    public static void glEndDraw() {
        GL30.glBindVertexArray(0);
        GL11.glPopAttrib();
        GL11.glPopClientAttrib();
    }

    public static int glDrawBloom() {
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        if (!BoxConfigs.isBloomEnabled()) return -1;
        int getter = 0;
        int[] buffer = new int[]{renderingBuffer.getFBO(1), renderingBuffer.getFBO(0)};
        int[] tex = new int[]{renderingBuffer.getEmissiveResult(0), renderingBuffer.getColorResult(1)};
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, buffer[getter]);
        GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
        _SHADER_PROGRAM[_BLOOM].active();
        _SHADER_PROGRAM[_BLOOM].putUniformSubroutine(GL20.GL_VERTEX_SHADER, 0, 0);
        _SHADER_PROGRAM[_BLOOM].putUniformSubroutine(GL20.GL_FRAGMENT_SHADER, 1, 0);

        for (byte i = 1; i < BUtil_RenderingBuffer.getLayerCount(); i++) {
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, buffer[getter]);
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
            _SHADER_PROGRAM[_BLOOM].bindTexture2D(tex[getter]);
            renderingBuffer.setScaleViewport(i);
            GL20.glUniform1f(_SHADER_PROGRAM[_BLOOM].location[0], renderingBuffer.getScaleFactor(i - 1));
            defaultQuadObject.glDraw();
            getter = 1 - getter;
            if (i == 1) {
                tex[0] = renderingBuffer.getColorResult(0);
            }
        }

        _SHADER_PROGRAM[_BLOOM].putUniformSubroutine(GL20.GL_VERTEX_SHADER, 0, 1);
        _SHADER_PROGRAM[_BLOOM].putUniformSubroutine(GL20.GL_FRAGMENT_SHADER, 1, 1);
        for (byte i = (byte) (BUtil_RenderingBuffer.getLayerCount() - 2); i > -1; i--) {
            GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, buffer[getter]);
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
            _SHADER_PROGRAM[_BLOOM].bindTexture2D(tex[getter]);
            renderingBuffer.setScaleViewport(i);
            GL20.glUniform1f(_SHADER_PROGRAM[_BLOOM].location[0], renderingBuffer.getScaleFactor(i + 1));
            defaultQuadObject.glDraw();
            getter = 1 - getter;
        }
        _SHADER_PROGRAM[_BLOOM].close();
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
        return tex[getter];
    }

    public static void glApplyAA() {
        if (BoxConfigs.isAADisabled()) return;
        byte type = BoxConfigs.isFXAAC() ? _FXAA_C : _FXAA_Q;
        int[] subroutines = new int[2];
        subroutines[0] = _SHADER_PROGRAM[type].subroutineLocation[1][BoxConfigs.isDepthAA() ? 1 : 0];
        subroutines[1] = _SHADER_PROGRAM[type].subroutineLocation[1][BoxConfigs.isAAShowEdge() ? 3 : 2];
        ShaderUtil.copyFromScreen(renderingBuffer.getFBO(1));
        _SHADER_PROGRAM[type].active();
        _SHADER_PROGRAM[type].putUniformSubroutines(GL20.GL_FRAGMENT_SHADER, 1, subroutines);
        _SHADER_PROGRAM[type].bindTexture2D(0, renderingBuffer.getColorResult(1));
        _SHADER_PROGRAM[type].bindTexture2D(1, renderingBuffer.getDataResult(0));
        defaultQuadObject.glDraw();
        _SHADER_PROGRAM[type].close();
    }

    public static boolean glMultiPass() {
        int texture;
        switch (BoxConfigs.getMultiPassMode()) {
            case BoxEnum.MP_BEAUTY: return false;
            case BoxEnum.MP_DATA: {
                texture = renderingBuffer.getDataResult(0);
                break;
            }
            case BoxEnum.MP_EMISSIVE: {
                texture = renderingBuffer.getEmissiveResult(0);
                break;
            }
            case BoxEnum.MP_NORMAL: {
                texture = renderingBuffer.getNormalResult(0);
                break;
            }
            default: return false;
        }
        _SHADER_PROGRAM[_DIRECT].active();
        GL20.glUniform1f(_SHADER_PROGRAM[_DIRECT].location[0], 1.0f);
        _SHADER_PROGRAM[_DIRECT].bindTexture2D(0, texture);
        defaultQuadObject.glDraw();
        _SHADER_PROGRAM[_DIRECT].close();
        return true;
    }

    public static void initScreenSize() {
        screenSize[0] = (int) (Global.getSettings().getScreenWidth() * Display.getPixelScaleFactor());
        screenSizeScale[0] = (int) (screenSize[0] * Global.getSettings().getScreenScaleMult());
        screenSize[1] = (int) (Global.getSettings().getScreenHeight() * Display.getPixelScaleFactor());
        screenSizeScale[1] = (int) (screenSize[1] * Global.getSettings().getScreenScaleMult());
        screenSizeFix[0] = CalculateUtil.getPOTMax(screenSize[0]);
        screenSizeFix[1] = CalculateUtil.getPOTMax(screenSize[1]);
        screenSizeUV[0] = (float) ((double) screenSize[0] / (double) screenSizeFix[0]);
        screenSizeUV[1] = (float) ((double) screenSize[1] / (double) screenSizeFix[1]);
    }

    public static int getScreenWidth() {
        return screenSize[0];
    }

    public static int getScreenHeight() {
        return screenSize[1];
    }

    public static int getScreenScaleWidth() {
        return screenSizeScale[0];
    }

    public static int getScreenScaleHeight() {
        return screenSizeScale[1];
    }

    /**
     * Needless usual.
     */
    public static int getScreenFixWidth() {
        return screenSizeFix[0];
    }

    /**
     * Needless usual.
     */
    public static int getScreenFixHeight() {
        return screenSizeFix[1];
    }

    /**
     * Needless usual.
     */
    public static float getScreenFixU() {
        return screenSizeUV[0];
    }

    /**
     * Needless usual.
     */
    public static float getScreenFixV() {
        return screenSizeUV[1];
    }

    public static BaseShaderData getCommonProgram() {
        return _SHADER_PROGRAM[_COMMON];
    }

    public static BaseShaderData getSpriteProgram() {
        return _SHADER_PROGRAM[_SPRITE];
    }

    public static BaseShaderData getCurveProgram() {
        return _SHADER_PROGRAM[_CURVE];
    }

    public static BaseShaderData getSegmentProgram() {
        return _SHADER_PROGRAM[_SEGMENT];
    }

    public static BaseShaderData getFlareProgram() {
        return _SHADER_PROGRAM[_FLARE];
    }

    public static BaseShaderData getTextProgram() {
        return _SHADER_PROGRAM[_TEXT];
    }

    public static BaseShaderData getDistortionProgram() {
        return _SHADER_PROGRAM[_DIST];
    }

    public static BaseShaderData getDirectDrawProgram() {
        return _SHADER_PROGRAM[_DIRECT];
    }

    public static BaseShaderData getBloomProgram() {
        return _SHADER_PROGRAM[_BLOOM];
    }

    public static BaseShaderData getFXAACProgram() {
        return _SHADER_PROGRAM[_FXAA_C];
    }

    public static BaseShaderData getFXAAQProgram() {
        return _SHADER_PROGRAM[_FXAA_Q];
    }

    public static BaseShaderData get2DMatrixProgram() {
        return _SHADER_PROGRAM[_MATRIX_2D];
    }

    public static BaseShaderData get3DMatrixProgram() {
        return _SHADER_PROGRAM[_MATRIX_3D];
    }

    public static BaseShaderData getNumberProgram() {
        return _SHADER_PROGRAM[_SIMPLE_NUMBER];
    }

    public static BaseShaderData getArcProgram() {
        return _SHADER_PROGRAM[_SIMPLE_ARC];
    }

    public static BaseShaderData getTexArcProgram() {
        return _SHADER_PROGRAM[_SIMPLE_ARC];
    }

    public static BaseShaderData getTestMissionProgram() {
        return _SHADER_PROGRAM[_MISSION_BG];
    }

    public static BUtil_RenderingBuffer getRenderingBuffer() {
        return renderingBuffer;
    }

    public static void refreshGameViewportMatrix(ViewportAPI viewport) {
        if (matrixUBO == 0) return;
        FloatBuffer matrix = CommonUtil.createFloatBuffer(TransformUtil.createGameOrthoMatrix(viewport, new Matrix4f()));
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 0, matrix);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static void refreshGameViewportMatrix(FloatBuffer matrix) {
        if (matrixUBO == 0) return;
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 0, matrix);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static void refreshGameViewportMatrixNone() {
        if (matrixUBO == 0) return;
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 0, _NONE_GAME_MATRIX);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static void refreshGameScreenState(ViewportAPI viewport) {
        if (matrixUBO == 0) return;
        FloatBuffer buffer = BufferUtils.createFloatBuffer(4);
        float llx = viewport.getLLX();
        float lly = viewport.getLLY();
        buffer.put(llx);
        buffer.put(lly);
        buffer.put(Math.abs(viewport.convertScreenXToWorldX(viewport.getVisibleWidth()) - llx));
        buffer.put(Math.abs(viewport.convertScreenYToWorldY(viewport.getVisibleHeight()) - lly));
        buffer.position(0);
        buffer.limit(buffer.capacity());
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 16, buffer);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static void refreshGameVanillaViewportUBOAll(ViewportAPI viewport) {
        if (matrixUBO == 0) return;
        FloatBuffer buffer = BufferUtils.createFloatBuffer(20);
        TransformUtil.createGameOrthoMatrix(viewport, new Matrix4f()).store(buffer);
        float llx = viewport.getLLX();
        float lly = viewport.getLLY();
        buffer.put(llx);
        buffer.put(lly);
        buffer.put(Math.abs(viewport.convertScreenXToWorldX(viewport.getVisibleWidth()) - llx));
        buffer.put(Math.abs(viewport.convertScreenYToWorldY(viewport.getVisibleHeight()) - lly));
        buffer.position(0);
        buffer.limit(buffer.capacity());
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 0, buffer);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static void refreshGameVanillaViewportUBOAll(FloatBuffer matrix, ViewportAPI viewport) {
        if (matrixUBO == 0) return;
        FloatBuffer buffer = BufferUtils.createFloatBuffer(4);
        float llx = viewport.getLLX();
        float lly = viewport.getLLY();
        buffer.put(0, llx);
        buffer.put(1, lly);
        buffer.put(2, Math.abs(viewport.convertScreenXToWorldX(viewport.getVisibleWidth()) - llx));
        buffer.put(3, Math.abs(viewport.convertScreenYToWorldY(viewport.getVisibleHeight()) - lly));
        buffer.position(0);
        buffer.limit(buffer.capacity());
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, matrixUBO);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 0, matrix);
        GL15.glBufferSubData(GL31.GL_UNIFORM_BUFFER, 16 * BoxDatabase.FLOAT_SIZE, buffer);
        GL15.glBindBuffer(GL31.GL_UNIFORM_BUFFER, 0);
    }

    public static boolean isFramebufferValid() {
        return renderingBuffer != null && renderingBuffer.isFinished(0) && renderingBuffer.isFinished(1);
    }

    public static void refreshRenderingBuffer() {
        if (renderingBuffer != null) {
            for (byte i = 0; i < BUtil_RenderingBuffer.getBufferCount(); i++) {
                if (renderingBuffer.isFinished(i)) renderingBuffer.delete(i);
            }
        }
        renderingBuffer = new BUtil_RenderingBuffer();
        for (byte i = 0; i < BUtil_RenderingBuffer.getBufferCount(); i++) {
            if (renderingBuffer.isFinished(i))
                Global.getLogger(ShaderCore.class).info("'Box Util' rendering framebuffer-" + i + " has refreshed.");
            else Global.getLogger(ShaderCore.class).log(Level.ERROR, "'Box Util' rendering framebuffer-" + i + " refresh failed.");
        }
    }

    public static boolean isRenderingFramebufferValid() {
        return renderingBuffer != null && renderingBuffer.isFinished(0) && renderingBuffer.isFinished(1);
    }

    public static SimpleVAOAPI getDefaultPointObject() {
        return defaultPointObject;
    }

    public static void refreshDefaultPointObject() {
        if (defaultPointObject != null) defaultPointObject.destroy();
        defaultPointObject = new PointObject();
        if (defaultPointObject.isValid())
            Global.getLogger(ShaderCore.class).info("'Box Util' default point object has refreshed.");
        else Global.getLogger(ShaderCore.class).log(Level.ERROR, "'Box Util' default point object refresh failed.");
    }

    public static SimpleVAOAPI getDefaultLineObject() {
        return defaultLineObject;
    }

    public static void refreshDefaultLineObject() {
        if (defaultLineObject != null) defaultLineObject.destroy();
        defaultLineObject = new LineObject();
        if (defaultLineObject.isValid())
            Global.getLogger(ShaderCore.class).info("'Box Util' default line object has refreshed.");
        else Global.getLogger(ShaderCore.class).log(Level.ERROR, "'Box Util' default line object refresh failed.");
    }

    public static SimpleVAOAPI getDefaultQuadObject() {
        return defaultQuadObject;
    }

    public static void refreshDefaultQuadObject() {
        if (defaultQuadObject != null) defaultQuadObject.destroy();
        defaultQuadObject = new QuadObject();
        if (defaultQuadObject.isValid())
            Global.getLogger(ShaderCore.class).info("'Box Util' default quad object has refreshed.");
        else Global.getLogger(ShaderCore.class).log(Level.ERROR, "'Box Util' default quad object refresh failed.");
    }

    public static boolean isDefaultVAOValid() {
        if (defaultPointObject == null || defaultLineObject == null || defaultQuadObject == null) return false;
        return defaultPointObject.isValid() && defaultLineObject.isValid() && defaultQuadObject.isValid();
    }

    public static void refreshDefaultVAO() {
        refreshDefaultPointObject();
        refreshDefaultLineObject();
        refreshDefaultQuadObject();
    }

    public static int getMatrixUBO() {
        return matrixUBO;
    }

    public static byte getMatrixUBOBinding() {
        return _GLSL_MATRIX_UBO_BINDING;
    }

    public static boolean isInitialized() {
        return glFinished;
    }

    public static boolean isValid() {
        return glValid;
    }

    public static boolean isMainProgramValid() {
        return glMainProgramValid;
    }

    public static boolean isDistortionValid() {
        return glDistortionValid;
    }

    public static boolean isBloomValid() {
        return glBloomValid;
    }

    public static boolean isFXAACValid() {
        return glFXAACValid;
    }

    public static boolean isFXAAQValid() {
        return glFXAAQValid;
    }

    public static boolean isMatrixProgramValid() {
        return glInstanceMatrixValid;
    }

    private ShaderCore() {}
}
