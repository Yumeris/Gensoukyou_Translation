package org.boxutil.define;

public final class BoxEnum {
    public static final byte STATE_SUCCESS = 0;
    public static final byte STATE_FAILED = 1;
    public static final byte STATE_FAILED_OTHER = 2;

    public static final byte FALSE = 0;
    public static final byte TRUE = 1;
    public static final byte ZERO = 0;
    public static final byte ONE = 1;
    public static final byte ONE_COLOR = -1;

    public static final byte MODE_COMMON = 0;
    public static final byte MODE_COLOR = 1;

    public static final byte TIMER_IN = 10;
    public static final byte TIMER_FULL = 11;
    public static final byte TIMER_OUT = 12;
    public static final byte TIMER_ONCE = 13;
    public static final byte TIMER_INVALID = 14;

    public static final byte ENTITY_COMMON = 0;
    public static final byte ENTITY_SPRITE = 1;
    public static final byte ENTITY_CURVE = 2;
    public static final byte ENTITY_SEGMENT = 3;
    public static final byte ENTITY_FLARE = 4;
    public static final byte ENTITY_CUSTOM = 5;
    public static final byte ENTITY_TEXT = 6;

    public static final byte ENTITY_DISTORTION = 0;
    public static final byte ENTITY_ILLUMINANT = 1;

    public static final byte MP_BEAUTY = 0;
    public static final byte MP_DATA = 1; // alphaFragCheck, depth, glowPower, alphaMax
    public static final byte MP_EMISSIVE = 2;
    public static final byte MP_NORMAL = 3;
    public static final byte MP_BLOOM = 4;

    public static final byte AA_DISABLE = 30;
    public static final byte AA_FXAA_CONSOLE = 31;
    public static final byte AA_FXAA_QUALITY = 32;

    public static final byte PARALLEL_JVM = 0;
    public static final byte PARALLEL_GL = 1;
    public static final byte PARALLEL_CL = 2;

    public static final byte GL_DEVICE_AMD_ATI = 0;
    public static final byte GL_DEVICE_NVIDIA = 1;
    public static final byte GL_DEVICE_INTEL = 2;
    public static final byte GL_DEVICE_OTHER = 3;

    private BoxEnum() {}
}
