package org.boxutil.base.api;

/**
 * For any <strong>Direct draw entity</strong>:<p>
 * Attributes of blend is invalid.<p>
 * Always rendering at the highest layer.
 */
public interface DirectDrawEntity {}
