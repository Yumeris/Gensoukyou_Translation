package org.boxutil.base.api;

public interface InstanceDataAPI {
    float[] pickFinal_16F();

    float[] pickTimer_32F();

    float[][] pickState_16F();

    byte[][] pickColor_8F();

    float[] getState();

    byte[] getColorState();

    float[] getTimer();

    void setTimer(float fadeIn, float full, float fadeOut);
}
