package org.boxutil.base;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.boxutil.base.api.InstanceDataAPI;
import org.boxutil.base.api.InstanceRenderAPI;
import org.boxutil.base.api.SimpleVAOAPI;
import org.boxutil.config.BoxConfigs;
import org.boxutil.define.BoxDatabase;
import org.boxutil.define.BoxEnum;
import org.boxutil.manager.KernelCore;
import org.boxutil.manager.ShaderCore;
import org.boxutil.units.standard.attribute.MaterialData;
import org.boxutil.util.CommonUtil;
import org.boxutil.util.KernelUtil;
import org.boxutil.util.TrigUtil;
import org.lwjgl.BufferUtils;
import org.lwjgl.opencl.CL10;
import org.lwjgl.opencl.CL12GL;
import org.lwjgl.opencl.CLMem;
import org.lwjgl.opengl.*;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseInstanceRenderData extends BaseRenderData implements InstanceRenderAPI {
    protected static final byte _FINAL_MATRIX = 0;
    protected static final byte _TIMER = 1;
    protected static final byte _STATE = 2;
    protected static final byte _COLOR = 3;
    // final(vec4 * 2), timer(vec4), state(vec4 * 2), color(vec4 * 2)
    // 2 * tex, 1 * tex, 2 * tex, 1 * tex
    protected static final byte[] _TBO_COUNT_2D = new byte[]{2, 1, 2, 2};
    // final(vec4 * 3), timer(vec4), state(vec4 * 4), color(vec4)
    // 3 * tex, 1 * tex, 4 * tex, 1 * tex
    protected static final byte[] _TBO_COUNT_3D = new byte[]{3, 1, 4, 2};
    protected static final int[] _FORMAT = new int[]{GL30.GL_RGBA16F, GL30.GL_RGBA32F, GL30.GL_RGBA16F, GL11.GL_RGBA8};
    protected List<InstanceDataAPI> instanceData = null;
    // [0][0]final0       = vec4
    // [0][1]final1       = vec4
    // [0][2]final2       = vec4 opt.
    // [1][0]timer        = vec4 **
    // [2][0]state0       = vec4
    // [2][1]state1-3/1-2 = vec12/vec8
    protected final FloatBuffer[][] _instanceDataJVM = new FloatBuffer[][]{null, null, null};
    // final rgba16f * 2/3
    // timer rgba32f * 1
    // state rgba16f * 2/4
    // color rgba16f * 1
    protected final int[][] _instanceDataTBOTex = new int[][]{new int[_TBO_COUNT_3D[_FINAL_MATRIX]], new int[_TBO_COUNT_3D[_TIMER]], new int[_TBO_COUNT_3D[_STATE]], new int[_TBO_COUNT_3D[_COLOR]]};
    protected final int[][] _instanceDataTBO = new int[][]{new int[_TBO_COUNT_3D[_FINAL_MATRIX]], new int[_TBO_COUNT_3D[_TIMER]], new int[_TBO_COUNT_3D[_STATE]], new int[_TBO_COUNT_3D[_COLOR]]};
    // [0][0]final0       => share
    // [0][1]final1       => share
    // [0][2]final2       => share opt.
    // [1][0]timer        => cl
    // [2][0]state0       => share
    // [2][1]state1-3/1-2 => cl
    protected final CLMem[][] _instanceDataMemory = new CLMem[][]{null, null, null, null}; // none color tex, global
    protected int[] instanceRefreshState = new int[]{0, 0, 0, 0}; // index, size, lastSize, renderingCount
    protected byte instanceDataType = 0; // 0-2D, 1-3D, 2-Custom
    protected final boolean[] needRefreshInstanceData = new boolean[]{false, false};

    public BaseInstanceRenderData() {}

    public void delete() {
        super.delete();
        this.resetInstanceData();
    }

    public void glDraw() {
        SimpleVAOAPI quad = ShaderCore.getDefaultQuadObject();
        if (quad == null || !quad.isValid()) return;
        quad.glDraw(Math.min(this.getValidInstanceDataCount(), this.getRenderingCount()));
    }

    /**
     * When call it, will reset data and delete related objects.<p>
     * A.K.A. <strong>free()</strong> for instance data resources.
     */
    public void resetInstanceData() {
        this.instanceData = null;
        this.instanceRefreshState[0] = 0;
        this.instanceRefreshState[1] = 0;
        final boolean instance3DCheck = this.isInstanceData3D();
        if (this.haveValidInstanceData() && BoxConfigs.isTBOSupported()) {
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
            if (BoxConfigs.isJVMParallel()) {
                this._instanceDataJVM[0] = null;
                this._instanceDataJVM[1] = null;
                this._instanceDataJVM[2] = null;
            } else if (BoxConfigs.isGLParallel()) {
                GL11.glDeleteTextures(this._instanceDataTBOTex[_TIMER][0]);
                GL15.glDeleteBuffers(this._instanceDataTBO[_TIMER][0]);
                GL11.glDeleteTextures(this._instanceDataTBOTex[_STATE][1]);
                GL15.glDeleteBuffers(this._instanceDataTBO[_STATE][1]);
                if (instance3DCheck) {
                    GL11.glDeleteTextures(this._instanceDataTBOTex[_STATE][2]);
                    GL15.glDeleteBuffers(this._instanceDataTBO[_STATE][2]);
                    GL11.glDeleteTextures(this._instanceDataTBOTex[_STATE][3]);
                    GL15.glDeleteBuffers(this._instanceDataTBO[_STATE][3]);
                }
                this._instanceDataTBOTex[_TIMER][0] = 0;
                this._instanceDataTBO[_TIMER][0] = 0;
                this._instanceDataTBOTex[_STATE][1] = 0;
                this._instanceDataTBO[_STATE][1] = 0;
                this._instanceDataTBOTex[_STATE][2] = 0;
                this._instanceDataTBO[_STATE][2] = 0;
                this._instanceDataTBOTex[_STATE][3] = 0;
                this._instanceDataTBO[_STATE][3] = 0;
            } else if (BoxConfigs.isCLParallel()) {
                CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][0]);
                CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][3]);
                CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][1]);
                CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][4]);
                CL10.clReleaseMemObject(this._instanceDataMemory[_TIMER][0]);
                CL10.clReleaseMemObject(this._instanceDataMemory[_STATE][2]);
                if (instance3DCheck) {
                    CL10.clReleaseMemObject(this._instanceDataMemory[_STATE][0]);
                    CL10.clReleaseMemObject(this._instanceDataMemory[_STATE][1]);
                    CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][2]);
                    CL10.clReleaseMemObject(this._instanceDataMemory[_FINAL_MATRIX][5]);
                }
                CL10.clReleaseMemObject(this._instanceDataMemory[3][0]);
                this._instanceDataMemory[_FINAL_MATRIX] = null;
                this._instanceDataMemory[_TIMER] = null;
                this._instanceDataMemory[_STATE] = null;
                this._instanceDataMemory[3] = null;
            }
            GL11.glDeleteTextures(this._instanceDataTBOTex[_FINAL_MATRIX][0]);
            GL15.glDeleteBuffers(this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL11.glDeleteTextures(this._instanceDataTBOTex[_FINAL_MATRIX][1]);
            GL15.glDeleteBuffers(this._instanceDataTBO[_FINAL_MATRIX][1]);
            GL11.glDeleteTextures(this._instanceDataTBOTex[_COLOR][0]);
            GL15.glDeleteBuffers(this._instanceDataTBO[_COLOR][0]);
            GL11.glDeleteTextures(this._instanceDataTBOTex[_COLOR][1]);
            GL15.glDeleteBuffers(this._instanceDataTBO[_COLOR][1]);
            if (instance3DCheck) {
                GL11.glDeleteTextures(this._instanceDataTBOTex[_FINAL_MATRIX][2]);
                GL15.glDeleteBuffers(this._instanceDataTBO[_FINAL_MATRIX][2]);
                GL11.glDeleteTextures(this._instanceDataTBOTex[_STATE][0]);
                GL15.glDeleteBuffers(this._instanceDataTBO[_STATE][0]);
            }
            this._instanceDataTBOTex[_FINAL_MATRIX][0] = 0;
            this._instanceDataTBO[_FINAL_MATRIX][0] = 0;
            this._instanceDataTBOTex[_FINAL_MATRIX][1] = 0;
            this._instanceDataTBO[_FINAL_MATRIX][1] = 0;
            this._instanceDataTBOTex[_FINAL_MATRIX][2] = 0;
            this._instanceDataTBO[_FINAL_MATRIX][2] = 0;
            this._instanceDataTBOTex[_STATE][0] = 0;
            this._instanceDataTBO[_STATE][0] = 0;
            this._instanceDataTBOTex[_COLOR][0] = 0;
            this._instanceDataTBO[_COLOR][0] = 0;
            this._instanceDataTBOTex[_COLOR][1] = 0;
            this._instanceDataTBO[_COLOR][1] = 0;
        }
        this.instanceRefreshState[2] = 0;
        this.instanceRefreshState[3] = 0;
        this.needRefreshInstanceData[0] = false;
        this.needRefreshInstanceData[1] = false;
    }

    public List<InstanceDataAPI> getInstanceData() {
        return this.instanceData;
    }

    /**
     * For rendering a lots of entities (such as 10k+ entities) at once.<p>
     * For all render objects, location/facing/size/color/emissive/alpha data all form {@link InstanceDataAPI}.<p>
     * Render count decided by <strong>List.size()</strong>.<p>
     * Have size limit, pick smallest from {@link BoxConfigs#getMaxInstanceDataSize()}.<p>
     * This entity attribute, {@link MaterialData#getColor()} and {@link MaterialData#getEmissiveColor()} both apply to each instance when rendering.<p>
     * For model matrix, each instance is also derived from this entity.
     *
     * @param instanceData set to 'null' or empty 'List' -> clear, or a 'List' what isn't empty.
     * @return return {@link BoxEnum#STATE_SUCCESS} when success, return {@link BoxEnum#STATE_SUCCESS} when over limit.
     */
    public byte setInstanceData(@Nullable List<InstanceDataAPI> instanceData) {
        if (instanceData == null || instanceData.isEmpty()) {
            this.instanceData = null;
            return BoxEnum.STATE_FAILED;
        }
        List<InstanceDataAPI> check = instanceData;
        int limit = BoxConfigs.getMaxInstanceDataSize();
        if (instanceData.size() > limit) check = check.subList(limit - 1, instanceData.size());
        float[] checkTimer = new float[3];
        float[] tmp;
        for (InstanceDataAPI data : check) {
            tmp = data.getTimer();
            if (checkTimer[0] > -500.0f && tmp[1] < checkTimer[0]) checkTimer[0] = tmp[1];
            if (checkTimer[1] > -500.0f && tmp[2] < checkTimer[1]) checkTimer[1] = tmp[2];
            if (checkTimer[2] > -500.0f && tmp[3] < checkTimer[2]) checkTimer[2] = tmp[3];
        }
        this.globalTimer[1] = checkTimer[0];
        this.globalTimer[2] = checkTimer[1];
        this.globalTimer[3] = checkTimer[2];
        this.instanceData = check;
        return BoxEnum.STATE_SUCCESS;
    }

    /**
     * Reset global timer by manual.<p>
     * Similar to {@link #setInstanceData(List)}.
     *
     * @return return {@link BoxEnum#STATE_SUCCESS} when success, return {@link BoxEnum#STATE_FAILED} when over limit.
     */
    public byte setInstanceData(@Nullable List<InstanceDataAPI> instanceData, float fadeIn, float full, float fadeOut) {
        if (instanceData == null || instanceData.isEmpty()) {
            this.instanceData = null;
            return BoxEnum.STATE_FAILED;
        }
        List<InstanceDataAPI> check = instanceData;
        int limit = BoxConfigs.getMaxInstanceDataSize();
        if (instanceData.size() > limit) check = check.subList(limit - 1, instanceData.size());
        this.setGlobalTimer(fadeIn, full, fadeOut);
        this.instanceData = check;
        return BoxEnum.STATE_SUCCESS;
    }

    /**
     * Have size limit {@link BoxConfigs#getMaxInstanceDataSize()}.<p>
     *
     * @return return {@link BoxEnum#STATE_SUCCESS} when success, return {@link BoxEnum#STATE_FAILED} when over limit, return {@link BoxEnum#STATE_FAILED_OTHER} when added a null object.
     */
    public byte addInstanceData(@NotNull InstanceDataAPI instanceData) {
        if (this.instanceData == null) this.instanceData = new ArrayList<>();
        if (this.instanceData.size() > BoxConfigs.getMaxInstanceDataSize()) return BoxEnum.STATE_FAILED;
        if (instanceData == null) {
            this.instanceData.add(null);
            return BoxEnum.STATE_FAILED_OTHER;
        }
        float[] tmp = instanceData.getTimer();
        if (tmp[1] < this.globalTimer[1] && tmp[1] > -500.0f)
            this.globalTimer[1] = tmp[1];
        if (tmp[2] < this.globalTimer[2] && tmp[2] > -500.0f)
            this.globalTimer[2] = tmp[2];
        if (tmp[3] < this.globalTimer[3] && tmp[3] > -500.0f)
            this.globalTimer[3] = tmp[3];
        this.instanceData.add(instanceData);
        return BoxEnum.STATE_SUCCESS;
    }

    /**
     * Use it when you changed the instance data.<p>
     * Put all data, but without calculating.<p>
     * For calculating, if running on JVM mode, it will not create any tmp-TBO, will get a matrix-TBO finally.<p>
     * <p>
     * <strong>Should have reserved size for instance-list, if adds more data later. If not, will clear previous data of all in texture objects when submit.</strong><p>
     * If list size has increased, will force to submit for all data.<p>
     * For submit, here will use {@link GL15#glBufferSubData(int, long, ByteBuffer)} for update TBO, it suitable for frequent submissions, else {@link GL15#glMapBuffer(int, int, ByteBuffer)} required CPU and GPU in synchronized that is unsuitable.<p>
     * <p>
     * Cost <strong>56Byte</strong> of vRAM each 2D-instance, when running on GL mode, entirely GPU calculate; In other words, rendering <strong>32768</strong> instances will cost <strong>1.75MB</strong> of vRAM.<p>
     * For 3D-instance cost <strong>80Byte</strong> and <strong>32768</strong> instances cost <strong>2.5MB</strong> of vRAM.
     *
     * @return return {@link BoxEnum#STATE_SUCCESS} when success.<p> return {@link BoxEnum#STATE_FAILED} when an empty instance data list or refresh count is zero.<p> return {@link BoxEnum#STATE_FAILED_OTHER} when happened another error.
     */
    public byte submitInstanceData() {
        if (this.instanceData == null || this.instanceData.isEmpty()) return BoxEnum.STATE_FAILED;
        if (!BoxConfigs.isTBOSupported()) return BoxEnum.STATE_FAILED_OTHER;
        final int size = this.instanceData.size();
        final boolean newTex = size > this.instanceRefreshState[2];
        final int refreshIndex = newTex ? 0 : this.instanceRefreshState[0];
        final int refreshCount = newTex ? size - refreshIndex : this.instanceRefreshState[1];
        if (refreshCount < 1) return BoxEnum.STATE_FAILED;
        final int refreshLimit = refreshIndex + refreshCount;
        final int pixelSize = refreshCount * 4;
        final long f16Size = pixelSize * 2L;
        final long f32Size = f16Size * 2L;
        final boolean instance3DCheck = this.isInstanceData3D();
        final int baseBufferSize = instance3DCheck ? 6 : 4;

        if (this._instanceDataTBO[_FINAL_MATRIX][0] == 0) {
            IntBuffer tboObject = BufferUtils.createIntBuffer(baseBufferSize);
            IntBuffer tboTex = BufferUtils.createIntBuffer(baseBufferSize);
            GL15.glGenBuffers(tboObject);
            GL11.glGenTextures(tboTex);
            this._instanceDataTBO[_FINAL_MATRIX][0] = tboObject.get(0);
            this._instanceDataTBOTex[_FINAL_MATRIX][0] = tboTex.get(0);
            this._instanceDataTBO[_FINAL_MATRIX][1] = tboObject.get(1);
            this._instanceDataTBOTex[_FINAL_MATRIX][1] = tboTex.get(1);
            this._instanceDataTBO[_COLOR][0] = tboObject.get(2);
            this._instanceDataTBOTex[_COLOR][0] = tboTex.get(2);
            this._instanceDataTBO[_COLOR][1] = tboObject.get(3);
            this._instanceDataTBOTex[_COLOR][1] = tboTex.get(3);
            if (instance3DCheck) {
                this._instanceDataTBO[_FINAL_MATRIX][2] = tboObject.get(4);
                this._instanceDataTBOTex[_FINAL_MATRIX][2] = tboTex.get(4);
                this._instanceDataTBO[_STATE][0] = tboObject.get(5);
                this._instanceDataTBOTex[_STATE][0] = tboTex.get(5);
            }
            if (this._instanceDataTBO[_FINAL_MATRIX][0] == 0 || this._instanceDataTBOTex[_FINAL_MATRIX][0] == 0) return BoxEnum.STATE_FAILED_OTHER;
        }

        byte[][] colorTmp = new byte[2][4];
        ByteBuffer colorBuffer = BufferUtils.createByteBuffer(pixelSize);
        ByteBuffer emissiveBuffer = BufferUtils.createByteBuffer(pixelSize);
        if (newTex) {
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][0]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, pixelSize, GL15.GL_STREAM_DRAW);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][1]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, pixelSize, GL15.GL_STREAM_DRAW);
            if (instance3DCheck) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][2]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][2]);
            }
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][1]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][1]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        }

        if (BoxConfigs.isJVMParallel()) {
            final byte[] chose = instance3DCheck ? new byte[]{3, 4} : new byte[]{2, 2};
            if (this._instanceDataJVM[_FINAL_MATRIX] == null) {
                this._instanceDataJVM[_FINAL_MATRIX] = new FloatBuffer[chose[0]];
                this._instanceDataJVM[_TIMER] = new FloatBuffer[1];
                this._instanceDataJVM[_STATE] = new FloatBuffer[chose[1]];
            }
            final int refreshIndexJVM = refreshIndex * 4;
            if (newTex) {
                this._instanceDataJVM[_FINAL_MATRIX][0] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_FINAL_MATRIX][1] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_TIMER][0] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_STATE][0] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_STATE][1] = BufferUtils.createFloatBuffer(pixelSize);
                if (instance3DCheck) {
                    this._instanceDataJVM[_FINAL_MATRIX][2] = BufferUtils.createFloatBuffer(pixelSize);
                    this._instanceDataJVM[_STATE][2] = BufferUtils.createFloatBuffer(pixelSize);
                    this._instanceDataJVM[_STATE][3] = BufferUtils.createFloatBuffer(pixelSize);
                }
            }
            this._instanceDataJVM[_FINAL_MATRIX][0].position(refreshIndexJVM);
            this._instanceDataJVM[_TIMER][0].position(refreshIndexJVM);
            this._instanceDataJVM[_STATE][0].position(refreshIndexJVM);
            this._instanceDataJVM[_STATE][1].position(refreshIndexJVM);
            if (instance3DCheck) {
                this._instanceDataJVM[_STATE][2].position(refreshIndexJVM);
                this._instanceDataJVM[_STATE][3].position(refreshIndexJVM);
            }
            float[] finalTmp, timerTmp;
            float[][] stateTmp;
            finalTmp = new float[4];
            timerTmp = new float[4];
            stateTmp = new float[4][4];
            for (int i = refreshIndex; i < refreshLimit; i++) {
                InstanceDataAPI data = this.instanceData.get(i);
                if (data == null) {
                    timerTmp[0] = 0.0f;
                } else {
                    finalTmp = data.pickFinal_16F();
                    timerTmp = data.pickTimer_32F();
                    stateTmp = data.pickState_16F();
                    colorTmp = data.pickColor_8F();
                }
                this._instanceDataJVM[_FINAL_MATRIX][0].put(finalTmp);
                this._instanceDataJVM[_TIMER][0].put(timerTmp);
                this._instanceDataJVM[_STATE][0].put(stateTmp[0]);
                this._instanceDataJVM[_STATE][1].put(stateTmp[1]);
                if (instance3DCheck) {
                    this._instanceDataJVM[_STATE][2].put(stateTmp[2]);
                    this._instanceDataJVM[_STATE][3].put(stateTmp[3]);
                }
                colorBuffer.put(colorTmp[0]);
                emissiveBuffer.put(colorTmp[1]);
            }
            this._instanceDataJVM[_FINAL_MATRIX][0].position(0);
            this._instanceDataJVM[_FINAL_MATRIX][0].limit(this._instanceDataJVM[_FINAL_MATRIX][0].capacity());
            this._instanceDataJVM[_FINAL_MATRIX][1].position(0);
            this._instanceDataJVM[_FINAL_MATRIX][1].limit(this._instanceDataJVM[_FINAL_MATRIX][1].capacity());
            this._instanceDataJVM[_TIMER][0].position(0);
            this._instanceDataJVM[_TIMER][0].limit(this._instanceDataJVM[_TIMER][0].capacity());
            this._instanceDataJVM[_STATE][0].position(0);
            this._instanceDataJVM[_STATE][0].limit(this._instanceDataJVM[_STATE][0].capacity());
            this._instanceDataJVM[_STATE][1].position(0);
            this._instanceDataJVM[_STATE][1].limit(this._instanceDataJVM[_STATE][1].capacity());
            if (instance3DCheck) {
                this._instanceDataJVM[_FINAL_MATRIX][2].position(0);
                this._instanceDataJVM[_FINAL_MATRIX][2].limit(this._instanceDataJVM[_FINAL_MATRIX][2].capacity());
                this._instanceDataJVM[_STATE][2].position(0);
                this._instanceDataJVM[_STATE][2].limit(this._instanceDataJVM[_STATE][2].capacity());
                this._instanceDataJVM[_STATE][3].position(0);
                this._instanceDataJVM[_STATE][3].limit(this._instanceDataJVM[_STATE][3].capacity());
            }
        } else if (BoxConfigs.isGLParallel()) {
            final byte[] chose = instance3DCheck ? new byte[]{5, 4} : new byte[]{3, 3};
            final ShortBuffer[] buffers = new ShortBuffer[chose[0]];
            final FloatBuffer timerBuffer = BufferUtils.createFloatBuffer(pixelSize);
            for (byte i = 0; i < buffers.length; i++) {
                buffers[i] = BufferUtils.createShortBuffer(pixelSize);
            }

            float[] finalTmp, timerTmp;
            float[][] stateTmp;
            finalTmp = new float[4];
            timerTmp = new float[4];
            stateTmp = new float[4][4];
            for (int i = refreshIndex; i < refreshLimit; i++) {
                InstanceDataAPI data = this.instanceData.get(i);
                if (data == null) {
                    timerTmp[0] = 0.0f;
                } else {
                    finalTmp = data.pickFinal_16F();
                    timerTmp = data.pickTimer_32F();
                    stateTmp = data.pickState_16F();
                    colorTmp = data.pickColor_8F();
                }
                CommonUtil.putFloat16(buffers[0], finalTmp);
                timerBuffer.put(timerTmp);
                CommonUtil.putFloat16(buffers[1], stateTmp[0]);
                CommonUtil.putFloat16(buffers[2], stateTmp[1]);
                if (instance3DCheck) {
                    CommonUtil.putFloat16(buffers[3], stateTmp[2]);
                    CommonUtil.putFloat16(buffers[4], stateTmp[3]);
                }
                colorBuffer.put(colorTmp[0]);
                emissiveBuffer.put(colorTmp[1]);
            }
            for (ShortBuffer buffer : buffers) {
                buffer.position(0);
                buffer.limit(buffer.capacity());
            }
            timerBuffer.position(0);
            timerBuffer.limit(timerBuffer.capacity());
            if (this._instanceDataTBO[_TIMER][0] == 0) {
                IntBuffer tboObject = BufferUtils.createIntBuffer(chose[1]);
                IntBuffer tboTex = BufferUtils.createIntBuffer(chose[1]);
                GL15.glGenBuffers(tboObject);
                GL11.glGenTextures(tboTex);
                this._instanceDataTBO[_TIMER][0] = tboObject.get(0);
                this._instanceDataTBOTex[_TIMER][0] = tboTex.get(0);
                this._instanceDataTBO[_STATE][1] = tboObject.get(1);
                this._instanceDataTBOTex[_STATE][1] = tboTex.get(1);
                if (instance3DCheck) {
                    this._instanceDataTBO[_STATE][2] = tboObject.get(2);
                    this._instanceDataTBOTex[_STATE][2] = tboTex.get(2);
                    this._instanceDataTBO[_STATE][3] = tboObject.get(3);
                    this._instanceDataTBOTex[_STATE][3] = tboTex.get(3);
                } else {
                    this._instanceDataTBO[_STATE][0] = tboObject.get(2);
                    this._instanceDataTBOTex[_STATE][0] = tboTex.get(2);
                }
                if (this._instanceDataTBO[_TIMER][0] == 0 || this._instanceDataTBOTex[_TIMER][0] == 0) return BoxEnum.STATE_FAILED_OTHER;
            }
            if (newTex) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_TIMER][0]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f32Size, GL15.GL_STREAM_DRAW);
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][1]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                if (instance3DCheck) {
                    GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][2]);
                    GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                    GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][3]);
                    GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                } else {
                    GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                    GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                }
            }
            final long tboRefreshIndex = refreshIndex * 4L * BoxDatabase.HALF_FLOAT_SIZE;
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, buffers[0]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_TIMER][0]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, (long) refreshIndex * 4L * BoxDatabase.FLOAT_SIZE, timerBuffer);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_TIMER][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_TIMER], this._instanceDataTBO[_TIMER][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, buffers[1]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][1]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, buffers[2]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][1]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][1]);
            if (instance3DCheck) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][2]);
                GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, buffers[3]);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][2]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][2]);
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][3]);
                GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, buffers[4]);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][3]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][3]);
            }
        } else if (BoxConfigs.isCLParallel()) {
            final byte chose = (byte) (instance3DCheck ? 3 : 2);
            if (this._instanceDataMemory[0] == null) {
                this._instanceDataMemory[_FINAL_MATRIX] = new CLMem[6];
                this._instanceDataMemory[_TIMER] = new CLMem[1];
                this._instanceDataMemory[_STATE] = new CLMem[3];
                this._instanceDataMemory[_FINAL_MATRIX][0] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0], 0, false, null);
                this._instanceDataMemory[_FINAL_MATRIX][3] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0], 0, true, null);
                this._instanceDataMemory[_FINAL_MATRIX][1] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1], 0, false, null);
                this._instanceDataMemory[_FINAL_MATRIX][4] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1], 0, true, null);
                if (instance3DCheck) {
                    this._instanceDataMemory[_STATE][0] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0], 0, false, null);
                    this._instanceDataMemory[_STATE][1] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0], 0, true, null);
                    this._instanceDataMemory[_FINAL_MATRIX][2] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2], 0, false, null);
                    this._instanceDataMemory[_FINAL_MATRIX][5] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2], 0, true, null);
                }
                if (this._instanceDataMemory[_FINAL_MATRIX][0] == null) return BoxEnum.STATE_FAILED_OTHER;
            }
            if (newTex) {
                if (instance3DCheck) {
                    GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                    GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                }

                this._instanceDataMemory[_TIMER][0] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, f32Size, null);
                this._instanceDataMemory[_STATE][2] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, f32Size * chose, null);
                this._instanceDataMemory[3][0] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, 8, null);
            }
            final int[] clMemSize = new int[]{pixelSize, pixelSize * chose};
            final FloatBuffer timerBuffer = BufferUtils.createFloatBuffer(clMemSize[0]);
            final FloatBuffer stateBuffer = BufferUtils.createFloatBuffer(clMemSize[1]);
            final ShortBuffer finalBuffer = BufferUtils.createShortBuffer(pixelSize);
            ShortBuffer glStateBuffer = null;
            if (instance3DCheck) glStateBuffer = BufferUtils.createShortBuffer(pixelSize);
            float[] finalTmp, timerTmp;
            float[][] stateTmp;
            finalTmp = new float[4];
            timerTmp = new float[4];
            stateTmp = new float[4][4];
            for (int i = refreshIndex; i < refreshLimit; i++) {
                InstanceDataAPI data = this.instanceData.get(i);
                if (data == null) {
                    timerTmp[0] = 0.0f;
                } else {
                    finalTmp = data.pickFinal_16F();
                    timerTmp = data.pickTimer_32F();
                    stateTmp = data.pickState_16F();
                    colorTmp = data.pickColor_8F();
                }
                CommonUtil.putFloat16(finalBuffer, finalTmp);
                timerBuffer.put(timerTmp);
                if (instance3DCheck) {
                    stateBuffer.put(stateTmp[1]);
                    stateBuffer.put(stateTmp[2]);
                    stateBuffer.put(stateTmp[3]);
                    CommonUtil.putFloat16(glStateBuffer, stateTmp[0]);
                } else {
                    stateBuffer.put(stateTmp[0]);
                    stateBuffer.put(stateTmp[1]);
                }
                colorBuffer.put(colorTmp[0]);
                emissiveBuffer.put(colorTmp[1]);
            }
            finalBuffer.flip();
            timerBuffer.flip();
            stateBuffer.flip();
            final int tboRefreshIndex = refreshIndex * 4;
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, finalBuffer);
            if (instance3DCheck) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, tboRefreshIndex, glStateBuffer);
            }
            long startIndex = refreshIndex * 4L;
            CL10.clEnqueueWriteBuffer(KernelCore.getDefaultCLQueue(), this._instanceDataMemory[_TIMER][0], CL10.CL_TRUE, startIndex, timerBuffer, null, null);
            CL10.clEnqueueWriteBuffer(KernelCore.getDefaultCLQueue(), this._instanceDataMemory[_STATE][1], CL10.CL_TRUE, startIndex * chose, stateBuffer, null, null);
        }
        colorBuffer.position(0);
        colorBuffer.limit(colorBuffer.capacity());
        emissiveBuffer.position(0);
        emissiveBuffer.limit(emissiveBuffer.capacity());
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][0]);
        GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, refreshIndex, colorBuffer);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][0]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_COLOR], this._instanceDataTBO[_COLOR][0]);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][1]);
        GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, refreshIndex, emissiveBuffer);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][1]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_COLOR], this._instanceDataTBO[_COLOR][1]);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        this.instanceRefreshState[2] = size;
        return BoxEnum.STATE_SUCCESS;
    }

    /**
     * For generally, automatic running in rendering manager, not required calling it.
     */
    public void sysRefreshInstanceData(float amount, boolean isPaused) {
        if (isPaused && !this.isTimingWhenPaused() || !BoxConfigs.isTBOSupported()) return;
        final boolean instance3DCheck = isInstanceData3D();
        if (BoxConfigs.isJVMParallel()) { // always JVM mode for default.
            this._instanceDataJVM[_FINAL_MATRIX][0].position(0);
            this._instanceDataJVM[_FINAL_MATRIX][0].limit(this._instanceDataJVM[_FINAL_MATRIX][0].capacity());
            this._instanceDataJVM[_FINAL_MATRIX][1].position(0);
            this._instanceDataJVM[_FINAL_MATRIX][1].limit(this._instanceDataJVM[_FINAL_MATRIX][1].capacity());
            this._instanceDataJVM[_TIMER][0].position(0);
            this._instanceDataJVM[_TIMER][0].limit(this._instanceDataJVM[_TIMER][0].capacity());
            this._instanceDataJVM[_STATE][0].position(0);
            this._instanceDataJVM[_STATE][0].limit(this._instanceDataJVM[_STATE][0].capacity());
            this._instanceDataJVM[_STATE][1].position(0);
            this._instanceDataJVM[_STATE][1].limit(this._instanceDataJVM[_STATE][1].capacity());
            if (instance3DCheck) {
                this._instanceDataJVM[_FINAL_MATRIX][2].position(0);
                this._instanceDataJVM[_FINAL_MATRIX][2].limit(this._instanceDataJVM[_FINAL_MATRIX][2].capacity());
                this._instanceDataJVM[_STATE][2].position(0);
                this._instanceDataJVM[_STATE][2].limit(this._instanceDataJVM[_STATE][2].capacity());
                this._instanceDataJVM[_STATE][3].position(0);
                this._instanceDataJVM[_STATE][3].limit(this._instanceDataJVM[_STATE][3].capacity());
            }
            final int finalMatrixFactor = instance3DCheck ? 3 : 2;
            final int bufferSize = this.instanceRefreshState[2] * 4;
            final ShortBuffer[] finalBuffers = new ShortBuffer[instance3DCheck ? 4 : 2];
            float[][] finalMatrix = new float[finalMatrixFactor][4];
            float[] matrixQ = new float[instance3DCheck ? 9 : 2];
            float[] currentRotate, currentScale, dynamicLoc, dynamicRotate, dynamicScale;
            currentRotate = new float[3];
            currentScale = new float[3];
            dynamicLoc = new float[3];
            dynamicRotate = new float[3];
            dynamicScale = new float[3];
            for (int i = 0; i < finalBuffers.length; i++) {
                finalBuffers[i] = BufferUtils.createShortBuffer(bufferSize);
            }

            int indexX, indexY, indexZ, indexW;
            float total, alpha, rotateX, rotateY, rotateZ, sinX, sinY, sinZ, cosX, cosY, cosZ, wq, xq, yq, zq, dqx, dqy, dqz;
            float[] tmpTimer, tmpState;
            tmpTimer = new float[]{-512.0f, 0};
            tmpState = new float[4];
            for (int i = 0; i < this.instanceRefreshState[2]; i++) {
                indexX = i * 4;
                indexY = indexX + 1;
                indexZ = indexX + 2;
                indexW = indexX + 3;
                total = this._instanceDataJVM[_TIMER][0].get(indexX);
                alpha = 21.0f;

                tmpTimer[0] = -512.0f;
                tmpTimer[1] = 0.0f;
                if (total > 2.0f) {
                    alpha = Math.abs(total - 3.0f);
                    tmpTimer[0] = this._instanceDataJVM[_TIMER][0].get(indexY);
                    tmpTimer[1] = 2.0f;
                } else if (total > 1.0f) {
                    tmpTimer[0] = this._instanceDataJVM[_TIMER][0].get(indexZ);
                    tmpTimer[1] = 1.0f;
                } else if (total > 0.0f) {
                    alpha = total + 10.0f;
                    tmpTimer[0] = this._instanceDataJVM[_TIMER][0].get(indexW);
                    tmpTimer[1] = 0.0f;
                }
                total = tmpTimer[0] > -500.0f ? total - tmpTimer[0] * amount : tmpTimer[1];
                total = Math.max(total, 0.0f);
                this._instanceDataJVM[_TIMER][0].put(indexX, total);

                finalMatrix[0][3] = this._instanceDataJVM[_FINAL_MATRIX][0].get(indexW) * BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                finalMatrix[0][2] = this._instanceDataJVM[_FINAL_MATRIX][0].get(indexZ) * BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                if (instance3DCheck) {
                    finalMatrix[0][1] = this._instanceDataJVM[_FINAL_MATRIX][0].get(indexY) * BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                    currentRotate[0] = this._instanceDataJVM[_STATE][0].get(indexX);
                    currentRotate[1] = this._instanceDataJVM[_STATE][0].get(indexY);
                    currentRotate[2] = this._instanceDataJVM[_STATE][0].get(indexZ);
                    currentScale[0] = this._instanceDataJVM[_STATE][1].get(indexX);
                    currentScale[1] = this._instanceDataJVM[_STATE][1].get(indexY);
                    currentScale[2] = this._instanceDataJVM[_STATE][1].get(indexZ);
                    dynamicLoc[0] = this._instanceDataJVM[_STATE][1].get(indexW) * amount;
                    dynamicLoc[1] = this._instanceDataJVM[_STATE][2].get(indexX) * amount;
                    dynamicLoc[2] = this._instanceDataJVM[_STATE][2].get(indexY) * amount;
                    dynamicRotate[0] = this._instanceDataJVM[_STATE][2].get(indexZ) * amount;
                    dynamicRotate[1] = this._instanceDataJVM[_STATE][2].get(indexW) * amount;
                    dynamicRotate[2] = this._instanceDataJVM[_STATE][3].get(indexX) * amount;
                    dynamicScale[0] = this._instanceDataJVM[_STATE][3].get(indexY) * amount;
                    dynamicScale[1] = this._instanceDataJVM[_STATE][3].get(indexZ) * amount;
                    dynamicScale[2] = this._instanceDataJVM[_STATE][3].get(indexW) * amount;
                } else {
                    currentRotate[2] = this._instanceDataJVM[_STATE][0].get(indexZ);
                    currentScale[0] = this._instanceDataJVM[_STATE][0].get(indexX);
                    currentScale[1] = this._instanceDataJVM[_STATE][0].get(indexY);
                    dynamicLoc[0] = this._instanceDataJVM[_STATE][1].get(indexX) * amount;
                    dynamicLoc[1] = this._instanceDataJVM[_STATE][1].get(indexY) * amount;
                    dynamicRotate[2] = this._instanceDataJVM[_STATE][0].get(indexW) * amount;
                    dynamicScale[0] = this._instanceDataJVM[_STATE][1].get(indexZ) * amount;
                    dynamicScale[1] = this._instanceDataJVM[_STATE][1].get(indexW) * amount;
                }

                rotateZ = currentRotate[2] * 0.5f;
                if (instance3DCheck) {
                    rotateX = currentRotate[0] * 0.5f;
                    rotateY = currentRotate[1] * 0.5f;
                    sinX = (float) Math.sin(Math.toRadians(rotateX));
                    cosX = TrigUtil.cosFormSinF(sinX, rotateX);
                    sinY = (float) Math.sin(Math.toRadians(rotateY));
                    cosY = TrigUtil.cosFormSinF(sinY, rotateY);
                    sinZ = (float) Math.sin(Math.toRadians(rotateZ));
                    cosZ = TrigUtil.cosFormSinF(sinZ, rotateZ);
                    wq = cosX * cosY * cosZ - sinX * sinY * sinZ;
                    xq = sinX * cosY * cosZ - cosX * sinY * sinZ;
                    yq = cosX * sinY * cosZ + sinX * cosY * sinZ;
                    zq = cosX * cosY * sinZ + sinX * sinY * cosZ;

                    dqx = xq + xq;
                    dqy = yq + yq;
                    dqz = zq + zq;
                    matrixQ[0] = dqx * xq;
                    matrixQ[1] = dqy * yq;
                    matrixQ[2] = dqz * zq;
                    matrixQ[3] = dqx * yq;
                    matrixQ[4] = dqx * zq;
                    matrixQ[5] = dqx * wq;
                    matrixQ[6] = dqy * zq;
                    matrixQ[7] = dqy * wq;
                    matrixQ[8] = dqz * wq;
                } else {
                    sinZ = (float) Math.sin(Math.toRadians(rotateZ));
                    dqz = rotateZ + rotateZ;
                    matrixQ[0] = dqz * sinZ;
                    matrixQ[1] = dqz * TrigUtil.cosFormSinF(sinZ, rotateZ);
                }

                finalMatrix[0][3] += dynamicLoc[0];
                finalMatrix[0][3] /= BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                finalMatrix[0][2] += dynamicLoc[1];
                finalMatrix[0][2] /= BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                this._instanceDataJVM[_FINAL_MATRIX][0].put(indexW, finalMatrix[0][3]);
                this._instanceDataJVM[_FINAL_MATRIX][0].put(indexZ, finalMatrix[0][2]);
                if (instance3DCheck) {
                    finalMatrix[0][1] += dynamicLoc[2];
                    finalMatrix[0][1] /= BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
                    this._instanceDataJVM[_FINAL_MATRIX][0].put(indexY, finalMatrix[0][1]);
                    tmpState[0] = currentRotate[0] + dynamicRotate[0];
                    tmpState[1] = currentRotate[1] + dynamicRotate[1];
                    tmpState[2] = currentRotate[2] + dynamicRotate[2];
                    tmpState[3] = alpha;
                    this._instanceDataJVM[_STATE][0].put(indexX, tmpState[0]);
                    this._instanceDataJVM[_STATE][0].put(indexY, tmpState[1]);
                    this._instanceDataJVM[_STATE][0].put(indexZ, tmpState[2]);
                    this._instanceDataJVM[_STATE][0].put(indexW, alpha);
                    this._instanceDataJVM[_STATE][1].put(indexX, currentScale[0] + dynamicScale[0]);
                    this._instanceDataJVM[_STATE][1].put(indexY, currentScale[1] + dynamicScale[1]);
                    this._instanceDataJVM[_STATE][1].put(indexZ, currentScale[2] + dynamicScale[2]);

                    finalMatrix[0][0] = currentScale[0] - (matrixQ[1] + matrixQ[2]) * currentScale[0];
                    finalMatrix[1][0] = (matrixQ[3] + matrixQ[8]) * currentScale[0];
                    finalMatrix[1][1] = currentScale[1] - (matrixQ[2] + matrixQ[0]) * currentScale[1];
                    finalMatrix[1][2] = (matrixQ[6] - matrixQ[5]) * currentScale[2];
                    finalMatrix[1][3] = (matrixQ[3] - matrixQ[8]) * currentScale[1];

                    finalMatrix[2][0] = (matrixQ[4] - matrixQ[7]) * currentScale[0];
                    finalMatrix[2][1] = (matrixQ[6] + matrixQ[5]) * currentScale[1];
                    finalMatrix[2][2] = currentScale[2] - (matrixQ[1] + matrixQ[0]) * currentScale[2];
                    finalMatrix[2][3] = (matrixQ[4] + matrixQ[7]) * currentScale[2];
                } else {
                    this._instanceDataJVM[_STATE][0].put(indexX, currentScale[0] + dynamicScale[0]);
                    this._instanceDataJVM[_STATE][0].put(indexY, currentScale[1] + dynamicScale[1]);
                    this._instanceDataJVM[_STATE][0].put(indexZ, currentRotate[2] + dynamicRotate[2]);

                    finalMatrix[0][0] = currentScale[0] - matrixQ[0] * currentScale[0];
                    finalMatrix[0][1] = -matrixQ[1] * currentScale[1];
                    finalMatrix[1][0] = matrixQ[1] * currentScale[0];
                    finalMatrix[1][1] = currentScale[1] - matrixQ[0] * currentScale[1];
                    finalMatrix[1][3] = alpha;
                }

                CommonUtil.putFloat16(finalBuffers[0], finalMatrix[0]);
                CommonUtil.putFloat16(finalBuffers[1], finalMatrix[1]);
                if (instance3DCheck) {
                    CommonUtil.putFloat16(finalBuffers[2], finalMatrix[2]);
                    CommonUtil.putFloat16(finalBuffers[3], tmpState);
                }
            }
            finalBuffers[0].position(0);
            finalBuffers[0].limit(finalBuffers[0].capacity());
            finalBuffers[1].position(0);
            finalBuffers[1].limit(finalBuffers[1].capacity());
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0, finalBuffers[0]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][1]);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0, finalBuffers[1]);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][1]);
            if (instance3DCheck) {
                finalBuffers[2].position(0);
                finalBuffers[2].limit(finalBuffers[2].capacity());
                finalBuffers[3].position(0);
                finalBuffers[3].limit(finalBuffers[3].capacity());
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][2]);
                GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0, finalBuffers[2]);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][2]);
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0, finalBuffers[3]);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][0]);
            }
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        } else if (BoxConfigs.isGLParallel()) { // GL mode.
            BaseShaderData program = instance3DCheck ? ShaderCore.get3DMatrixProgram() : ShaderCore.get2DMatrixProgram();
            final int itemDim = (int) Math.ceil(Math.sqrt(this.getValidInstanceDataCount() / (BoxDatabase.isGLDeviceAMD() ? 64.0f : 32.0f)));
            program.putBindingImageTexture(0, this._instanceDataTBOTex[_FINAL_MATRIX][0], _FORMAT[_FINAL_MATRIX]);
            program.putBindingImageTexture(1, this._instanceDataTBOTex[_FINAL_MATRIX][1], _FORMAT[_FINAL_MATRIX]);
            program.putBindingImageTexture(3, this._instanceDataTBOTex[_STATE][0], _FORMAT[_STATE]);
            program.putBindingImageTexture(7, this._instanceDataTBOTex[_TIMER][0], _FORMAT[_TIMER]);
            if (instance3DCheck) {
                program.putBindingImageTexture(2, this._instanceDataTBOTex[_FINAL_MATRIX][2], _FORMAT[_FINAL_MATRIX]);
                program.putBindingImageTexture(4, this._instanceDataTBOTex[_STATE][1], _FORMAT[_STATE]);
                program.putBindingImageTextureReadOnly(5, this._instanceDataTBOTex[_STATE][2], _FORMAT[_STATE]);
                program.putBindingImageTextureReadOnly(6, this._instanceDataTBOTex[_STATE][3], _FORMAT[_STATE]);
            } else program.putBindingImageTextureReadOnly(4, this._instanceDataTBOTex[_STATE][1], _FORMAT[_STATE]);
            GL20.glUniform2f(program.location[0], amount, this.getValidInstanceDataCount());
            GL43.glDispatchCompute(1, itemDim, itemDim);
        } else if (BoxConfigs.isCLParallel()) { // CL mode.
            boolean isAMD = BoxDatabase.getGLState().GL_CURRENT_DEVICE_VENDOR_BYTE == BoxEnum.GL_DEVICE_AMD_ATI;
            final long itemDim = (long) Math.ceil(Math.sqrt(this.getValidInstanceDataCount() / (BoxDatabase.isGLDeviceAMD() ? 64.0f : 32.0f)));
            BaseKernelData kernel = instance3DCheck ? KernelCore.getInstanceKernel3D() : KernelCore.getInstanceKernel2D();
            kernel.bindKernelArg(0, this.getInstanceDataMemory()[_FINAL_MATRIX][0]);
            kernel.bindKernelArg(1, this.getInstanceDataMemory()[_FINAL_MATRIX][3]);
            kernel.bindKernelArg(2, this.getInstanceDataMemory()[_FINAL_MATRIX][1]);
            kernel.bindKernelArg(3, this.getInstanceDataMemory()[_FINAL_MATRIX][4]);
            final int[] index = instance3DCheck ? new int[]{6, 7, 8, 9, 10, 11} : new int[]{4, 5, 6, 7, 8, 9};
            if (instance3DCheck) {
                kernel.bindKernelArg(4, this.getInstanceDataMemory()[_FINAL_MATRIX][2]);
                kernel.bindKernelArg(5, this.getInstanceDataMemory()[_FINAL_MATRIX][5]);
            }
            kernel.bindKernelArg(index[0], this.getInstanceDataMemory()[_TIMER][0]);
            kernel.bindKernelArg(index[1], this.getInstanceDataMemory()[_STATE][0]);
            kernel.bindKernelArg(index[2], this.getInstanceDataMemory()[_STATE][1]);
            kernel.bindKernelArg(index[3], this.getInstanceDataMemory()[_STATE][2]);
            kernel.bindKernelArg(index[4], KernelCore.getInstanceSampler());
            FloatBuffer buffer = BufferUtils.createFloatBuffer(2);
            buffer.put(amount);
            buffer.put(this.getValidInstanceDataCount());
            buffer.flip();
            CL10.clEnqueueWriteBuffer(KernelCore.getDefaultCLQueue(), this.getInstanceDataMemory()[3][0], CL10.CL_TRUE, 0, buffer, null, null);
            kernel.bindKernelArg(index[5], this.getInstanceDataMemory()[3][0]);
            final long[] local = isAMD ? new long[]{4, 16} : new long[]{4, 8};
            kernel.enqueueND(2, new long[]{itemDim, itemDim}, local);
        }
        if (!this.isAlwaysRefreshInstanceData()) this.callRefreshInstanceData(false);
    }

    /**
     * Optional.<p>
     * Just <strong>malloc()</strong> without any submit call.
     *
     * @param dataNum must be positive integer.
     *
     * @return return {@link BoxEnum#STATE_SUCCESS} when success.<p> return {@link BoxEnum#STATE_FAILED} when parameter error.<p> return {@link BoxEnum#STATE_FAILED_OTHER} when happened another error.
     */
    public byte mallocInstanceData(int dataNum) {
        if (dataNum < 1) return BoxEnum.STATE_FAILED;
        final int pixelSize = dataNum * 4;
        final long f16Size = pixelSize * 2L;
        final long f32Size = f16Size * 2L;
        final boolean instance3DCheck = this.isInstanceData3D();
        final int baseBufferSize = instance3DCheck ? 6 : 4;

        if (this._instanceDataTBO[_FINAL_MATRIX][0] == 0) {
            IntBuffer tboObject = BufferUtils.createIntBuffer(baseBufferSize);
            IntBuffer tboTex = BufferUtils.createIntBuffer(baseBufferSize);
            GL15.glGenBuffers(tboObject);
            GL11.glGenTextures(tboTex);
            this._instanceDataTBO[_FINAL_MATRIX][0] = tboObject.get(0);
            this._instanceDataTBOTex[_FINAL_MATRIX][0] = tboTex.get(0);
            this._instanceDataTBO[_FINAL_MATRIX][1] = tboObject.get(1);
            this._instanceDataTBOTex[_FINAL_MATRIX][1] = tboTex.get(1);
            this._instanceDataTBO[_COLOR][0] = tboObject.get(2);
            this._instanceDataTBOTex[_COLOR][0] = tboTex.get(2);
            this._instanceDataTBO[_COLOR][1] = tboObject.get(3);
            this._instanceDataTBOTex[_COLOR][1] = tboTex.get(3);
            if (instance3DCheck) {
                this._instanceDataTBO[_FINAL_MATRIX][2] = tboObject.get(4);
                this._instanceDataTBOTex[_FINAL_MATRIX][2] = tboTex.get(4);
                this._instanceDataTBO[_STATE][0] = tboObject.get(5);
                this._instanceDataTBOTex[_STATE][0] = tboTex.get(5);
            }
            if (this._instanceDataTBO[_FINAL_MATRIX][0] == 0 || this._instanceDataTBOTex[_FINAL_MATRIX][0] == 0) return BoxEnum.STATE_FAILED_OTHER;
        }

        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][0]);
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][0]);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][0]);
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, pixelSize, GL15.GL_STREAM_DRAW);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][0]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_COLOR], this._instanceDataTBO[_COLOR][0]);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_COLOR][1]);
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, pixelSize, GL15.GL_STREAM_DRAW);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][1]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_COLOR], this._instanceDataTBO[_COLOR][1]);
        if (instance3DCheck) {
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][2]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][2]);
        }
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_FINAL_MATRIX][1]);
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1]);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_FINAL_MATRIX], this._instanceDataTBO[_FINAL_MATRIX][1]);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);

        if (BoxConfigs.isJVMParallel()) {
            final byte[] chose = instance3DCheck ? new byte[]{3, 4} : new byte[]{2, 2};
            if (this._instanceDataJVM[_FINAL_MATRIX] == null) {
                this._instanceDataJVM[_FINAL_MATRIX] = new FloatBuffer[chose[0]];
                this._instanceDataJVM[_TIMER] = new FloatBuffer[1];
                this._instanceDataJVM[_STATE] = new FloatBuffer[chose[1]];
            }
            this._instanceDataJVM[_FINAL_MATRIX][0] = BufferUtils.createFloatBuffer(pixelSize);
            this._instanceDataJVM[_FINAL_MATRIX][1] = BufferUtils.createFloatBuffer(pixelSize);
            this._instanceDataJVM[_TIMER][0] = BufferUtils.createFloatBuffer(pixelSize);
            this._instanceDataJVM[_STATE][0] = BufferUtils.createFloatBuffer(pixelSize);
            this._instanceDataJVM[_STATE][1] = BufferUtils.createFloatBuffer(pixelSize);
            if (instance3DCheck) {
                this._instanceDataJVM[_FINAL_MATRIX][2] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_STATE][2] = BufferUtils.createFloatBuffer(pixelSize);
                this._instanceDataJVM[_STATE][3] = BufferUtils.createFloatBuffer(pixelSize);
            }
        } else if (BoxConfigs.isGLParallel()) {
            final byte chose = (byte) (instance3DCheck ? 4 : 3);
            if (this._instanceDataTBO[_TIMER][0] == 0) {
                IntBuffer tboObject = BufferUtils.createIntBuffer(chose);
                IntBuffer tboTex = BufferUtils.createIntBuffer(chose);
                GL15.glGenBuffers(tboObject);
                GL11.glGenTextures(tboTex);
                this._instanceDataTBO[_TIMER][0] = tboObject.get(0);
                this._instanceDataTBOTex[_TIMER][0] = tboTex.get(0);
                this._instanceDataTBO[_STATE][1] = tboObject.get(1);
                this._instanceDataTBOTex[_STATE][1] = tboTex.get(1);
                if (instance3DCheck) {
                    this._instanceDataTBO[_STATE][2] = tboObject.get(2);
                    this._instanceDataTBOTex[_STATE][2] = tboTex.get(2);
                    this._instanceDataTBO[_STATE][3] = tboObject.get(3);
                    this._instanceDataTBOTex[_STATE][3] = tboTex.get(3);
                } else {
                    this._instanceDataTBO[_STATE][0] = tboObject.get(2);
                    this._instanceDataTBOTex[_STATE][0] = tboTex.get(2);
                }
                if (this._instanceDataTBO[_TIMER][0] == 0 || this._instanceDataTBOTex[_TIMER][0] == 0) return BoxEnum.STATE_FAILED_OTHER;
            }

            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_TIMER][0]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f32Size, GL15.GL_STREAM_DRAW);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_TIMER][0]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_TIMER], this._instanceDataTBO[_TIMER][0]);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][1]);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][1]);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][1]);
            if (instance3DCheck) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][2]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][2]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][2]);
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][3]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][3]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][3]);
            } else {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
                GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0]);
                GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, _FORMAT[_STATE], this._instanceDataTBO[_STATE][0]);
            }
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        } else if (BoxConfigs.isCLParallel()) {
            final byte chose = (byte) (instance3DCheck ? 3 : 2);
            if (this._instanceDataMemory[0] == null) {
                this._instanceDataMemory[_FINAL_MATRIX] = new CLMem[6];
                this._instanceDataMemory[_TIMER] = new CLMem[1];
                this._instanceDataMemory[_STATE] = new CLMem[3];
                this._instanceDataMemory[_FINAL_MATRIX][0] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0], 0, false, null);
                this._instanceDataMemory[_FINAL_MATRIX][3] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0], 0, true, null);
                this._instanceDataMemory[_FINAL_MATRIX][1] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1], 0, false, null);
                this._instanceDataMemory[_FINAL_MATRIX][4] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1], 0, true, null);
                if (instance3DCheck) {
                    this._instanceDataMemory[_STATE][0] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0], 0, false, null);
                    this._instanceDataMemory[_STATE][1] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0], 0, true, null);
                    this._instanceDataMemory[_FINAL_MATRIX][2] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2], 0, false, null);
                    this._instanceDataMemory[_FINAL_MATRIX][5] = KernelUtil.shareTextureAny(CL12GL.CL_GL_OBJECT_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2], 0, true, null);
                }
                if (this._instanceDataMemory[_FINAL_MATRIX][0] == null) return BoxEnum.STATE_FAILED_OTHER;
            }

            if (instance3DCheck) {
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBO[_STATE][0]);
                GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, f16Size, GL15.GL_STREAM_DRAW);
            }

            this._instanceDataMemory[_TIMER][0] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, f32Size, null);
            this._instanceDataMemory[_STATE][2] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, f32Size * chose, null);
            this._instanceDataMemory[3][0] = KernelUtil.ioBuffer(CL10.CL_MEM_READ_WRITE, 8, null);
        }
        this.instanceRefreshState[2] = dataNum;
        return BoxEnum.STATE_SUCCESS;
    }

    public boolean isNeedRefreshInstanceData() {
        return this.needRefreshInstanceData[0] || this.needRefreshInstanceData[1];
    }

    public boolean isAlwaysRefreshInstanceData() {
        return this.needRefreshInstanceData[1];
    }

    /**
     * When changed the instance data, call it.
     */
    public void callRefreshInstanceData(boolean refresh) {
        this.needRefreshInstanceData[0] = refresh;
    }

    public void setAlwaysRefreshInstanceData(boolean refresh) {
        this.needRefreshInstanceData[1] = refresh;
    }

    public boolean haveInstanceData() {
        return this.instanceData != null && !this.instanceData.isEmpty();
    }

    public boolean haveValidInstanceData() {
        return this.getValidInstanceDataCount() > 0;
    }

    public int getValidInstanceDataCount() {
        return this.instanceRefreshState[2];
    }

    public FloatBuffer[][] getInstanceDataTmpBufferJVM() {
        return this._instanceDataJVM;
    }

    public int[][] getInstanceDataTBO() {
        return this._instanceDataTBO;
    }

    public int[][] getInstanceDataTBOTex() {
        return this._instanceDataTBOTex;
    }

    public CLMem[][] getInstanceDataMemory() {
        return this._instanceDataMemory;
    }

    public void putShaderInstanceData() {
        boolean instance3DCheck = isInstanceData3D();
        GL13.glActiveTexture(GL13.GL_TEXTURE10);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][0]);
        GL13.glActiveTexture(GL13.GL_TEXTURE11);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][1]);
        if (instance3DCheck) {
            GL13.glActiveTexture(GL13.GL_TEXTURE12);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_FINAL_MATRIX][2]);
            GL13.glActiveTexture(GL13.GL_TEXTURE13);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_STATE][0]);
        }
        GL13.glActiveTexture(GL13.GL_TEXTURE14);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][0]);
        GL13.glActiveTexture(GL13.GL_TEXTURE15);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this._instanceDataTBOTex[_COLOR][1]);
    }

    public int getInstanceDataRefreshIndex() {
        return this.instanceRefreshState[0];
    }

    public int getInstanceDataRefreshSize() {
        return this.instanceRefreshState[1];
    }

    /**
     * @param index will refresh instance data start from this index.
     */
    public void setInstanceDataRefreshIndex(int index) {
        if (this.instanceData == null) return;
        this.instanceRefreshState[0] = Math.min(Math.max(index, 0), Math.max(this.instanceData.size() - 1, 0));
    }

    /**
     * @param size Will refresh instance data count.
     */
    public void setInstanceDataRefreshSize(int size) {
        if (this.instanceData == null) return;
        int total = this.instanceData.size();
        this.instanceRefreshState[1] = this.instanceRefreshState[0] + size > total ? total - this.instanceRefreshState[0] : size;
    }

    public void setInstanceDataRefreshAllFromCurrentIndex() {
        if (this.instanceData == null) return;
        this.instanceRefreshState[1] = this.instanceData.size() - this.instanceRefreshState[0];
    }

    public int getRenderingCount() {
        return this.instanceRefreshState[3];
    }

    public void setRenderingCount(int num) {
        this.instanceRefreshState[3] = num;
    }

    public byte getInstanceDataType() {
        return this.instanceDataType;
    }

    public boolean isInstanceData2D() {
        return this.instanceDataType == 0;
    }

    /**
     * Must call it before {@link InstanceRenderAPI#submitInstanceData()}, or after {@link InstanceRenderAPI#resetInstanceData} has called.
     */
    public void setUseInstanceData2D() {
        this.instanceDataType = 0;
    }

    public boolean isInstanceData3D() {
        return this.instanceDataType == 1;
    }

    /**
     * Must call it before {@link InstanceRenderAPI#submitInstanceData()}, or after {@link InstanceRenderAPI#resetInstanceData} has called.
     */
    public void setUseInstanceData3D() {
        this.instanceDataType = 1;
    }

    public boolean isInstanceDataCustom() {
        return this.instanceDataType == 2;
    }

    /**
     * Will be recognized as 3D-data.<p>
     * If call it, should override {@link InstanceRenderAPI#submitInstanceData()} and {@link InstanceRenderAPI#sysRefreshInstanceData(float, boolean)} in your class.<p>
     * Must call it before {@link InstanceRenderAPI#submitInstanceData()}, or after {@link InstanceRenderAPI#resetInstanceData} has called.
     */
    public void setUseInstanceDataCustom() {
        this.instanceDataType = 2;
    }

    /**
     * Use 2D-data for default.<p>
     * Must call it before {@link InstanceRenderAPI#submitInstanceData()}, or after {@link InstanceRenderAPI#resetInstanceData} has called.
     */
    public void setUseDefaultInstanceData() {
        this.instanceDataType = 0;
    }

    public byte getGlobalTimerState() {
        if (this.haveValidInstanceData() && this.globalTimer[0] > 0.0f) return BoxEnum.TIMER_FULL;
        else if (this.globalTimer[0] > 2.0f) return BoxEnum.TIMER_IN;
        else if (this.globalTimer[0] > 1.0f) return BoxEnum.TIMER_FULL;
        else if (this.globalTimer[0] > 0.0f) return BoxEnum.TIMER_OUT;
        else return this.isGlobalTimerOnce() ? BoxEnum.TIMER_ONCE : BoxEnum.TIMER_INVALID;
    }
}
