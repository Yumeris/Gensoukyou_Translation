package org.boxutil.base;

import org.boxutil.base.api.InstanceDataAPI;
import org.boxutil.base.api.InstanceRenderAPI;
import org.boxutil.base.api.RenderDataAPI;
import org.boxutil.units.standard.attribute.Instance2Data;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * <strong>Very^32</strong> simple particle dynamic resource manager.<p>
 * Only for one entity.<p>
 * For reference.
 */
public class SimpleParticleControlData extends BaseControlData {
    protected InstanceRenderAPI entity = null;
    protected final int[] state = new int[4]; // currIndex, lastIndex, renderingCount, maxCount
    protected final float[] stateF = new float[3]; // timer, dataTimer, maxDur
    protected final boolean[] stateB = new boolean[4]; // indexReset, fullRefresh, invalid, ignorePaused

    public void addParticle(Vector2f location, float facing, float turnRate, Vector2f velocity, Vector2f scale, Vector2f scaleRate, Color basecolor, Color emissive, float in, float full, float out) {
        if (this.stateB[2]) return;
        if (this.state[0] == this.state[1] && !this.stateB[0]) {
            this.stateF[0] = this.stateF[2];
            this.entity.setAlwaysRefreshInstanceData(true);
        }
        if (this.state[0] >= this.state[3]) this.state[0] = 0;

        Instance2Data data = new Instance2Data();
        data.setLocation(location);
        data.setFacing(facing);
        data.setTurnRate(turnRate);
        data.setVelocity(velocity);
        data.setScale(scale);
        data.setScaleRate(scaleRate);
        data.setColor(basecolor);
        data.setEmissiveColor(emissive);
        data.setTimer(in, full, out);
        this.entity.getInstanceData().set(this.state[0], data);
        if (this.state[2] < this.state[3]) this.state[2]++;

        this.state[0]++;
        if (this.stateB[0] && this.state[0] >= this.state[1]) this.stateB[1] = true;
        if (this.state[0] <= this.state[1]) this.stateB[0] = true;
    }

    /**
     * @param dataDur rendering once if at <strong>(-3000.0f, -1000.0f)</strong>, always active if less than <strong>-3000.0f</strong>.
     */
    public SimpleParticleControlData(int maxParticles, float maxDur, float dataDur, boolean ignorePaused) {
        this.state[3] = maxParticles;
        this.stateF[1] = dataDur;
        this.stateF[2] = maxDur;
        this.stateB[3] = ignorePaused;
    }

    public void controlInit(@NotNull RenderDataAPI renderEntity) {
        this.stateB[2] = !(renderEntity instanceof InstanceRenderAPI);
        if (this.stateB[2]) return;
        this.entity = (InstanceRenderAPI) renderEntity;
        this.entity.setUseInstanceData2D();
        this.entity.mallocInstanceData(this.state[3]);
    }

    public void controlAdvance(@NotNull RenderDataAPI renderEntity, float amount) {
        if (this.stateB[2] || !this.controlCanRenderNow(renderEntity)) return;
        if (this.state[0] != this.state[1] || this.stateB[0]) {
            if (this.stateB[1]) {
                this.entity.setInstanceDataRefreshIndex(0);
                this.entity.setInstanceDataRefreshAllFromCurrentIndex();
                this.entity.submitInstanceData();
            } else {
                if (this.stateB[0]) {
                    this.entity.setInstanceDataRefreshIndex(this.state[1]);
                    this.entity.setInstanceDataRefreshAllFromCurrentIndex();
                    this.entity.submitInstanceData();
                }
                this.entity.setInstanceDataRefreshIndex(0);
                this.entity.setInstanceDataRefreshSize(this.state[0]);
                this.entity.submitInstanceData();
            }
            if (this.state[0] >= this.state[3]) this.state[0] = 0;
            this.stateB[1] = false;
            this.stateB[0] = false;
            this.state[1] = this.state[0];
            this.entity.setRenderingCount(this.state[2]);
        }
        if (this.stateF[0] > 0.0f) this.stateF[0] -= amount;
        else if (this.state[2] > 0) {
            this.entity.setAlwaysRefreshInstanceData(false);
            this.entity.setRenderingCount(0);
            this.state[0] = 0;
            this.state[1] = 0;
            this.state[2] = 0;
        }
        if (this.stateF[1] > 0.0f) this.stateF[1] -= amount;
    }

    public boolean controlAlphaBasedTimer(@NotNull RenderDataAPI renderEntity) {
        return false;
    }

    public boolean controlRemoveBasedTimer(@NotNull RenderDataAPI renderEntity) {
        return false;
    }

    public boolean controlRunWhilePaused(@NotNull RenderDataAPI renderEntity) {
        return this.stateB[3];
    }

    public boolean controlIsOnceRender(@NotNull RenderDataAPI renderEntity) {
        return this.stateF[1] > -3000.0f && this.stateF[1] < -1000.0f;
    }

    public boolean controlIsDone(@NotNull RenderDataAPI renderEntity) {
        return this.stateB[2] || (this.stateF[1] > -1000.0f && this.stateF[1] < 0.0f);
    }

    public boolean controlCanRenderNow(@NotNull RenderDataAPI renderEntity) {
        return this.state[2] > 0;
    }
}
