package org.boxutil.units.builtin.shader;

import org.boxutil.base.BaseShaderData;

public class BUtil_ShaderProgram extends BaseShaderData {
    public BUtil_ShaderProgram(int id) {
        super(id);
    }
}
