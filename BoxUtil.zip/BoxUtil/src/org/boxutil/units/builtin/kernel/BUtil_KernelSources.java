package org.boxutil.units.builtin.kernel;

/**
 * <strong>DO NOT EDIT THEM.</strong>
 */
@Deprecated
public final class BUtil_KernelSources {
    public final static class InstanceMatrix {
        private InstanceMatrix() {}

        public final static String KERNEL_NAME_2D = "createInstanceMatrix2D";

        public final static String KERNEL_2D = "#define INSTANCE_SCALE INSTANCE_SCALE_VALUE\n" +
                "\n" +
                "__kernel void createInstanceMatrix2D(\n" +
                "    __read_only image1d_t final0R, __write_only image1d_t final0W,\n" +
                "    __read_only image1d_t final1R, __write_only image1d_t final1W,\n" +
                "    __global float4 *timerT,\n" +
                "    __global float4 *state1In,\n" +
                "    sampler_t samplerIn, float2 globalState\n" +
                ") {\n" +
                "    int2 vIndex = (int2) (get_global_id(0), get_global_id(1)) + 1;\n" +
                "    int index = vIndex.x * vIndex.y - 1;\n" +
                "    float4 timer = timerT[index];\n" +
                "    if (index >= (int) (globalState.x) || timer.y <= 0.0) return;\n" +
                "    float4 final0 = read_imagef(final0R, samplerIn, index);\n" +
                "    float4 final1 = read_imagef(final1R, samplerIn, index);\n" +
                "\tint stateIndex = index * 2;\n" +
                "    float4 state0 = state1In[stateIndex];\n" +
                "    float4 state1 = state1In[stateIndex + 1];\n" +
                "\n" +
                "    float2 loc = final0.wz * INSTANCE_SCALE;\n" +
                "\tfloat facing = state0.z;\n" +
                "\tfloat2 scale = state0.xy;\n" +
                "\n" +
                "    // dLoc, dScale\n" +
                "\tfloat4 dynamic = state1 * globalState.x;\n" +
                "    float turnRate = state0.w * globalState.x;\n" +
                "\n" +
                "    float pryRotate = facing * 0.5f;\n" +
                "\tfloat prySin = native_sin(radians(pryRotate));\n" +
                "\tfloat pryCos = sqrt(1.0f - prySin * prySin);\n" +
                "    if (pryRotate > 90.0f) pryCos = -pryCos;\n" +
                "\n" +
                "\tfloat dqz = prySin + prySin;\n" +
                "\tfloat q22 = dqz * prySin;\n" +
                "\tfloat q23 = dqz * pryCos;\n" +
                "\n" +
                "    float alpha = 21.0f;\n" +
                "\tfloat2 timerTmp = (float2) (-512.0f);\n" +
                "\tuint timerCheck = (uint) (timer.x);\n" +
                "\tif (timerCheck > 2u) {\n" +
                "\t\talpha = fabs(timer.x - 3.0f);\n" +
                "\t\ttimerTmp = (float2) (timer.y, 2.0f);\n" +
                "\t}\n" +
                "\tif (timerCheck == 1u) {\n" +
                "\t\ttimerTmp = (float2) (timer.z, 1.0f);\n" +
                "\t}\n" +
                "\tif (timerCheck == 0u) {\n" +
                "\t\talpha = timer.x + 10.0f;\n" +
                "\t\ttimerTmp = (float2) (timer.w, 0.0f);\n" +
                "\t}\n" +
                "\ttimer.x = timerTmp.x > -500.0f ? (timer.x - timerTmp.x * globalState.x) : timerTmp.y;\n" +
                "\ttimer.x = max(timer.x, 0.0f);\n" +
                "    timerT[index] = timer;\n" +
                "\n" +
                "    loc += dynamic.xy;\n" +
                "\tloc /= INSTANCE_SCALE;\n" +
                "\tfacing = fmod(facing + turnRate + 360.0f, 360.0f);\n" +
                "\tscale += dynamic.zw;\n" +
                "    write_imagef(final0W, index, (float4) (\n" +
                "\t\tscale.x - q22 * scale.x,\n" +
                "\t\t-q23 * scale.y,\n" +
                "\t\tloc.y,\n" +
                "\t\tloc.x\n" +
                "\t));\n" +
                "    write_imagef(final1W, index, (float4) (\n" +
                "\t\tq23 * scale.x,\n" +
                "\t\tscale.y -q22 * scale.y,\n" +
                "\t\t0.0f,\n" +
                "\t\talpha\n" +
                "\t));\n" +
                "\n" +
                "\tstate1In[stateIndex] = (float4) (scale, facing, state1.w);\n" +
                "}\n";

        public final static String KERNEL_NAME_3D = "createInstanceMatrix3D";

        public final static String KERNEL_3D = "#define INSTANCE_SCALE INSTANCE_SCALE_VALUE\n" +
                "\n" +
                "__kernel void createInstanceMatrix3D(\n" +
                "    __read_only image1d_t final0R, __write_only image1d_t final0W,\n" +
                "    __read_only image1d_t final1R, __write_only image1d_t final1W,\n" +
                "    __read_only image1d_t final2R, __write_only image1d_t final2W,\n" +
                "    __global float4 *timerT,\n" +
                "    __read_only image1d_t state0R, __write_only image1d_t state0W,\n" +
                "    __global float4 *state1_3,\n" +
                "    sampler_t samplerIn, float2 globalState\n" +
                ") {\n" +
                "    int2 vIndex = (int2) (get_global_id(0), get_global_id(1)) + 1;\n" +
                "    int index = vIndex.x * vIndex.y - 1;\n" +
                "    float4 timer = timerT[index];\n" +
                "    if (index >= (int) (globalState.x) || timer.y <= 0.0) return;\n" +
                "    float4 final0 = read_imagef(final0R, samplerIn, index);\n" +
                "    float4 final1 = read_imagef(final1R, samplerIn, index);\n" +
                "    float4 final2 = read_imagef(final2R, samplerIn, index);\n" +
                "    float4 state0 = read_imagef(state0R, samplerIn, index);\n" +
                "    int state1Index = index * 3;\n" +
                "    int state2Index = state1Index + 1;\n" +
                "    int state3Index = state2Index + 1;\n" +
                "    float4 state1 = state1_3[state1Index];\n" +
                "    float4 state2 = state1_3[state2Index];\n" +
                "    float4 state3 = state1_3[state3Index];\n" +
                "\n" +
                "    float3 loc = final0.wyz * INSTANCE_SCALE;\n" +
                "\tfloat3 rotate = (float3) (state0.x, state0.y, state0.z);\n" +
                "\tfloat3 scale = (float3) (state1.x, state1.y, state1.z);\n" +
                "\n" +
                "    // dLoc, dRotate, dScale\n" +
                "\tfloat8 dynamic = (float8) (\n" +
                "\t\tstate1.w, state2.x, state2.y,\n" +
                "\t\tstate2.z, state2.w, state3.x,\n" +
                "\t\tstate3.y, state3.z\n" +
                "\t);\n" +
                "    float dScaleZ = state3.w;\n" +
                "\tdynamic *= globalState.x;\n" +
                "    dScaleZ *= globalState.x;\n" +
                "\n" +
                "    float3 pryRotate = radians(rotate * 0.5f);\n" +
                "\tfloat3 prySin = native_sin(pryRotate);\n" +
                "\tfloat3 pryCos = sqrt(1.0f - pryRotate * pryRotate);\n" +
                "    if (rotate.x > 90.0f && rotate.x < 270.0f) pryCos.x = -pryCos.x;\n" +
                "\tif (rotate.y > 90.0f && rotate.y < 270.0f) pryCos.y = -pryCos.y;\n" +
                "\tif (rotate.z > 90.0f && rotate.z < 270.0f) pryCos.z = -pryCos.z;\n" +
                "\n" +
                "\tfloat wq = pryCos.x * pryCos.y * pryCos.z - prySin.x * prySin.y * prySin.z;\n" +
                "\tfloat xq = prySin.x * pryCos.y * pryCos.z - pryCos.x * prySin.y * prySin.z;\n" +
                "\tfloat yq = pryCos.x * prySin.y * pryCos.z + prySin.x * pryCos.y * prySin.z;\n" +
                "\tfloat zq = pryCos.x * pryCos.y * prySin.z + prySin.x * prySin.y * pryCos.z;\n" +
                "\n" +
                "\tfloat dqx = xq + xq;\n" +
                "\tfloat dqy = yq + yq;\n" +
                "\tfloat dqz = zq + zq;\n" +
                "\tfloat q00 = dqx * xq;\n" +
                "\tfloat q11 = dqy * yq;\n" +
                "\tfloat q22 = dqz * zq;\n" +
                "\tfloat q01 = dqx * yq;\n" +
                "\tfloat q02 = dqx * zq;\n" +
                "\tfloat q03 = dqx * wq;\n" +
                "\tfloat q12 = dqy * zq;\n" +
                "\tfloat q13 = dqy * wq;\n" +
                "\tfloat q23 = dqz * wq;\n" +
                "\n" +
                "    float alpha = 21.0f;\n" +
                "\tfloat2 timerTmp = (float2) (-512.0f);\n" +
                "\tuint timerCheck = (uint) (timer.x);\n" +
                "\tif (timerCheck > 2u) {\n" +
                "\t\talpha = fabs(timer.x - 3.0f);\n" +
                "\t\ttimerTmp = (float2) (timer.y, 2.0f);\n" +
                "\t}\n" +
                "\tif (timerCheck == 1u) {\n" +
                "\t\ttimerTmp = (float2) (timer.z, 1.0f);\n" +
                "\t}\n" +
                "\tif (timerCheck == 0u) {\n" +
                "\t\talpha = timer.x + 10.0f;\n" +
                "\t\ttimerTmp = (float2) (timer.w, 0.0f);\n" +
                "\t}\n" +
                "\ttimer.x = timerTmp.x > -500.0f ? (timer.x - timerTmp.x * globalState.x) : timerTmp.y;\n" +
                "\ttimer.x = max(timer.x, 0.0f);\n" +
                "    timerT[index] = timer;\n" +
                "\n" +
                "    loc += dynamic.s012;\n" +
                "\tloc /= INSTANCE_SCALE;\n" +
                "\trotate = fmod(rotate + dynamic.s345 + 360.0f, 360.0f);\n" +
                "\tscale += (float3)(dynamic.s67, dScaleZ);\n" +
                "    write_imagef(final0W, index, (float4) (\n" +
                "\t\tscale.x - (q11 + q22) * scale.x,\n" +
                "\t\tloc.y,\n" +
                "\t\tloc.z,\n" +
                "\t\tloc.x\n" +
                "\t));\n" +
                "    write_imagef(final1W, index, (float4) (\n" +
                "\t\t(q01 + q23) * scale.x,\n" +
                "\t\tscale.y - (q22 + q00) * scale.y,\n" +
                "\t\t(q12 - q03) * scale.z,\n" +
                "\t\t(q01 - q23) * scale.y\n" +
                "\t));\n" +
                "    write_imagef(final2W, index, (float4) (\n" +
                "\t\t(q02 - q13) * scale.x,\n" +
                "\t\t(q12 + q03) * scale.y,\n" +
                "\t\tscale.z - (q11 + q00) * scale.z,\n" +
                "\t\t(q02 + q13) * scale.z\n" +
                "\t));\n" +
                "\n" +
                "    write_imagef(state0W, index, (float4) (rotate, alpha));\n" +
                "    state1_3[state1Index] = (float4) (scale.s012, state1.w);\n" +
                "}\n";
    }

    private BUtil_KernelSources() {}
}
