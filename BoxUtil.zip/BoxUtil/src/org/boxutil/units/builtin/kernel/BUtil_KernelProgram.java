package org.boxutil.units.builtin.kernel;

import org.boxutil.base.BaseKernelData;

import java.nio.IntBuffer;

@Deprecated
public class BUtil_KernelProgram extends BaseKernelData {
    public BUtil_KernelProgram(String source, String mainFunctionName) {
        super(source, mainFunctionName);
    }

    public BUtil_KernelProgram(String source, String programOptions, String mainFunctionName, IntBuffer programState) {
        super(source, programOptions, mainFunctionName, programState);
    }
}
