package org.boxutil.units.builtin.console;

import org.boxutil.define.BoxDatabase;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.Console;

public class PrintContextInfo implements BaseCommand {
    public CommandResult runCommand(@NotNull String s, @NotNull BaseCommand.CommandContext commandContext) {
        BoxDatabase.GLState state = BoxDatabase.getGLState();
        Console.showMessage("GL_CURRENT_DEVICE_NAME: " + state.GL_CURRENT_DEVICE_NAME);
        Console.showMessage("GL_CURRENT_DEVICE_VERSION: " + state.GL_CURRENT_DEVICE_VERSION);
        Console.showMessage("GL_CURRENT_DEVICE_VENDOR_NAME: " + state.GL_CURRENT_DEVICE_VENDOR_NAME);
        Console.showMessage("GL_CURRENT_DEVICE_VENDOR_BYTE: " + state.GL_CURRENT_DEVICE_VENDOR_BYTE);
        Console.showMessage("GL_GL42: " + state.GL_GL42);
        Console.showMessage("GL_GL43: " + state.GL_GL43);
        Console.showMessage("GL_ARB_framebuffer_object: " + state.GL_FBO);
        Console.showMessage("GL_ARB_texture_buffer_object: " + state.GL_TBO);
        Console.showMessage("GL_ARB_shader_subroutine: " + state.GL_SUBROUTINE);
        Console.showMessage("GL_COMPUTE_SHADER: " + state.GL_COMPUTE_SHADER);
        Console.showMessage("GL_IMAGE_LOAD_STORE: " + state.GL_IMAGE_LOAD_STORE);
        Console.showMessage("GL_BINDLESS_TEXTURE: " + state.GL_BINDLESS_TEXTURE);
        Console.showMessage("GL_NPOT_TEXTURE: " + state.GL_NPOT_TEXTURE);

        Console.showMessage("\nMAX_TEXTURE_BUFFER_SIZE: " + state.MAX_TEXTURE_BUFFER_SIZE);
        Console.showMessage("MAX_TEXTURE_SIZE: " + state.MAX_TEXTURE_SIZE);
        Console.showMessage("MAX_TEXTURE2D_PIXELS: " + state.MAX_TEXTURE2D_PIXELS);
        Console.showMessage("MAX_TEXTURE3D_SIZE: " + state.MAX_TEXTURE3D_SIZE);
        Console.showMessage("MAX_TEXTURE3D_PIXELS: " + state.MAX_TEXTURE3D_PIXELS);
        Console.showMessage("MAX_TEXTURE_UNITS: " + state.MAX_TEXTURE_UNITS);
        Console.showMessage("GL_MAX_WORK_GROUP_SIZE_X: " + state.GL_MAX_WORK_GROUP_SIZE_X);
        Console.showMessage("GL_MAX_WORK_GROUP_SIZE_Y: " + state.GL_MAX_WORK_GROUP_SIZE_Y);
        Console.showMessage("GL_MAX_WORK_GROUP_SIZE_Z: " + state.GL_MAX_WORK_GROUP_SIZE_Z);
        Console.showMessage("GL_MAX_LOCAL_SIZE_X: " + state.GL_MAX_LOCAL_SIZE_X);
        Console.showMessage("GL_MAX_LOCAL_SIZE_Y: " + state.GL_MAX_LOCAL_SIZE_Y);
        Console.showMessage("GL_MAX_LOCAL_SIZE_Z: " + state.GL_MAX_LOCAL_SIZE_Z);
        Console.showMessage("GL_MAX_WORK_ITEMS: " + state.GL_MAX_WORK_ITEMS);

        Console.showMessage("\nMAX_INSTANCE_DATA_TEX_SIZE: " + state.DEVICE_MAX_INSTANCE_DATA_SIZE);
        state.print();
        return CommandResult.SUCCESS;
    }
}
