package org.boxutil.units.builtin.legacy.array;

public class Stack2f {
    public float x = 0.0f;
    public float y = 0.0f;

    public Stack2f(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }
}
