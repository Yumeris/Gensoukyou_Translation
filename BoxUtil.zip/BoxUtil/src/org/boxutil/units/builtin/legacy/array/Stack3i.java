package org.boxutil.units.builtin.legacy.array;

public class Stack3i {
    public int x = 0;
    public int y = 0;
    public int z = 0;

    public Stack3i(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }
}
