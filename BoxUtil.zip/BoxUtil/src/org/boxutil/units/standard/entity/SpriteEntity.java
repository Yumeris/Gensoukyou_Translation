package org.boxutil.units.standard.entity;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.graphics.SpriteAPI;
import org.boxutil.base.BaseMIRenderData;
import org.boxutil.define.BoxDatabase;
import org.boxutil.define.BoxEnum;
import org.lwjgl.BufferUtils;
import org.lwjgl.util.vector.Vector2f;

import java.nio.FloatBuffer;

/**
 * Sprite entity will not to be applying AA if depth based AA is enabled and not to be use common mode, it only can be rendering on color mode.
 */
public class SpriteEntity extends BaseMIRenderData {
    // vec2(tile), startIndex, randomIndexEachInstance, vec2(start), vec2(end)
    protected final float[] spriteState = new float[]{1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f};
    protected final float[] baseSize = new float[]{1.0f, 1.0f};
    protected int currentTileCount = 1;
    protected boolean isRandomTile = false;

    public SpriteEntity() {
        this.getMaterialData().setDisableCullFace();
    }

    public SpriteEntity(String category, String key) {
        this(Global.getSettings().getSprite(category, key));
        this.getMaterialData().setDisableCullFace();
    }

    public SpriteEntity(String filename) {
        this(Global.getSettings().getSprite(filename));
        this.getMaterialData().setDisableCullFace();
    }

    public SpriteEntity(SpriteAPI sprite) {
        this.material.setDiffuse(sprite);
        this.getMaterialData().setDisableCullFace();
    }

    public void reset() {
        super.reset();
        this.spriteState[0] = 1.0f;
        this.spriteState[1] = 1.0f;
        this.spriteState[2] = 0.0f;
        this.spriteState[3] = 0.0f;
        this.isRandomTile = true;Global.getLogger(Global.class).info(org.lwjgl.opengl.GL11.glGetInteger(org.lwjgl.opengl.GL31.GL_MAX_TEXTURE_BUFFER_SIZE));
        this.resetUV();
    }

    public void resetUV() {
        this.spriteState[4] = 0.0f;
        this.spriteState[5] = 0.0f;
        this.spriteState[6] = 1.0f;
        this.spriteState[7] = 1.0f;
    }

    public float[] getBaseSizePerTiles() {
        return this.baseSize;
    }

    public float getBaseWidthPerTiles() {
        return this.baseSize[0];
    }

    public float getBaseHeightPerTiles() {
        return this.baseSize[1];
    }

    public void setBaseWidthPerTiles(float width) {
        this.baseSize[0] = width;
    }

    public void setBaseHeightPerTiles(float height) {
        this.baseSize[1] = height;
    }

    public void setBaseSizePerTiles(float width, float height) {
        this.setBaseWidthPerTiles(width);
        this.setBaseHeightPerTiles(height);
    }

    public int getMaxTileCount() {
        return (int) (this.spriteState[0] * this.spriteState[1]);
    }

    public boolean isTilesRendering() {
        return this.getMaxTileCount() > 1;
    }

    public int getCurrentTileCount() {
        return this.currentTileCount;
    }

    public void setCurrentTileCount(int count) {
        this.currentTileCount = Math.min(count, this.getMaxTileCount());
    }

    public int getCountPerRow() {
        return (int) this.spriteState[0];
    }

    public int getCountPerColumn() {
        return (int) this.spriteState[1];
    }

    public int getStartingIndex() {
        return (int) this.spriteState[2];
    }

    public boolean isRandomTile() {
        return this.isRandomTile;
    }

    public boolean isRandomTileEachInstance() {
        return this.spriteState[3] == 1.0f;
    }

    /**
     * @param countPerRow value greater than or equal 1.
     * @param countPerColumn value greater than or equal 1.
     */
    public void setTileSize(int countPerRow, int countPerColumn) {
        this.spriteState[0] = Math.max(countPerRow, 1);
        this.spriteState[1] = Math.max(countPerColumn, 1);
        this.currentTileCount = this.getMaxTileCount();
    }

    /**
     * Texture parameter should be {@link org.lwjgl.opengl.GL11#GL_REPEAT}.
     */
    public void setRandomTile(boolean isRandom) {
        this.isRandomTile = isRandom;
    }

    /**
     * Texture parameter should be {@link org.lwjgl.opengl.GL11#GL_REPEAT}.
     */
    public void setRandomTileEachInstance(boolean random) {
        this.spriteState[3] = random ? 1.0f : 0.0f;
    }

    /**
     * From bottom-left, line by line.
     */
    public void setStartingFormIndex(int index) {
        this.spriteState[2] = Math.min(Math.max(index, 0), this.currentTileCount - 1);
    }

    public void nextTileIndex() {
        if (this.currentTileCount == 1) return;
        this.spriteState[2]++;
        if (this.spriteState[2] >= this.currentTileCount) this.spriteState[2] = 0.0f;
    }

    public void setDiffuseSprite(SpriteAPI sprite) {
        this.getMaterialData().setDiffuse(sprite);
    }

    public void setEmissiveSprite(SpriteAPI sprite) {
        this.getMaterialData().setEmissive(sprite);
    }

    public void setDiffuseSprite(String category, String key) {
        this.getMaterialData().setDiffuse(Global.getSettings().getSprite(category, key));
    }

    public void setEmissiveSprite(String category, String key) {
        this.getMaterialData().setEmissive(Global.getSettings().getSprite(category, key));
    }

    public void setDiffuseSprite(String filename) {
        this.getMaterialData().setDiffuse(Global.getSettings().getSprite(filename));
    }

    public void setEmissiveSprite(String filename) {
        this.getMaterialData().setEmissive(Global.getSettings().getSprite(filename));
    }

    public void resetDiffuseSprite() {
        this.getMaterialData().setDiffuse(BoxDatabase.BUtil_ONE);
    }

    public void resetEmissiveSprite() {
        this.getMaterialData().setEmissive(BoxDatabase.BUtil_NONE);
    }

    public float[] getUVStartArray() {
        return new float[]{this.spriteState[4], spriteState[5]};
    }

    public Vector2f getUVStart() {
        return new Vector2f(this.spriteState[4], spriteState[5]);
    }

    public void setUVStart(float x, float y) {
        this.spriteState[4] = x;
        this.spriteState[5] = y;
    }

    public void setUVStart(Vector2f location) {
        this.spriteState[4] = location.x;
        this.spriteState[5] = location.y;
    }

    public float[] getUVEndArray() {
        return new float[]{this.spriteState[6], spriteState[7]};
    }

    public Vector2f getUVEnd() {
        return new Vector2f(this.spriteState[7], spriteState[6]);
    }

    public void setUVEnd(float x, float y) {
        this.spriteState[6] = x;
        this.spriteState[7] = y;
    }

    public void setUVEnd(Vector2f location) {
        this.spriteState[4] = location.x;
        this.spriteState[7] = location.y;
    }

    public FloatBuffer pickDataPackage_vec4() {
        FloatBuffer buffer = BufferUtils.createFloatBuffer(24);
        buffer.put(this.material.getState());
        buffer.put(this.getGlobalTimerAlpha());
        buffer.put(this.spriteState);
        buffer.put(this.hashCode() / 1048576.0f);
        buffer.put(this.getCurrentTileCount() - 1);
        buffer.put(this.baseSize);
        buffer.position(0);
        buffer.limit(buffer.capacity());
        return buffer;
    }

    @Deprecated
    public byte getDrawMode() {return BoxEnum.MODE_COLOR;}

    @Deprecated
    public void setDrawMode(int drawMode) {}
}
