package org.boxutil.units.standard.attribute;

import com.fs.starfarer.api.graphics.SpriteAPI;
import org.boxutil.util.CommonUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.boxutil.define.BoxDatabase;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import java.awt.*;

// The material is only 2D-Texture supported.
public class MaterialData {
    protected final static byte _FULL = 1;
    protected final SpriteAPI[] textures = new SpriteAPI[]{BoxDatabase.BUtil_ONE, BoxDatabase.BUtil_Z, BoxDatabase.BUtil_ONE, BoxDatabase.BUtil_NONE};
    protected byte cullFace = 0;
    protected final float[] state = new float[]{_FULL, _FULL, _FULL, _FULL, _FULL, _FULL, _FULL, _FULL, _FULL, 0.0f, _FULL};
    protected boolean additionEmissive = true;

    public MaterialData() {

    }

    public void clearTextures() {
        this.textures[0] = BoxDatabase.BUtil_ONE;
        this.textures[1] = BoxDatabase.BUtil_Z;
        this.textures[2] = BoxDatabase.BUtil_ONE;
        this.textures[3] = BoxDatabase.BUtil_NONE;
    }

    public void syncTextures(ModelData entity) {
        this.textures[0] = entity.getDiffuse();
        this.textures[1] = entity.getNormal();
        this.textures[2] = entity.getAO();
        this.textures[3] = entity.getEmissive();
    }

    /**
     * Without textures.
     */
    public void reset() {
        this.cullFace = 0;
        this.state[0] = _FULL;
        this.state[1] = _FULL;
        this.state[2] = _FULL;
        this.state[3] = _FULL;
        this.state[4] = _FULL;
        this.state[5] = _FULL;
        this.state[6] = _FULL;
        this.state[7] = _FULL;
        this.state[8] = _FULL;
        this.state[9] = 0.0f;
        this.state[10] = _FULL;
    }

    public void putShaderTexture() {
        for (int i = 0; i < this.textures.length; i++) {
            GL13.glActiveTexture(GL13.GL_TEXTURE0 + i);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.textures[i].getTextureId());
        }
    }

    public SpriteAPI[] getTextures() {
        return this.textures;
    }

    public SpriteAPI getDiffuse() {
        return textures[0];
    }

    /**
     * Set null for default.
     */
    public void setDiffuse(@Nullable SpriteAPI diffuse) {
        if (diffuse == null) this.textures[0] = BoxDatabase.BUtil_ONE; else this.textures[0] = diffuse;
    }

    public SpriteAPI getNormal() {
        return textures[1];
    }

    /**
     * Set null for default.
     */
    public void setNormal(@Nullable SpriteAPI normal) {
        if (normal == null) this.textures[1] = BoxDatabase.BUtil_Z; else this.textures[1] = normal;
    }

    public SpriteAPI getAO() {
        return textures[2];
    }

    /**
     * Set null for default.
     */
    public void setAO(@Nullable SpriteAPI ao) {
        if (ao == null) this.textures[2] = BoxDatabase.BUtil_ONE; else this.textures[2] = ao;
    }

    public SpriteAPI getEmissive() {
        return textures[3];
    }

    /**
     * Set null for default.
     */
    public void setEmissive(@Nullable SpriteAPI emissive) {
        if (emissive == null) this.textures[3] = BoxDatabase.BUtil_NONE; else this.textures[3] = emissive;
    }

    public void setDisableCullFace() {
        this.cullFace = 3;
    }

    public byte getCullFace() {
        return this.cullFace;
    }

    public void setCullBack() {
        this.cullFace = 0;
    }

    public void setCullFront() {
        this.cullFace = 1;
    }

    public void setCullFrontAndBack() {
        this.cullFace = 2;
    }

    public float[] getColorArray() {
        return new float[]{this.state[0], this.state[1], this.state[2], this.state[3]};
    }

    public Color getColorC() {
        return CommonUtil.toCommonColor(this.getColor());
    }

    public Vector4f getColor() {
        return new Vector4f(this.state[0], this.state[1], this.state[2], this.state[3]);
    }

    public void setColor(@NotNull Vector4f color) {
        this.state[0] = color.x;
        this.state[1] = color.y;
        this.state[2] = color.z;
        this.state[3] = color.w;
    }

    public void setColor(float r, float g, float b, float a) {
        this.state[0] = r;
        this.state[1] = g;
        this.state[2] = b;
        this.state[3] = a;
    }

    public void setColor(Color color) {
        this.state[0] = color.getRed() / 255.0f;
        this.state[1] = color.getGreen() / 255.0f;
        this.state[2] = color.getBlue() / 255.0f;
        this.state[3] = color.getAlpha() / 255.0f;
    }

    public void setColorAlpha(float alpha) {
        this.state[3] = alpha;
    }

    public float[] getEmissiveColorArray() {
        return new float[]{this.state[4], this.state[5], this.state[6], this.state[7]};
    }

    public Color getEmissiveColorC() {
        return CommonUtil.toCommonColor(this.getEmissiveColor());
    }

    public Vector4f getEmissiveColor() {
        return new Vector4f(this.state[4], this.state[5], this.state[6], this.state[7]);
    }

    public void setEmissiveColor(@NotNull Vector4f color) {
        this.state[4] = color.x;
        this.state[5] = color.y;
        this.state[6] = color.z;
        this.state[7] = color.w;
    }

    public void setEmissiveColor(float r, float g, float b, float a) {
        this.state[4] = r;
        this.state[5] = g;
        this.state[6] = b;
        this.state[7] = a;
    }

    public void setEmissiveColor(Color color) {
        this.state[4] = color.getRed() / 255.0f;
        this.state[5] = color.getGreen() / 255.0f;
        this.state[6] = color.getBlue() / 255.0f;
        this.state[7] = color.getAlpha() / 255.0f;
    }

    public void setEmissiveColorAlpha(float alpha) {
        this.state[7] = alpha;
    }

    public float[] getEmissiveStateArray() {
        return new float[]{this.state[8], this.state[9], this.state[10]};
    }

    public Vector3f getEmissiveState() {
        return new Vector3f(this.state[8], this.state[9], this.state[10]);
    }

    public void setEmissiveState(float alphaToEmissive, float colorToEmissive, float glowPower) {
        this.state[8] = alphaToEmissive;
        this.state[9] = colorToEmissive;
        this.state[10] = glowPower;
    }

    public float getAlphaToEmissive() {
        return this.state[8];
    }

    /**
     * @param alphaToEmissive mix level, value: 0.0 to 1.0
     */
    public void setAlphaToEmissive(float alphaToEmissive) {
        this.state[8] = alphaToEmissive;
    }

    public void setAlphaToEmissiveDefault() {
        this.state[8] = _FULL;
    }

    /**
     * Use alpha mix when false.
     * Vanilla rendering: usually is addition.
     */
    public boolean isAdditionEmissive() {
        return this.additionEmissive;
    }

    public void setAdditionEmissive(boolean addition) {
        this.additionEmissive = addition;
    }

    public float isColorToEmissive() {
        return this.state[9];
    }

    /**
     * @param colorToEmissive mix level, value: 0.0 to 1.0
     */
    public void setColorToEmissive(float colorToEmissive) {
        this.state[9] = colorToEmissive;
    }

    public void setColorToEmissiveDefault() {
        this.state[9] = 0.0f;
    }

    public float getGlowPower() {
        return this.state[10];
    }

    /**
     * @param glowPower Decided by final of emissive level; 0 to 1.0f
     */
    public void setGlowPower(float glowPower) {
        this.state[10] = glowPower;
    }

    public void setGlowPowerDefault() {
        this.state[10] = _FULL;
    }

    public float[] getState() {
        return this.state;
    }
}
