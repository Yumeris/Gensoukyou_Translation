package org.boxutil.units.standard.attribute;

import org.jetbrains.annotations.NotNull;
import org.boxutil.base.api.InstanceDataAPI;
import org.boxutil.define.BoxDatabase;
import org.boxutil.define.BoxEnum;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

import java.awt.*;

/**
 * <strong>Priority use this if renders more than one entity.</strong><p>
 * Max base location value is 655040.0f.<p>
 * Timer value used 32bit-float in GL.
 * Max other float value is 65504.0f, used half-float in GL.<p>
 * Color used unsigned byte in GL.<p>
 * It was caused by vanilla order of magnitude, save them all for 32F will kill your vRam.
 */
public class Instance3Data implements InstanceDataAPI {
    public static final float MAX_LOCATION_VALUE = 65504.0f * BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
    public static final float MAX_OTHER_VALUE = 65504.0f;
    // vec3(location), vec3(rotate), vec3(scale), vec3(offset), vec3(rotateRate), vec3(scaleRate), vec4(timer)
    protected final float[] state = new float[22];
    // vec4(color), vec4(emissive)
    protected final byte[] colorState = new byte[]{BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR};

    public Instance3Data() {}

    public Instance3Data(Instance3Data data) {
        System.arraycopy(data.state, 0, this.state, 0, this.state.length);
        System.arraycopy(data.colorState, 0, this.colorState, 0, this.colorState.length);
    }

    /**
     * For built-in pipeline.<p>
     * {<p>
     * 0, loc.z, loc.y, loc.x<p>
     * 0, 0,     0,     0<p>
     * 0, 0,     0,     0<p>
     * }
     */
    public float[] pickFinal_16F() {
        return new float[]{0.0f, this.state[2], this.state[1], this.state[0]};
    }

    /**
     * For built-in pipeline.<p>
     * {<p>
     * total, fadeIn, full, fadeOut<p>
     * }
     */
    public float[] pickTimer_32F() {
        return new float[]{this.state[18], this.state[19], this.state[20], this.state[21]};
    }

    /**
     * For built-in pipeline.
     * {<p>
     * rotate.x,  rotate.y, rotate.z,  alpha<p>
     * scale.x,   scale.y,  scale.z,   dLoc.x<p>
     * dLoc.y,    dLoc.z,   dRotate.x, dRotate.y<p>
     * dRotate.z, dScale.x, dScale.y,  dScale.z<p>
     * }
     */
    public float[][] pickState_16F() {
        return new float[][]{
                new float[]{this.state[3], this.state[4], this.state[5], 0.0f,},
                new float[]{this.state[6], this.state[7], this.state[8], this.state[9],},
                new float[]{this.state[10], this.state[11], this.state[12], this.state[13],},
                new float[]{this.state[14], this.state[15], this.state[16], this.state[17],}
        };
    }

    /**
     * For built-in pipeline.
     * {<p>
     * cR, cG, cB cA<p>
     * eR, eG, eB, eA<p>
     * }
     */
    public byte[][] pickColor_8F() {
        return new byte[][]{
                new byte[]{this.colorState[0], this.colorState[1], this.colorState[2], this.colorState[3],},
                new byte[]{this.colorState[4], this.colorState[5], this.colorState[6], this.colorState[7],},
        };
    }

    public float[] getState() {
        return this.state;
    }

    public byte[] getColorState() {
        return this.colorState;
    }

    /**
     * Transform data of base.<p>
     * Rotate use ZXY order, angle of yaw/pitch/roll or z/x/y.<p>
     * Scale use factor, it's not a target size.<p>
     * Base value.
     */
    public float[] getBaseState() {
        return new float[]{this.state[0], this.state[1], this.state[2], this.state[3], this.state[4], this.state[5], this.state[6], this.state[7], this.state[8]};
    }

    public float[] getLocationArray() {
        return new float[]{this.state[0] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[1] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[2] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE};
    }

    public Vector3f getLocation() {
        return new Vector3f(this.state[0] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[1] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[2] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE);
    }

    public void setLocation(@NotNull Vector3f location) {
        this.setLocation(location.x, location.y, location.z);
    }

    public void setLocation(@NotNull Vector2f location) {
        this.setLocation(location.x, location.y);
    }

    public void setLocation(float x, float y, float z) {
        this.setLocation(x, y);
        this.state[2] = z / BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
    }

    public void setLocation(float x, float y) {
        this.state[0] = x / BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
        this.state[1] = y / BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
    }

    public float[] getLocationArrayDirect() {
        return new float[]{this.state[0], this.state[1], this.state[2]};
    }

    public Vector3f getLocationDirect() {
        return new Vector3f(this.state[0], this.state[1], this.state[2]);
    }

    public void setLocationDirect(@NotNull Vector3f location) {
        this.setLocationDirect(location.x, location.y, location.z);
    }

    public void setLocationDirect(@NotNull Vector2f location) {
        this.setLocationDirect(location.x, location.y);
    }

    public void setLocationDirect(float x, float y, float z) {
        this.setLocationDirect(x, y);
        this.state[2] = z;
    }

    public void setLocationDirect(float x, float y) {
        this.state[0] = x;
        this.state[1] = y;
    }

    public float[] getRotateArrayZXY() {
        return new float[]{this.state[3], this.state[4], this.state[5]};
    }

    public Vector3f getRotateZXY() {
        return new Vector3f(this.state[3], this.state[4], this.state[5]);
    }

    public void setRotateZXY(@NotNull Vector3f rotate) {
        this.setRotateZXY(rotate.x, rotate.y, rotate.z);
    }

    public void setRotateZXY(float yaw, float pitch, float roll) {
        this.setFacing(yaw);
        this.state[4] = pitch;
        this.state[5] = roll;
    }

    public void setFacing(float facing) {
        this.state[3] = facing;
    }

    public float[] getScaleArray() {
        return new float[]{this.state[6], this.state[7], this.state[8]};
    }

    public Vector3f getScale() {
        return new Vector3f(this.state[6], this.state[7], this.state[8]);
    }

    public void setScale(@NotNull Vector3f rotate) {
        this.setScale(rotate.x, rotate.y, rotate.z);
    }

    public void setScale(float x, float y, float z) {
        this.setScaleVanilla(x, y);
        this.state[8] = z;
    }

    public void setScaleVanilla(float x, float y) {
        this.state[6] = x;
        this.state[7] = y;
    }

    public void setScaleALl(float factor) {
        this.setScale(factor, factor, factor);
    }

    /**
     * Transform data per second.<p>
     * Fixed values.
     */
    public float[] getDynamicState() {
        return new float[]{this.state[9], this.state[10], this.state[11], this.state[12], this.state[13], this.state[14], this.state[15], this.state[16], this.state[17]};
    }

    public float[] getVelocityArray() {
        return new float[]{this.state[9], this.state[10], this.state[11]};
    }

    public Vector3f getVelocity() {
        return new Vector3f(this.state[9], this.state[10], this.state[11]);
    }

    public void setVelocity(@NotNull Vector3f location) {
        this.setVelocity(location.x, location.y, location.z);
    }

    public void setVelocity(@NotNull Vector2f location) {
        this.setVelocity(location.x, location.y);
    }

    public void setVelocity(float x, float y, float z) {
        this.setVelocity(x, y);
        this.state[11] = z;
    }

    public void setVelocity(float x, float y) {
        this.state[9] = x;
        this.state[10] = y;
    }

    public void setVelocityDirect(@NotNull Vector3f location) {
        this.setVelocityDirect(location.x, location.y, location.z);
    }

    public void setVelocityDirect(@NotNull Vector2f location) {
        this.setVelocityDirect(location.x, location.y);
    }

    public void setVelocityDirect(float x, float y, float z) {
        this.setVelocityDirect(x, y);
        this.state[11] = z;
    }

    public void setVelocityDirect(float x, float y) {
        this.state[9] = x;
        this.state[10] = y;
    }

    public float[] getRotateRateArrayZXY() {
        return new float[]{this.state[12], this.state[13], this.state[14]};
    }

    public Vector3f getRotateRateZXY() {
        return new Vector3f(this.state[12], this.state[13], this.state[14]);
    }

    public void setRotateRateZXY(@NotNull Vector3f rotate) {
        this.setRotateRateZXY(rotate.x, rotate.y, rotate.z);
    }

    public void setRotateRateZXY(float yaw, float pitch, float roll) {
        this.setTurnRate(yaw);
        this.state[13] = pitch;
        this.state[14] = roll;
    }

    public void setTurnRate(float facing) {
        this.state[12] = facing;
    }

    public float[] getScaleRateArray() {
        return new float[]{this.state[15], this.state[16], this.state[17]};
    }

    public Vector3f getScaleRate() {
        return new Vector3f(this.state[15], this.state[16], this.state[17]);
    }

    public void setScaleRate(@NotNull Vector3f rotate) {
        this.setScaleRate(rotate.x, rotate.y, rotate.z);
    }

    public void setScaleRate(float x, float y, float z) {
        this.setScaleRateVanilla(x, y);
        this.state[17] = z;
    }

    public void setScaleRateVanilla(float x, float y) {
        this.state[15] = x;
        this.state[16] = y;
    }

    public void setScaleRateALl(float factor) {
        this.setScaleRate(factor, factor, factor);
    }

    public byte[] getColorArray() {
        return new byte[]{this.colorState[0], this.colorState[1], this.colorState[2], this.colorState[3]};
    }

    public Color getColor() {
        return new Color(
                this.colorState[0] & 0xFF,
                this.colorState[1] & 0xFF,
                this.colorState[2] & 0xFF,
                this.colorState[3] & 0xFF);
    }

    public Vector4f getColor4f() {
        return new Vector4f(
                (this.colorState[0] & 0xFF) / 255.0f,
                (this.colorState[1] & 0xFF) / 255.0f,
                (this.colorState[2] & 0xFF) / 255.0f,
                (this.colorState[3] & 0xFF) / 255.0f);
    }

    public void setColor(@NotNull Color color) {
        this.colorState[0] = (byte) color.getRed();
        this.colorState[1] = (byte) color.getGreen();
        this.colorState[2] = (byte) color.getBlue();
        this.colorState[3] = (byte) color.getAlpha();
    }

    public void setColor(byte r, byte g, byte b, byte a) {
        this.colorState[0] = r;
        this.colorState[1] = g;
        this.colorState[2] = b;
        this.colorState[3] = a;
    }

    public void setColor(int r, int g, int b, int a) {
        this.colorState[0] = (byte) r;
        this.colorState[1] = (byte) g;
        this.colorState[2] = (byte) b;
        this.colorState[3] = (byte) a;
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setColor(float r, float g, float b, float a) {
        this.colorState[0] = (byte) (r * 255.0f);
        this.colorState[1] = (byte) (g * 255.0f);
        this.colorState[2] = (byte) (b * 255.0f);
        this.colorState[3] = (byte) (a * 255.0f);
    }

    public byte[] getEmissiveColorArray() {
        return new byte[]{this.colorState[4], this.colorState[5], this.colorState[6], this.colorState[7]};
    }

    public Color getEmissiveColor() {
        return new Color(
                this.colorState[4] & 0xFF,
                this.colorState[5] & 0xFF,
                this.colorState[6] & 0xFF,
                this.colorState[7] & 0xFF);
    }

    public Vector4f getEmissiveColor4f() {
        return new Vector4f(
                (this.colorState[4] & 0xFF) / 255.0f,
                (this.colorState[5] & 0xFF) / 255.0f,
                (this.colorState[6] & 0xFF) / 255.0f,
                (this.colorState[7] & 0xFF) / 255.0f);
    }

    public void setEmissiveColor(@NotNull Color color) {
        this.colorState[4] = (byte) color.getRed();
        this.colorState[5] = (byte) color.getGreen();
        this.colorState[6] = (byte) color.getBlue();
        this.colorState[7] = (byte) color.getAlpha();
    }

    public void setEmissiveColor(byte r, byte g, byte b, byte a) {
        this.colorState[4] = r;
        this.colorState[5] = g;
        this.colorState[6] = b;
        this.colorState[7] = a;
    }

    public void setEmissiveColor(int r, int g, int b, int a) {
        this.colorState[4] = (byte) r;
        this.colorState[5] = (byte) g;
        this.colorState[6] = (byte) b;
        this.colorState[7] = (byte) a;
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setEmissiveColor(float r, float g, float b, float a) {
        this.colorState[4] = (byte) (r * 255.0f);
        this.colorState[5] = (byte) (g * 255.0f);
        this.colorState[6] = (byte) (b * 255.0f);
        this.colorState[7] = (byte) (a * 255.0f);
    }

    public float[] getTimer() {
        return new float[]{this.state[18], this.state[19], this.state[20], this.state[21]};
    }

    /**
     * Will pick a max total value for a global timer.<p>
     * Just initialized data values, to use 3d-texture id get the actual data.
     */
    public void setTimer(float fadeIn, float full, float fadeOut) {
        if (fadeIn <= 0.0f && full <= 0.0f && fadeOut <= 0.0f) {
            this.state[18] = this.state[19] = this.state[20] = this.state[21] = -512.0f;
            return;
        }
        this.state[18] = 3.0f;
        if (fadeIn <= 0.0f) {
            this.state[19] = -512.0f;
            this.state[18] = 2.0f;
            if (full <= 0.0f) this.state[18] = 1.0f;
        } else this.state[19] = 1.0f / fadeIn;
        this.state[20] = full <= 0.0f ? -512.0f : 1.0f / full;
        this.state[21] = fadeOut <= 0.0f ? -512.0f : 1.0f / fadeOut;
    }
}
