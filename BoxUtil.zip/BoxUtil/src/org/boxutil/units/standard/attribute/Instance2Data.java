package org.boxutil.units.standard.attribute;

import org.jetbrains.annotations.NotNull;
import org.boxutil.base.api.InstanceDataAPI;
import org.boxutil.define.BoxDatabase;
import org.boxutil.define.BoxEnum;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector4f;

import java.awt.*;

public class Instance2Data implements InstanceDataAPI {
    public static final float MAX_LOCATION_VALUE = 65504.0f * BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
    public static final float MAX_OTHER_VALUE = 65504.0f;
    // vec2(location), float(facing), vec2(scale), vec2(offset), float(turnRate), vec2(scaleRate), vec4(timer)
    protected final float[] state = new float[14];
    // vec4(color), vec4(emissive)
    protected final byte[] colorState = new byte[]{BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR, BoxEnum.ONE_COLOR};

    public Instance2Data() {}

    public Instance2Data(Instance2Data data) {
        System.arraycopy(data.state, 0, this.state, 0, this.state.length);
        System.arraycopy(data.colorState, 0, this.colorState, 0, this.colorState.length);
    }

    /**
     * For built-in pipeline.<p>
     * {<p>
     * 0, 0, loc.y, loc.x<p>
     * 0, 0, 0,     alpha<p>
     * }
     */
    public float[] pickFinal_16F() {
        return new float[]{0.0f, 0.0f, this.state[1], this.state[0]};
    }

    /**
     * For built-in pipeline.<p>
     * {<p>
     * total, fadeIn, full, fadeOut<p>
     * }
     */
    public float[] pickTimer_32F() {
        return new float[]{this.state[10], this.state[11], this.state[12], this.state[13]};
    }

    /**
     * For built-in pipeline.
     * {<p>
     * scale.x, scale.y, facing,   turnRate<p>
     * dLoc.x,  dLoc.y,  dScale.x, dScale.y<p>
     * }
     */
    public float[][] pickState_16F() {
        return new float[][]{
                new float[]{this.state[3], this.state[4], this.state[2], this.state[7],},
                new float[]{this.state[5], this.state[6], this.state[8], this.state[9],},
        };
    }

    /**
     * For built-in pipeline.
     * {<p>
     * cR, cG, cB cA<p>
     * eR, eG, eB, eA<p>
     * }
     */
    public byte[][] pickColor_8F() {
        return new byte[][]{
                new byte[]{this.colorState[0], this.colorState[1], this.colorState[2], this.colorState[3],},
                new byte[]{this.colorState[4], this.colorState[5], this.colorState[6], this.colorState[7],},
        };
    }

    public float[] getState() {
        return this.state;
    }

    public byte[] getColorState() {
        return this.colorState;
    }

    /**
     * Transform data of base.<p>
     * Scale use factor, it's not a target size.<p>
     * Base value.
     */
    public float[] getBaseState() {
        return new float[]{this.state[0], this.state[1], this.state[2], this.state[3], this.state[4]};
    }

    public float[] getLocationArray() {
        return new float[]{this.state[0] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[1] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE};
    }

    public Vector2f getLocation() {
        return new Vector2f(this.state[0] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE, this.state[1] * BoxDatabase.HALF_FLOAT_LOCATION_SCALE);
    }

    public void setLocation(@NotNull Vector2f location) {
        this.setLocation(location.x, location.y);
    }

    public void setLocation(float x, float y) {
        this.state[0] = x / BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
        this.state[1] = y / BoxDatabase.HALF_FLOAT_LOCATION_SCALE;
    }

    public float[] getLocationArrayDirect() {
        return new float[]{this.state[0], this.state[1]};
    }

    public Vector2f getLocationDirect() {
        return new Vector2f(this.state[0], this.state[1]);
    }

    public void setLocationDirect(@NotNull Vector2f location) {
        this.setLocationDirect(location.x, location.y);
    }

    public void setLocationDirect(float x, float y) {
        this.state[0] = x;
        this.state[1] = y;
    }

    public float getFacing() {
        return this.state[2];
    }

    public void setFacing(float facing) {
        this.state[2] = facing;
    }

    public float[] getScaleArray() {
        return new float[]{this.state[3], this.state[4]};
    }

    public Vector2f getScale() {
        return new Vector2f(this.state[3], this.state[4]);
    }

    public void setScale(@NotNull Vector2f rotate) {
        this.setScale(rotate.x, rotate.y);
    }

    public void setScale(float x, float y) {
        this.state[3] = x;
        this.state[4] = y;
    }

    public void setScaleALl(float factor) {
        this.setScale(factor, factor);
    }

    /**
     * Transform data per second.<p>
     * Fixed values.
     */
    public float[] getDynamicState() {
        return new float[]{this.state[5], this.state[6], this.state[7], this.state[8], this.state[9]};
    }

    public float[] getVelocityArray() {
        return new float[]{this.state[5], this.state[6]};
    }

    public Vector2f getVelocity() {
        return new Vector2f(this.state[5], this.state[6]);
    }

    public void setVelocity(@NotNull Vector2f location) {
        this.setVelocity(location.x, location.y);
    }

    public void setVelocity(float x, float y) {
        this.state[5] = x;
        this.state[6] = y;
    }

    public void setVelocityDirect(@NotNull Vector2f location) {
        this.setVelocityDirect(location.x, location.y);
    }

    public void setVelocityDirect(float x, float y) {
        this.state[5] = x;
        this.state[6] = y;
    }

    public float getTurnRate() {
        return this.state[7];
    }

    public void setTurnRate(float turnRate) {
        this.state[7] = turnRate;
    }

    public float[] getScaleRateArray() {
        return new float[]{this.state[8], this.state[9]};
    }

    public Vector2f getScaleRate() {
        return new Vector2f(this.state[8], this.state[9]);
    }

    public void setScaleRate(@NotNull Vector2f rotate) {
        this.setScaleRate(rotate.x, rotate.y);
    }

    public void setScaleRate(float x, float y) {
        this.state[8] = x;
        this.state[9] = y;
    }

    public void setScaleRateALl(float factor) {
        this.setScaleRate(factor, factor);
    }

    public byte[] getColorArray() {
        return new byte[]{this.colorState[0], this.colorState[1], this.colorState[2], this.colorState[3]};
    }

    public Color getColor() {
        return new Color(
                this.colorState[0] & 0xFF,
                this.colorState[1] & 0xFF,
                this.colorState[2] & 0xFF,
                this.colorState[3] & 0xFF);
    }

    public Vector4f getColor4f() {
        return new Vector4f(
                (this.colorState[0] & 0xFF) / 255.0f,
                (this.colorState[1] & 0xFF) / 255.0f,
                (this.colorState[2] & 0xFF) / 255.0f,
                (this.colorState[3] & 0xFF) / 255.0f);
    }

    public void setColor(@NotNull Color color) {
        this.colorState[0] = (byte) color.getRed();
        this.colorState[1] = (byte) color.getGreen();
        this.colorState[2] = (byte) color.getBlue();
        this.colorState[3] = (byte) color.getAlpha();
    }

    public void setColor(byte r, byte g, byte b, byte a) {
        this.colorState[0] = r;
        this.colorState[1] = g;
        this.colorState[2] = b;
        this.colorState[3] = a;
    }

    public void setColor(int r, int g, int b, int a) {
        this.colorState[0] = (byte) r;
        this.colorState[1] = (byte) g;
        this.colorState[2] = (byte) b;
        this.colorState[3] = (byte) a;
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setColor(float r, float g, float b, float a) {
        this.colorState[0] = (byte) (r * 255.0f);
        this.colorState[1] = (byte) (g * 255.0f);
        this.colorState[2] = (byte) (b * 255.0f);
        this.colorState[3] = (byte) (a * 255.0f);
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setAlpha(float a) {
        this.colorState[3] = (byte) (a * 255.0f);
    }

    public byte[] getEmissiveColorArray() {
        return new byte[]{this.colorState[4], this.colorState[5], this.colorState[6], this.colorState[7]};
    }

    public Color getEmissiveColor() {
        return new Color(
                this.colorState[4] & 0xFF,
                this.colorState[5] & 0xFF,
                this.colorState[6] & 0xFF,
                this.colorState[7] & 0xFF);
    }

    public Vector4f getEmissiveColor4f() {
        return new Vector4f(
                (this.colorState[4] & 0xFF) / 255.0f,
                (this.colorState[5] & 0xFF) / 255.0f,
                (this.colorState[6] & 0xFF) / 255.0f,
                (this.colorState[7] & 0xFF) / 255.0f);
    }

    public void setEmissiveColor(@NotNull Color color) {
        this.colorState[4] = (byte) color.getRed();
        this.colorState[5] = (byte) color.getGreen();
        this.colorState[6] = (byte) color.getBlue();
        this.colorState[7] = (byte) color.getAlpha();
    }

    public void setEmissiveColor(byte r, byte g, byte b, byte a) {
        this.colorState[4] = r;
        this.colorState[5] = g;
        this.colorState[6] = b;
        this.colorState[7] = a;
    }

    public void setEmissiveColor(int r, int g, int b, int a) {
        this.colorState[4] = (byte) r;
        this.colorState[5] = (byte) g;
        this.colorState[6] = (byte) b;
        this.colorState[7] = (byte) a;
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setEmissiveColor(float r, float g, float b, float a) {
        this.colorState[4] = (byte) (r * 255.0f);
        this.colorState[5] = (byte) (g * 255.0f);
        this.colorState[6] = (byte) (b * 255.0f);
        this.colorState[7] = (byte) (a * 255.0f);
    }

    /**
     * The value 0.0 to 1.0
     */
    public void setEmissiveAlpha(float a) {
        this.colorState[7] = (byte) (a * 255.0f);
    }

    public float[] getTimer() {
        return new float[]{this.state[10], this.state[11], this.state[12], this.state[13]};
    }

    /**
     * Will pick a max total value for a global timer.<p>
     * Just initialized data values, to use 3d-texture id get the actual data.
     */
    public void setTimer(float fadeIn, float full, float fadeOut) {
        if (fadeIn <= 0.0f && full <= 0.0f && fadeOut <= 0.0f) {
            this.state[10] = this.state[11] = this.state[12] = this.state[13] = -512.0f;
            return;
        }
        this.state[10] = 3.0f;
        if (fadeIn <= 0.0f) {
            this.state[11] = -512.0f;
            this.state[10] = 2.0f;
            if (full <= 0.0f) this.state[10] = 1.0f;
        } else this.state[11] = 1.0f / fadeIn;
        this.state[12] = full <= 0.0f ? -512.0f : 1.0f / full;
        this.state[13] = fadeOut <= 0.0f ? -512.0f : 1.0f / fadeOut;
    }
}
